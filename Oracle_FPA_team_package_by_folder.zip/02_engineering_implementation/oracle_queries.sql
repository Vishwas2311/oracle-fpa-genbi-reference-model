-- DRAFT_UNEXECUTED. PROPOSED_TARGET only. Provisional Oracle 19c baseline.
-- Preconditions: approved policies/mappings, published immutable release data,
-- current trusted identity, database enforcement, bounded query window, and driver limits.
-- These are reviewed-shape templates, not an arbitrary SQL acceptance mechanism.

-- TEMPLATE Q_GL_ACTIVITY. Functional-currency debit-positive movement, no presentation sign inference.
-- Bind :tenant_id, :principal_id, :purpose_code from trusted identity/policy context.
-- Bind :access_at as TIMESTAMP WITH TIME ZONE from trusted current clock, never user historical as-of.
-- Bind :period_start/:period_end as Oracle DATE business-date boundaries, :release_id as character.
SELECT g.ENTITY_ID, g.LEDGER_ID, g.ACCOUNT_ID, g.PERIOD_ID, g.CURRENCY,
       COUNT(*) AS SOURCE_ROWS, SUM(g.DEBIT) AS DEBIT,
       SUM(g.CREDIT) AS CREDIT, SUM(g.DEBIT-g.CREDIT) AS MOVEMENT_DR
FROM FPA_GL_LINE g
JOIN FPA_PERIOD p ON p.TENANT_ID=g.TENANT_ID AND p.PERIOD_ID=g.PERIOD_ID
  AND p.RELEASE_ID=g.RELEASE_ID
WHERE g.TENANT_ID=:tenant_id AND g.RELEASE_ID=:release_id
  AND g.POSTING_STATE='POSTED' AND g.LAYER_CODE=:layer_code
  AND p.PERIOD_START>=:period_start AND p.PERIOD_END<=:period_end
  AND EXISTS (SELECT 1 FROM FPA_ENTITLEMENT e
              WHERE e.TENANT_ID=g.TENANT_ID AND e.ENTITY_ID=g.ENTITY_ID
                AND e.PRINCIPAL_ID=:principal_id AND e.PURPOSE_CODE=:purpose_code
                AND e.VALID_FROM<=:access_at AND e.VALID_TO>:access_at)
GROUP BY g.ENTITY_ID,g.LEDGER_ID,g.ACCOUNT_ID,g.PERIOD_ID,g.CURRENCY;

-- TEMPLATE Q_ACTUAL_PLAN. Common grain entity/ledger/account/period/currency.
-- Preconditions: plan sign mapped to debit-positive convention upstream; approved budget version.
-- Both inputs are authorized before the FULL OUTER JOIN. An absent side stays NULL.
-- Period bounds use the named period spine, never lexical period IDs.
WITH allowed AS (
  SELECT DISTINCT TENANT_ID, ENTITY_ID FROM FPA_ENTITLEMENT
  WHERE TENANT_ID=:tenant_id AND PRINCIPAL_ID=:principal_id
    AND PURPOSE_CODE=:purpose_code AND VALID_FROM<=:access_at AND VALID_TO>:access_at
), actual AS (
  SELECT g.TENANT_ID,g.ENTITY_ID,g.LEDGER_ID,g.ACCOUNT_ID,g.PERIOD_ID,g.CURRENCY,
         SUM(g.DEBIT-g.CREDIT) AS AMOUNT
  FROM FPA_GL_LINE g
  JOIN allowed e ON e.TENANT_ID=g.TENANT_ID AND e.ENTITY_ID=g.ENTITY_ID
  JOIN FPA_PERIOD p ON p.TENANT_ID=g.TENANT_ID AND p.PERIOD_ID=g.PERIOD_ID
    AND p.RELEASE_ID=g.RELEASE_ID
  WHERE g.TENANT_ID=:tenant_id AND g.RELEASE_ID=:release_id
    AND g.POSTING_STATE='POSTED' AND g.LAYER_CODE=:layer_code
    AND p.PERIOD_START>=:period_start AND p.PERIOD_END<=:period_end
  GROUP BY g.TENANT_ID,g.ENTITY_ID,g.LEDGER_ID,g.ACCOUNT_ID,g.PERIOD_ID,g.CURRENCY
), budget AS (
  SELECT b.TENANT_ID,b.ENTITY_ID,b.LEDGER_ID,b.ACCOUNT_ID,b.PERIOD_ID,b.CURRENCY,
         SUM(b.AMOUNT) AS AMOUNT
  FROM FPA_PLAN b
  JOIN allowed e ON e.TENANT_ID=b.TENANT_ID AND e.ENTITY_ID=b.ENTITY_ID
  JOIN FPA_VERSION v ON v.TENANT_ID=b.TENANT_ID AND v.VERSION_ID=b.VERSION_ID
    AND v.RELEASE_ID=b.RELEASE_ID
  JOIN FPA_PERIOD p ON p.TENANT_ID=b.TENANT_ID AND p.PERIOD_ID=b.PERIOD_ID
    AND p.RELEASE_ID=b.RELEASE_ID
  WHERE b.TENANT_ID=:tenant_id AND b.RELEASE_ID=:release_id AND b.VERSION_ID=:version_id
    AND v.SCENARIO='BUDGET' AND v.STATE IN ('APPROVED','LOCKED')
    AND v.VINTAGE_AT<=:business_as_of AND b.SIGN_POLICY_ID=:sign_policy_id
    AND p.PERIOD_START>=:period_start AND p.PERIOD_END<=:period_end
  GROUP BY b.TENANT_ID,b.ENTITY_ID,b.LEDGER_ID,b.ACCOUNT_ID,b.PERIOD_ID,b.CURRENCY
)
SELECT COALESCE(a.ENTITY_ID,b.ENTITY_ID) AS ENTITY_ID,
       COALESCE(a.LEDGER_ID,b.LEDGER_ID) AS LEDGER_ID,
       COALESCE(a.ACCOUNT_ID,b.ACCOUNT_ID) AS ACCOUNT_ID,
       COALESCE(a.PERIOD_ID,b.PERIOD_ID) AS PERIOD_ID,
       COALESCE(a.CURRENCY,b.CURRENCY) AS CURRENCY,
       a.AMOUNT AS ACTUAL_DR,b.AMOUNT AS BUDGET_DR,
       a.AMOUNT-b.AMOUNT AS VARIANCE_DR,
       CASE WHEN a.AMOUNT IS NULL THEN 'ACTUAL_UNAVAILABLE'
            WHEN b.AMOUNT IS NULL THEN 'BUDGET_UNAVAILABLE' ELSE 'BOTH_PRESENT' END AS COVERAGE
FROM actual a FULL OUTER JOIN budget b
  ON a.TENANT_ID=b.TENANT_ID AND a.ENTITY_ID=b.ENTITY_ID
 AND a.LEDGER_ID=b.LEDGER_ID AND a.ACCOUNT_ID=b.ACCOUNT_ID
 AND a.PERIOD_ID=b.PERIOD_ID AND a.CURRENCY=b.CURRENCY;

-- TEMPLATE Q_BALANCE. A single explicitly resolved closing snapshot, never SUM across periods.
SELECT b.ENTITY_ID,b.LEDGER_ID,b.ACCOUNT_ID,b.PERIOD_ID,b.CURRENCY,b.CLOSING_DR
FROM FPA_BALANCE b
WHERE b.TENANT_ID=:tenant_id AND b.RELEASE_ID=:release_id
  AND b.PERIOD_ID=:period_id AND b.LAYER_CODE=:layer_code
  AND EXISTS (SELECT 1 FROM FPA_ENTITLEMENT e WHERE e.TENANT_ID=b.TENANT_ID
    AND e.ENTITY_ID=b.ENTITY_ID AND e.PRINCIPAL_ID=:principal_id
    AND e.PURPOSE_CODE=:purpose_code AND e.VALID_FROM<=:access_at AND e.VALID_TO>:access_at);
