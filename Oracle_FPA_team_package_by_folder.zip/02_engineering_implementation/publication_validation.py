"""Offline candidate admission. No source connector, database writer or authorization service."""
from collections import defaultdict
from datetime import date, datetime
from decimal import Decimal
import re
from reference_engine import D, ContractError, exact_calculation, require, storage_decimal

def _key(row,columns):return tuple(row.get(c) for c in columns)

@exact_calculation
def validate_publication(rows_by_table,model,release_id,mode='synthetic'):
    """Validate a complete candidate snapshot; return evidence, never production approval."""
    require(mode in ['synthetic','company_candidate'],'INVALID_ADMISSION_MODE')
    tables={t['name']:t for t in model['tables']}
    require(not (set(rows_by_table)-set(tables)),'UNKNOWN_TARGET_TABLE')
    indexes={}
    for name,table in tables.items():
        rows=rows_by_table.get(name,[]);columns={c['name']:c for c in table['columns']}
        for row in rows:
            require(not(set(row)-set(columns)),'UNKNOWN_COLUMN')
            for column in columns.values():
                value=row.get(column['name'])
                require(value is not None or column['nullable'],'MISSING_REQUIRED_COLUMN')
                if value is None:continue
                typ=column['type']
                if typ.startswith('NUMBER('):
                    precision,scale=(int(v) for v in typ[7:-1].split(','))
                    storage_decimal(value,precision,scale)
                elif typ.startswith(('VARCHAR2(','CHAR(')):
                    require(isinstance(value,str) and 0<len(value)<=int(re.search(r'\((\d+)',typ)[1]),'INVALID_TEXT_LENGTH')
                elif typ=='DATE':
                    require(isinstance(value,str),'INVALID_DATE')
                    try:date.fromisoformat(value)
                    except ValueError:raise ContractError('INVALID_DATE') from None
                elif typ.startswith('TIMESTAMP('):
                    try:instant=datetime.fromisoformat(value.replace('Z','+00:00'))
                    except (ValueError,TypeError,AttributeError):raise ContractError('INVALID_TIMESTAMP') from None
                    require(instant.tzinfo is not None,'TIMESTAMP_WITHOUT_ZONE')
                elif typ=='CLOB':require(isinstance(value,str) and bool(value),'INVALID_TEXT')
            for check in table['checks']:
                enum=re.fullmatch(r"([A-Z_]+) IN \((.+)\)",check)
                if enum and "'" in enum[2]:require(row.get(enum[1]) in re.findall(r"'([^']*)'",enum[2]),'INVALID_ENUM')
            for start,end in [('VALID_FROM','VALID_TO'),('RECORDED_FROM','RECORDED_TO'),('PERIOD_START','PERIOD_END'),('ACTUAL_CUTOFF','HORIZON_END')]:
                if start in row and end in row:
                    a,b=row[start],row[end]
                    if start.startswith('RECORDED'):a,b=(datetime.fromisoformat(v.replace('Z','+00:00')) for v in [a,b])
                    require(a<b,'INVALID_INTERVAL')
            if name=='FPA_FX_RATE':require(D(row['RATE'])>0,'INVALID_RATE')
            if name=='FPA_REPORT_MAP':require(D(row['SIGN_MULTIPLIER']) in [D(-1),D(1)],'INVALID_SIGN_MULTIPLIER')
            if name=='FPA_REPORT_LINE':
                require(D(row['INDENT_LEVEL'])>=0,'INVALID_INDENT_LEVEL')
                require(row['LINE_KIND']=='LEAF' or row.get('EXPRESSION_ID') is not None,'MISSING_REPORT_EXPRESSION')
            if name=='FPA_HIER_NODE':require((row['NODE_TYPE']=='ENTITY')==(row.get('ENTITY_ID') is not None),'INVALID_NODE_ENTITY_LINK')
        for key in [table['primary_key']]+table['unique']:
            values=[_key(row,key) for row in rows if all(row.get(c) is not None for c in key)]
            require(len(values)==len(set(values)),'DUPLICATE_TARGET_KEY')
            indexes[(name,tuple(key))]={_key(row,key):row for row in rows}
    for name,table in tables.items():
        for row in rows_by_table.get(name,[]):
            for fk in table['foreign_keys']:
                key=_key(row,fk['columns'])
                if any(v is None for v in key):continue
                require(key in indexes[(fk['target'],tuple(fk['target_columns']))],'MISSING_OR_CROSS_RELEASE_REFERENCE')
    def lookup(name,row,keys):
        return indexes[(name,tuple(keys))][_key(row,keys)]
    release=indexes[('FPA_RELEASE',('RELEASE_ID',))].get((release_id,))
    require(release is not None,'MISSING_RELEASE')
    scope=lambda name:[row for row in rows_by_table.get(name,[]) if 'RELEASE_ID' not in row or row['RELEASE_ID']==release_id]
    sources=scope('FPA_SOURCE')
    require(bool(sources),'MISSING_SOURCE')
    if mode=='synthetic':require(all(s['DATA_ORIGIN']=='SYNTHETIC' for s in sources),'SYNTHETIC_ACTUAL_MIX')
    else:
        require(all(s['DATA_ORIGIN']=='ACTUAL_SOURCE' and s['AUTHORITY_STATE']=='VERIFIED' for s in sources),'UNVERIFIED_COMPANY_SOURCE')
        require(all(t['source_binding']=='SOURCE_BOUND' for t in model['tables'] if scope(t['name'])),'UNBOUND_COMPANY_TARGET')
        require(all(row['STATUS']=='APPROVED' for row in scope('FPA_POLICY')),'UNAPPROVED_COMPANY_POLICY')
    totals=defaultdict(lambda:[0,D(0),D(0)])
    journals=defaultdict(lambda:D(0))
    for row in scope('FPA_GL_LINE'):
        ledger=lookup('FPA_LEDGER',row,['TENANT_ID','LEDGER_ID','RELEASE_ID'])
        period=lookup('FPA_PERIOD',row,['TENANT_ID','PERIOD_ID','RELEASE_ID'])
        account=lookup('FPA_ACCOUNT',row,['TENANT_ID','ACCOUNT_ID','RELEASE_ID'])
        require(ledger['CALENDAR_ID']==period['CALENDAR_ID'],'LEDGER_CALENDAR_MISMATCH')
        require(ledger['COA_ID']==account['COA_ID'],'LEDGER_ACCOUNT_CHART_MISMATCH')
        debit,credit=D(row['DEBIT']),D(row['CREDIT'])
        require(debit>=0 and credit>=0 and (debit==0 or credit==0),'INVALID_DEBIT_CREDIT')
        key=_key(row,['TENANT_ID','BATCH_ID','RELEASE_ID'])
        totals[key][0]+=1;totals[key][1]+=debit;totals[key][2]+=credit
        if row['POSTING_STATE']=='POSTED':
            journals[_key(row,['TENANT_ID','SOURCE_ID','BATCH_ID','ENTITY_ID','LEDGER_ID','PERIOD_ID','CURRENCY','JOURNAL_ID','LAYER_CODE','RELEASE_ID'])]+=debit-credit
    require(all(value==0 for value in journals.values()),'UNBALANCED_JOURNAL')
    rejected=defaultdict(int)
    for row in rows_by_table.get('FPA_QUARANTINE',[]):rejected[_key(row,['TENANT_ID','BATCH_ID','RELEASE_ID'])]+=1
    for batch in scope('FPA_BATCH'):
        key=_key(batch,['TENANT_ID','BATCH_ID','RELEASE_ID'])
        require(int(D(batch['INPUT_ROWS']))==int(D(batch['ACCEPTED_ROWS']))+int(D(batch['REJECTED_ROWS'])),'ROW_CONTROL_MISMATCH')
        require(all(D(batch[c])>=0 for c in ['INPUT_ROWS','ACCEPTED_ROWS','REJECTED_ROWS','INPUT_DEBIT','INPUT_CREDIT']),'NEGATIVE_BATCH_CONTROL')
        require(rejected[key]==int(D(batch['REJECTED_ROWS'])),'QUARANTINE_COUNT_MISMATCH')
        require(key in totals,'UNSUPPORTED_OR_EMPTY_BATCH_SCOPE')
        count,debit,credit=totals[key]
        require(count==int(D(batch['ACCEPTED_ROWS'])),'ACCEPTED_COUNT_MISMATCH')
        # Rejected amounts require explicit control adjustment; never certify an unexplained gap.
        require(D(batch['REJECTED_ROWS'])==0,'REJECTED_AMOUNT_RECONCILIATION_REQUIRED')
        require(debit==D(batch['INPUT_DEBIT']) and credit==D(batch['INPUT_CREDIT']),'BATCH_AMOUNT_MISMATCH')
    for name in ['FPA_PLAN','FPA_PLAN_LINE','FPA_BALANCE','FPA_COVERAGE']:
        for row in scope(name):
            ledger=lookup('FPA_LEDGER',row,['TENANT_ID','LEDGER_ID','RELEASE_ID'])
            period=lookup('FPA_PERIOD',row,['TENANT_ID','PERIOD_ID','RELEASE_ID'])
            require(ledger['CALENDAR_ID']==period['CALENDAR_ID'],'LEDGER_CALENDAR_MISMATCH')
            if 'ACCOUNT_ID' in row:
                account=lookup('FPA_ACCOUNT',row,['TENANT_ID','ACCOUNT_ID','RELEASE_ID'])
                require(ledger['COA_ID']==account['COA_ID'],'LEDGER_ACCOUNT_CHART_MISMATCH')
            if name=='FPA_BALANCE':require(D(row['OPENING_DR'])+D(row['MOVEMENT_DR'])==D(row['CLOSING_DR']),'BALANCE_BRIDGE_MISMATCH')
            if name=='FPA_COVERAGE' and row['COVERAGE_STATE'] in ['COMPLETE','ZERO_ACTIVITY']:
                require(row.get('COMPLETE_THROUGH') is not None,'MISSING_COMPLETENESS_WATERMARK')
    for name in ['FPA_ENTITY_VER','FPA_REPORT_MAP']:
        rows=scope(name)
        group=['TENANT_ID','ENTITY_ID','RELEASE_ID'] if name=='FPA_ENTITY_VER' else ['TENANT_ID','ACCOUNT_ID','POLICY_ID','RELEASE_ID']
        for i,a in enumerate(rows):
            for b in rows[i+1:]:
                if _key(a,group)!=_key(b,group):continue
                overlap=a['VALID_FROM']<b['VALID_TO'] and b['VALID_FROM']<a['VALID_TO']
                if name=='FPA_ENTITY_VER':
                    inst=lambda value:datetime.fromisoformat(value.replace('Z','+00:00'))
                    overlap=overlap and inst(a['RECORDED_FROM'])<inst(b['RECORDED_TO']) and inst(b['RECORDED_FROM'])<inst(a['RECORDED_TO'])
                require(not overlap,'OVERLAPPING_INTERVAL')
    # This supported core gate cannot certify arbitrary future extension domains.
    require(not scope('FPA_HIER_EDGE') and not scope('FPA_ASSUMPTION'),'UNSUPPORTED_ADMISSION_DOMAIN')
    return dict(status='validated_candidate',release_id=release_id,mode=mode,rows_checked=sum(len(v) for v in rows_by_table.values()),production_approved=False,native_enforcement='NOT_RUN')

if __name__=='__main__':
    import argparse,json,pathlib
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True)
    parser.add_argument('--mode',choices=['synthetic','company_candidate'],default='synthetic')
    args=parser.parse_args()
    p=pathlib.Path(__file__).resolve().parent
    candidate=json.loads(pathlib.Path(args.input).read_text(encoding='utf-8'))
    print(json.dumps(validate_publication(candidate['tables'],json.loads((p/'canonical_model.json').read_text()),candidate['release_id'],args.mode)))
