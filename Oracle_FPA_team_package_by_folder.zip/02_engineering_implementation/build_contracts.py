"""Publish internal JSON contracts and examples, never native vendor configuration."""
import csv,json,pathlib
P=pathlib.Path(__file__).resolve().parent
def save(n,x):(P/n).write_text(json.dumps(x,indent=2),encoding='utf-8')
def obj(props,required=None):return dict(type='object',properties=props,required=list(props) if required is None else required,additionalProperties=False)
def arr(items):return dict(type='array',items=items)
string=dict(type='string',minLength=1);strings=arr(string)
decimal=dict(type='string',pattern=r'^-?(0|[1-9][0-9]*)(\.[0-9]+)?$')
timestamp=dict(type='string',format='date-time');date=dict(type='string',format='date')
metric_ref=obj(dict(id=string,version=dict(type='integer',minimum=1)))
time=obj(dict(calendar_policy_ref=string,date_role=dict(enum=['posting','accounting_period','snapshot']),period_start=date,period_end=date,business_as_of=timestamp,close_policy_ref=string,completeness_ref=string))
scenario=obj(dict(scenario=dict(enum=['ACTUAL','BUDGET','FORECAST','WHAT_IF']),version_ref=string),['scenario'])
scenario['allOf']=[dict(if_={})] if False else [{'if':{'properties':{'scenario':{'enum':['BUDGET','FORECAST','WHAT_IF']}}},'then':{'required':['version_ref']}}]
intent=obj(dict(request_id=string,effective_identity_ref=string,tenant_scope_ref=string,release_id=string,mode=dict(enum=['proposed_exploration','certified']),metric_refs=dict(type='array',items=metric_ref,minItems=1),entity_filters=strings,requested_grain=dict(type='array',items=dict(enum=['entity','ledger','account','period','currency','reporting_line']),minItems=1,uniqueItems=True),time_context=time,scenario_context=scenario,currency_context=obj(dict(output_currency=dict(type='string',pattern='^[A-Z]{3}$'),translation_policy_ref=string)),reporting_context=obj(dict(basis_policy_ref=string,hierarchy_version_ref=string,consolidation_scope_ref=string),['basis_policy_ref']),comparison_policy_ref=string,defaults_applied=strings,unresolved_choices=strings,requested_limit=dict(type='integer',minimum=1,maximum=10000)),['request_id','effective_identity_ref','tenant_scope_ref','release_id','mode','metric_refs','entity_filters','requested_grain','time_context','scenario_context','reporting_context','defaults_applied','unresolved_choices','requested_limit'])
intent['allOf']=[{'if':{'properties':{'mode':{'const':'certified'}}},'then':{'properties':{'unresolved_choices':{'maxItems':0}}}}]
intent['$schema']='https://json-schema.org/draft/2020-12/schema'
save('intent.schema.json',intent)
result=obj(dict(status=dict(enum=['success','partial']),execution_id=string,release_id=string,snapshot_ref=string,resolved_intent=string,metric_refs=arr(metric_ref),rows=arr(obj(dict(key=string,value={'oneOf':[decimal,{'type':'null'}]},unit=string))),full_population_totals=arr(obj(dict(metric_id=string,value={'oneOf':[decimal,{'type':'null'}]},unit=string))),row_count=dict(type='integer',minimum=0),complete_row_count={'type':['integer','null'],'minimum':0},truncated=dict(type='boolean'),next_page_ref={'type':['string','null']},warnings=strings,validation_state=dict(enum=['synthetic_passed','proposed_unreconciled','source_reconciled']),source_watermarks=arr(obj(dict(source_id=string,complete_through=timestamp))),defaults_applied=strings,limitations=strings,policy_refs=strings,access_revision=string))
result['allOf']=[{'if':{'properties':{'status':{'const':'success'}}},'then':{'properties':{'truncated':{'const':False}}}},{'if':{'properties':{'truncated':{'const':True}}},'then':{'properties':{'status':{'const':'partial'}}}}]
stops=[]
for status in ['clarification_required','unsupported','unauthorized','awaiting_data','failure']:
    stops.append(obj(dict(status=dict(const=status),request_id=string,message=string,choices=strings)))
save('answer.schema.json',{'$schema':'https://json-schema.org/draft/2020-12/schema','oneOf':[result]+stops})
policy=obj(dict(id=string,definition=string,status=dict(enum=['proposed','approved','retired']),version=dict(type='integer',minimum=1),owner=string,source_binding=dict(enum=['UNBOUND','SOURCE_BOUND'])))
save('policy.schema.json',dict(**policy,**{'$schema':'https://json-schema.org/draft/2020-12/schema'}))
column=obj(dict(name=string,type=string,description=string,nullable=dict(type='boolean'),default={'type':['string','number','null']},source_binding=dict(enum=['UNBOUND','SOURCE_BOUND']),sensitivity=string,test_refs=strings))
foreign_key=obj(dict(columns=strings,target=string,target_columns=strings,cardinality=dict(const='many_to_one'),tenant_required=dict(type='boolean'),enforcement=string))
table_contract=obj(dict(id=string,name=string,grain=string,description=string,columns=dict(type='array',items=column,minItems=1),primary_key=dict(type='array',items=string,minItems=1),unique=arr(strings),checks=strings,history=string,source_binding=dict(enum=['UNBOUND','SOURCE_BOUND']),owner=string,status=dict(enum=['proposed','validated','approved','retired']),foreign_keys=arr(foreign_key)))
metric_contract=obj(dict(id=string,name=string,status=dict(enum=['proposed','approved','retired']),version=dict(type='integer',minimum=1),policy_ids=dict(type='array',items=string,minItems=1),owner=string,approver=string,source_binding=dict(enum=['UNBOUND','SOURCE_BOUND']),expression=obj(dict(id=string,operator=dict(enum=['sum_report_line','subtract','divide','approved_recipe','closing_balance','versioned_plan']),input_metric_ids=strings,report_lines=strings,output_unit=dict(enum=['currency','fraction']),rounding=string,missingness=string)),grain=strings,allowed_dimensions=strings,forbidden_dimensions=strings,aggregation=obj(dict(entity=string,time=string,currency=string)),calculation_scope=obj(dict(security=string,numerator=string,denominator=string,window=string,totals=string,ranking=string,display_limit=string)),synonyms=strings,not_synonyms=strings,lineage_ids=strings,tests=strings,certifiable=dict(type='boolean')))
save('metric.schema.json',dict(**metric_contract,**{'$schema':'https://json-schema.org/draft/2020-12/schema'}))
save('table.schema.json',dict(**table_contract,**{'$schema':'https://json-schema.org/draft/2020-12/schema'}))
binding=obj(dict(target=string,state=dict(enum=['UNBOUND','SOURCE_BOUND']),source_product={'type':['string','null']},source_schema={'type':['string','null']},source_object={'type':['string','null']},column_map=dict(type='object',additionalProperties={'type':'string'}),effective_from={'type':['string','null']},validation_evidence={'type':['string','null']}))
binding['allOf']=[{'if':{'properties':{'state':{'const':'SOURCE_BOUND'}}},'then':{'properties':{'source_product':string,'source_object':string,'column_map':{'minProperties':1},'validation_evidence':string}}}]
save('source_binding.schema.json',dict(**binding,**{'$schema':'https://json-schema.org/draft/2020-12/schema'}))
vector=obj(dict(chunk_id=string,object_id=string,object_type=string,domain=string,tenant_scope=string,security_policy_refs=strings,approved_text_ref=string,content_hash=dict(type='string',pattern='^[a-f0-9]{64}$'),definition_version=dict(type='integer',minimum=1),valid_from=timestamp,valid_to=timestamp,approval=dict(const='approved'),authority_ref=string,provenance_ref=string,locale=string,sensitivity=string,embedding_model=string,embedding_version=string,vector_dimensions=dict(type='integer',minimum=1),distance_metric=dict(enum=['cosine','euclidean','inner_product']),embedding_at=timestamp,index_generation=string,tombstone=dict(type='boolean')))
save('vector_record.schema.json',dict(**vector,**{'$schema':'https://json-schema.org/draft/2020-12/schema'}))
node=obj(dict(id=string,type=dict(enum=['Metric','Fact','Dimension','Column','Account','ReportingLine','Entity','HierarchyVersion','Policy','ScenarioVersion','Driver','Assumption','Transformation','Source','OwnerRole','VerifiedQuery','TestCase']),version=dict(type='integer',minimum=1),definition=string,provenance=strings,valid_from=timestamp,valid_to=timestamp,approval=dict(enum=['proposed','approved','retired']),security_policy_refs=strings,release_id=string))
edge=obj(dict(id=string,type=dict(enum=['depends_on','governed_by','calculated_from','maps_to','approved_by','member_of','tested_by','hypothesized_driver_of']),from_id=string,to_id=string,from_version=dict(type='integer',minimum=1),to_version=dict(type='integer',minimum=1),valid_from=timestamp,valid_to=timestamp,provenance=strings,approval=dict(enum=['proposed','approved','retired']),properties=dict(type='object'),security_policy_refs=strings,release_id=string))
save('graph.schema.json',dict(**obj(dict(nodes=arr(node),edges=arr(edge))),**{'$schema':'https://json-schema.org/draft/2020-12/schema'}))
example=dict(request_id='synthetic-request-001',effective_identity_ref='trusted-session/T1/analyst',tenant_scope_ref='T1',release_id='reference-2026-11-01-02',mode='proposed_exploration',metric_refs=[dict(id='metric.revenue',version=1)],entity_filters=['E1','E2'],requested_grain=['period','currency'],time_context=dict(calendar_policy_ref='fixture.calendar',date_role='accounting_period',period_start='2026-01-01',period_end='2026-02-01',business_as_of='2026-02-20T00:00:00Z',close_policy_ref='fixture.close',completeness_ref='synthetic-fixture-1'),scenario_context=dict(scenario='ACTUAL'),currency_context=dict(output_currency='USD',translation_policy_ref='fixture.fx'),reporting_context=dict(basis_policy_ref='fixture.management'),defaults_applied=[],unresolved_choices=[],requested_limit=100)
save('intent.valid.json',example)
invalid=dict(example,mode='certified',unresolved_choices=['approved company calendar unavailable'])
save('intent.invalid.json',invalid)
answer=dict(status='success',execution_id='offline-Q005',release_id=example['release_id'],snapshot_ref='synthetic-fixture-1',resolved_intent='synthetic-request-001',metric_refs=example['metric_refs'],rows=[dict(key='2026-01/USD',value='300',unit='USD')],full_population_totals=[dict(metric_id='metric.revenue',value='300',unit='USD')],row_count=1,complete_row_count=1,truncated=False,next_page_ref=None,warnings=[],validation_state='synthetic_passed',source_watermarks=[dict(source_id='SYNTHETIC',complete_through='2026-02-01T00:00:00Z')],defaults_applied=[],limitations=['Synthetic only. No company certification or native Oracle execution.'],policy_refs=['fixture.calendar','fixture.fx','fixture.sign'],access_revision='synthetic-current-1')
save('answer.valid.json',answer)
save('answer.stop.json',dict(status='awaiting_data',request_id='company-request-001',message='The original approved source and metric policy are unavailable.',choices=[]))
start='2026-01-01T00:00:00Z';end='9999-12-31T00:00:00Z'
model=json.loads((P/'canonical_model.json').read_text(encoding='utf-8'))
nodes=[];edges=[]
for m in model['metrics']:
    nodes.append(dict(id=m['id'],type='Metric',version=1,definition=m['name'],provenance=['canonical_model.json#'+m['id']],valid_from=start,valid_to=end,approval='proposed',security_policy_refs=['design.confidential_finance'],release_id=example['release_id']))
for t in model['tables']:
    types={'FPA_GL_LINE':'Fact','FPA_BALANCE':'Fact','FPA_PLAN':'Fact','FPA_PLAN_LINE':'Fact','FPA_ENTITY_ID':'Dimension','FPA_FX_RATE':'Fact','FPA_SOURCE':'Source','FPA_POLICY':'Policy','FPA_ENTITY':'Entity','FPA_ENTITY_VER':'Dimension','FPA_ACCOUNT':'Account','FPA_PERIOD':'Dimension','FPA_LEDGER':'Dimension','FPA_VERSION':'ScenarioVersion','FPA_CALENDAR':'Dimension','FPA_CURRENCY':'Dimension','FPA_HIER_VERSION':'HierarchyVersion','FPA_HIER_NODE':'Dimension','FPA_REPORT_LINE':'ReportingLine','FPA_ASSUMPTION':'Assumption'}
    if t['name'] not in types:continue
    nodes.append(dict(id=t['id'],type=types[t['name']],version=1,definition=t['description'],provenance=['canonical_model.json#'+t['id']],valid_from=start,valid_to=end,approval='proposed',security_policy_refs=['design.confidential_finance'],release_id=example['release_id']))
for m in model['metrics']:
    for target in m['expression']['input_metric_ids']+m['lineage_ids']:
        edges.append(dict(id='edge.'+str(len(edges)+1),type='depends_on',from_id=m['id'],to_id=target,from_version=1,to_version=1,valid_from=start,valid_to=end,provenance=['canonical_model.json#'+m['id']],approval='proposed',properties={},security_policy_refs=['design.confidential_finance'],release_id=example['release_id']))
save('graph.proposed.json',dict(nodes=nodes,edges=edges))
parameters=[]
def walk(properties,path=''):
    for k,v in properties.items():
        ref=path+k
        parameters.append(dict(parameter_id=ref,scope='runtime',meaning=k.replace('_',' '),type=v.get('type','conditional'),allowed_values=json.dumps(v.get('enum',[])),requiredness='see JSON Schema conditional required rules',authority='trusted authentication/policy service' if k in ['effective_identity_ref','tenant_scope_ref'] else 'governed release/context resolution',owner='security' if k in ['effective_identity_ref','tenant_scope_ref'] else 'semantic_engineering',default='none unless explicit approved release default',validation='intent.schema.json and semantic admission checks',missing_behavior='block affected numeric answer or request clarification',consumer='intent resolver/compiler'))
        if 'properties' in v:walk(v['properties'],ref+'.')
walk(intent['properties'])
for k in ['release_id','model_hash','policy_versions','data_snapshot','index_generation','embedding_model','access_revision']:
    parameters.append(dict(parameter_id='publication.'+k,scope='release_time' if k!='model_hash' else 'design_time',meaning=k.replace('_',' '),type='string',allowed_values='registry-bound',requiredness='conditional to selected store',authority='canonical release publisher',owner='data_governance',default='none',validation='compatible-release and content-hash check',missing_behavior='block dependent publication',consumer='publisher/cache/retrieval'))
with (P/'parameter_dictionary.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(parameters[0]));w.writeheader();w.writerows(parameters)
print(json.dumps({'schemas':9,'graph_nodes':len(nodes),'graph_edges':len(edges),'runtime_parameters':len(parameters)}))
