"""Regression evidence for audit F01–F08. Portable relational probes are not Oracle tests."""
from pathlib import Path
from decimal import Decimal, localcontext
import copy,datetime,json,sqlite3,sys
from reference_engine import ContractError,D,evaluate,storage_decimal,idempotent,validate_model,allocate,ratio
from publication_validation import validate_publication
P=Path(__file__).resolve().parent
load=lambda name:json.loads((P/name).read_text(encoding='utf-8'))
model=load('canonical_model.json');fixture=load('publication_fixture.json');results=[]
def check(name,fn):
    try:fn();results.append(dict(id=name,passed=True))
    except Exception as exc:results.append(dict(id=name,passed=False,error=repr(exc)))
def reject(fn,code):
    try:fn()
    except ContractError as exc:assert str(exc)==code,(str(exc),code);return
    raise AssertionError('Expected rejection '+code)
def run(rows):return validate_publication(rows,model,fixture['release_id'])
def changed(name,column,value,code):
    rows=copy.deepcopy(fixture['tables']);rows[name][0][column]=value
    reject(lambda:run(rows),code)

def database():
    db=sqlite3.connect(':memory:');db.execute('PRAGMA foreign_keys=ON')
    for t in model['tables']:
        cols=['"'+c['name']+'" '+('NUMERIC' if c['type'].startswith('NUMBER') else 'TEXT')+(' NOT NULL' if not c['nullable'] else '') for c in t['columns']]
        cols+=['PRIMARY KEY ('+','.join(t['primary_key'])+')']
        cols+=['UNIQUE ('+','.join(key)+')' for key in t['unique']]
        cols+=['CHECK ('+c+')' for c in t['checks']]
        cols+=['FOREIGN KEY ('+','.join(f['columns'])+') REFERENCES '+f['target']+' ('+','.join(f['target_columns'])+')' for f in t['foreign_keys']]
        db.execute('CREATE TABLE '+t['name']+' ('+','.join(cols)+')')
    return db
def insert(db,name,row):db.execute('INSERT INTO '+name+' ('+','.join(row)+') VALUES ('+','.join('?' for _ in row)+')',list(row.values()))
def populate(db,rows):
    # FK dependency order is derived from the model, not from seed dictionary order.
    pending=dict(rows);loaded=set()
    while pending:
        ready=[name for name in pending if all(f['target'] in loaded or f['target']==name or f['target'] not in rows for f in next(t for t in model['tables'] if t['name']==name)['foreign_keys'])]
        assert ready,'Unresolvable FK dependency order'
        for name in ready:
            for row in pending.pop(name):insert(db,name,row)
            loaded.add(name)

def releases():
    rows=copy.deepcopy(fixture['tables']);r1=fixture['release_id'];r2=r1+'-restated'
    for name in list(rows):
        if any(c['name']=='RELEASE_ID' for c in next(t for t in model['tables'] if t['name']==name)['columns']):
            rows[name]+=[dict(row,RELEASE_ID=r2) for row in list(rows[name])]
    validate_publication(rows,model,r1);validate_publication(rows,model,r2)
    db=database();populate(db,rows)
    for release in [r1,r2]:
        assert db.execute('SELECT COUNT(*) FROM FPA_GL_LINE g JOIN FPA_PERIOD p ON p.TENANT_ID=g.TENANT_ID AND p.PERIOD_ID=g.PERIOD_ID AND p.RELEASE_ID=g.RELEASE_ID WHERE g.RELEASE_ID=?',(release,)).fetchone()[0]==28
    assert db.execute('SELECT COUNT(*) FROM FPA_ENTITLEMENT').fetchone()[0]==2
check('F01_TWO_RELEASES_RETAIN_ALL_FACTS_AND_CURRENT_RIGHTS',releases)
check('F04_VALID_SYNTHETIC_PUBLICATION',lambda:run(fixture['tables']))
check('F04_CROSS_RELEASE_REFERENCE_REJECTED',lambda:changed('FPA_GL_LINE','RELEASE_ID','missing','MISSING_OR_CROSS_RELEASE_REFERENCE'))
check('F04_ENTITY_CURRENCY_MISMATCH_REJECTED',lambda:changed('FPA_ENTITY','FUNCTIONAL_CCY','EUR','MISSING_OR_CROSS_RELEASE_REFERENCE'))
check('F04_BATCH_CURRENCY_MISMATCH_REJECTED',lambda:changed('FPA_BATCH','CONTROL_CCY','EUR','MISSING_OR_CROSS_RELEASE_REFERENCE'))
check('F04_CHART_MISMATCH_REJECTED',lambda:changed('FPA_LEDGER','COA_ID','different','LEDGER_ACCOUNT_CHART_MISMATCH'))
def calendar_mismatch():
    rows=copy.deepcopy(fixture['tables']);calendar=dict(rows['FPA_CALENDAR'][0],CALENDAR_ID='other')
    rows['FPA_CALENDAR'].append(calendar);rows['FPA_LEDGER'][0]['CALENDAR_ID']='other'
    reject(lambda:run(rows),'LEDGER_CALENDAR_MISMATCH')
check('F04_LEDGER_CALENDAR_MISMATCH_REJECTED',calendar_mismatch)
check('F04_BATCH_COUNT_MISMATCH_REJECTED',lambda:changed('FPA_BATCH','INPUT_ROWS',999,'ROW_CONTROL_MISMATCH'))
check('F04_BATCH_AMOUNT_MISMATCH_REJECTED',lambda:changed('FPA_BATCH','INPUT_DEBIT','999','BATCH_AMOUNT_MISMATCH'))
check('F04_MIXED_ORIGIN_REJECTED',lambda:changed('FPA_SOURCE','DATA_ORIGIN','ACTUAL_SOURCE','SYNTHETIC_ACTUAL_MIX'))
def overlap():
    rows=copy.deepcopy(fixture['tables']);rows['FPA_ENTITY_VER'].append(dict(rows['FPA_ENTITY_VER'][0],ENTITY_VER_ID='overlap'))
    reject(lambda:run(rows),'OVERLAPPING_INTERVAL')
check('F04_OVERLAPPING_ENTITY_HISTORY_REJECTED',overlap)
check('F04_COMPANY_MODE_REQUIRES_VERIFIED_SOURCE',lambda:reject(lambda:validate_publication(fixture['tables'],model,fixture['release_id'],'company_candidate'),'UNVERIFIED_COMPANY_SOURCE'))
def plan_line():
    table=next(t for t in model['tables'] if t['name']=='FPA_PLAN_LINE')
    assert 'ACCOUNT_ID' not in {c['name'] for c in table['columns']}
    rows=copy.deepcopy(fixture['tables']);rows['FPA_PLAN']=[]
    assert run(rows)['status']=='validated_candidate'
    db=database();populate(db,rows)
    assert db.execute('SELECT COUNT(*) FROM FPA_PLAN_LINE').fetchone()[0]==1
check('F02_NATIVE_REPORT_LINE_PLAN_WITHOUT_ACCOUNT_ALLOCATION',plan_line)
def coverage():
    rows=copy.deepcopy(fixture['tables']);rows['FPA_LEDGER'].append(dict(rows['FPA_LEDGER'][0],LEDGER_ID='L2'))
    item=dict(TENANT_ID='T1',SOURCE_ID='SYNTHETIC',ENTITY_ID='E1',LEDGER_ID='L1',PERIOD_ID='2026-01',CURRENCY='USD',COVERAGE_STATE='COMPLETE',CLOSE_STATE='HARD_CLOSED',COMPLETE_THROUGH='2026-02-01T00:00:00+00:00',EVIDENCE_REF='synthetic',RELEASE_ID=fixture['release_id'])
    rows['FPA_COVERAGE']=[item,dict(item,LEDGER_ID='L2',COVERAGE_STATE='PARTIAL',CLOSE_STATE='OPEN')]
    run(rows);db=database();populate(db,rows)
    assert db.execute('SELECT COUNT(*) FROM FPA_COVERAGE').fetchone()[0]==2
check('F03_DISTINCT_LEDGER_COMPLETENESS_STATES',coverage)
def precision():
    amount='99999999999999999999.12345678'
    with localcontext() as ctx:
        ctx.prec=10
        value=evaluate(dict(operation='bridge',arguments=dict(opening=amount,movements=[amount])),{},model)
    assert str(value)=='199999999999999999998.24691356'
    reject(lambda:storage_decimal(value),'AMOUNT_OUT_OF_RANGE')
check('F05_CALLER_CONTEXT_INDEPENDENT_AND_STORAGE_RANGE_CHECKED',precision)
check('F05_NONFINITE_REJECTED',lambda:reject(lambda:ratio('Infinity','2'),'NONFINITE_DECIMAL'))
check('F05_NAN_REJECTED',lambda:reject(lambda:ratio('NaN','2'),'NONFINITE_DECIMAL'))
check('F05_FLOAT_INPUT_REJECTED',lambda:reject(lambda:ratio(0.1,'2'),'INVALID_DECIMAL_TYPE'))
check('F05_STORAGE_SCALE_LOSS_REJECTED',lambda:reject(lambda:storage_decimal('.000000001'),'AMOUNT_SCALE_LOSS'))
def replay():
    row=dict(tenant='T',source='S',ledger='L',journal='J',line=1,release='R1',debit='1',batch='B1')
    assert len(idempotent([row,dict(row,batch='B2'),dict(row,release='R2',debit='2')]))==2
    reject(lambda:idempotent([row,dict(row,debit='2')]),'CONFLICTING_REPLAY')
    reject(lambda:idempotent([{k:v for k,v in row.items() if k!='release'}]),'MISSING_REPLAY_RELEASE')
check('F06_REPLAY_RELEASE_AND_TRANSPORT_BOUNDARIES',replay)
def certification():
    m=copy.deepcopy(model)
    for policy in m['policies']:policy.update(status='approved',source_binding='SOURCE_BOUND')
    for table in m['tables']:table.update(status='approved',source_binding='SOURCE_BOUND')
    metric=next(x for x in m['metrics'] if x['id']=='metric.gross_profit')
    metric.update(status='approved',source_binding='SOURCE_BOUND',certifiable=True)
    reject(lambda:validate_model(m),'UNAPPROVED_DEPENDENCY')
    for x in m['metrics']:
        if x['id'] in ['metric.revenue','metric.cogs']:x.update(status='approved',source_binding='SOURCE_BOUND')
    assert validate_model(m)
    next(t for t in m['tables'] if t['name']=='FPA_GL_LINE')['source_binding']='UNBOUND'
    reject(lambda:validate_model(m),'UNBOUND_CERTIFICATION_LINEAGE')
check('F07_CERTIFICATION_REQUIRES_TRANSITIVE_APPROVAL_AND_LINEAGE',certification)
def allocation():
    weights=['.25']*4+['0']
    values=allocate('.06',weights)
    assert values==[D('.02'),D('.02'),D('.01'),D('.01'),D(0)]
    assert sum(values)==D('.06') and all(v>=0 for v in values)
    assert allocate('-.06',weights)==[-v for v in values]
    assert all(v==0 for v in allocate('0',weights))
    reject(lambda:allocate('.001',weights),'POOL_NOT_MINOR_UNIT_ALIGNED')
check('F08_ALLOCATION_ELIGIBILITY_SIGN_AND_RESIDUAL',allocation)
def native_line_query_shape():
    import re
    db=database();populate(db,fixture['tables'])
    sql=(P/'oracle_queries.sql').read_text().split('-- TEMPLATE Q_ACTUAL_PLAN_LINE.')[1]
    sql=sql[sql.index('WITH allowed'):]
    # Portable shape probe for UTC fixture only, not Oracle timezone/native syntax validation.
    sql=re.sub(r'CAST\(g.POSTED_AT AT TIME ZONE :business_timezone AS DATE\)',"substr(g.POSTED_AT,1,10)",sql)
    binds=dict(tenant_id='T1',principal_id='synthetic_analyst',purpose_code='fixture_test',access_at='2026-02-01T00:00:00+00:00',mapping_policy_id='fixture.reporting',release_id=fixture['release_id'],layer_code='INPUT',period_start='2026-01-01',period_end='2026-02-01',version_id='BUDGET1',sign_policy_id='fixture.sign',business_as_of='2026-02-01T00:00:00+00:00')
    rows=db.execute(sql,binds).fetchall()
    e1=next(row for row in rows if row[0]=='E1')
    assert e1[-3:]==(-120,-110,-10)
    assert next(row for row in rows if row[0]=='E2')[-2] is None
check('F02_REPORT_LINE_QUERY_COMMON_GRAIN_AND_UNMATCHED_ACTUAL',native_line_query_shape)
check('F04_NEGATIVE_FX_REJECTED',lambda:changed('FPA_FX_RATE','RATE','-1','INVALID_RATE'))
def model_counts():
    assert len(model['tables'])==29 and sum(len(t['columns']) for t in model['tables'])==248
    assert len(model['metrics'])==15 and not any(m['certifiable'] for m in model['metrics'])
    assert all(s['state']=='UNBOUND' for s in load('configuration.json')['source_bindings'])
check('CORRECTED_COUNTS_AND_UNAPPROVED_STATUS',model_counts)
report=dict(release_id=model['release_id'],executed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=results,passed=sum(r['passed'] for r in results),total=len(results),scope='Offline F01-F08 correction regressions; SQLite key/check probes are not native Oracle tests; no company approval')
(P/'correction_test_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if all(r['passed'] for r in results) else 1)
