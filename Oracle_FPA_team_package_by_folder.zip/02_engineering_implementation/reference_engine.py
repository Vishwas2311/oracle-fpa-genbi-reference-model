"""Bounded offline reference calculations. No SQL executor, NLP model, or live security implementation."""
from decimal import Decimal, localcontext, ROUND_HALF_EVEN, ROUND_DOWN, InvalidOperation
from functools import wraps
import json, pathlib
class ContractError(ValueError): pass
def require(ok,code):
    if not ok: raise ContractError(code)
def D(value):
    require(isinstance(value,(str,int,Decimal)) and not isinstance(value,bool),'INVALID_DECIMAL_TYPE')
    try:result=Decimal(value)
    except InvalidOperation:raise ContractError('INVALID_DECIMAL') from None
    require(result.is_finite(),'NONFINITE_DECIMAL')
    return result

def exact_calculation(fn):
    @wraps(fn)
    def checked(*args,**kwargs):
        with localcontext() as ctx:
            ctx.prec=38;ctx.rounding=ROUND_HALF_EVEN
            return fn(*args,**kwargs)
    return checked

@exact_calculation
def storage_decimal(value,precision=28,scale=8):
    number=D(value)
    require(abs(number)<D(10)**(precision-scale),'AMOUNT_OUT_OF_RANGE')
    require(number==number.quantize(D(10)**(-scale)),'AMOUNT_SCALE_LOSS')
    return number

@exact_calculation
def allocate(pool,weights):
    """Proposed fixture policy: signed cents, largest remainder, input-order ties."""
    pool=D(pool);weights=list(map(D,weights));cent=D('.01')
    storage_decimal(pool)
    require(bool(weights),'NO_ELIGIBLE_TARGET')
    require(all(w>=0 for w in weights) and sum(weights)==1,'INVALID_WEIGHTS')
    require(pool==pool.quantize(cent),'POOL_NOT_MINOR_UNIT_ALIGNED')
    raw=[abs(pool)*w for w in weights]
    allocated=[value.quantize(cent,rounding=ROUND_DOWN) for value in raw]
    residual=int((abs(pool)-sum(allocated))/cent)
    order=sorted((i for i,w in enumerate(weights) if w>0),key=lambda i:(-(raw[i]-allocated[i]),i))
    require(residual<=len(order),'ALLOCATION_ROUNDING_OVERFLOW')
    for i in order[:residual]:allocated[i]+=cent
    return [value if pool>=0 else -value for value in allocated]

@exact_calculation
def ratio(a,b):
    if a is None or b is None: return None
    return None if D(b)==0 else D(a)/D(b)
@exact_calculation
def variance(a,b):
    if a is None or b is None: return {'absolute':None,'fraction':None}
    a,b=D(a),D(b)
    return {'absolute':a-b,'fraction':None if b==0 else (a-b)/abs(b)}
@exact_calculation
def fx(amount,source,target,date,rates):
    if source==target: return D(amount)
    matches=[r for r in rates if (r['from'],r['to'],r['date'])==(source,target,date)]
    require(len(matches)==1,'MISSING_OR_AMBIGUOUS_RATE')
    require(D(matches[0]['rate'])>0,'INVALID_RATE')
    return D(amount)*D(matches[0]['rate'])
@exact_calculation
def totals(fixture,period,entity=None,converted=False):
    rows=[r for r in fixture['journals'] if r['period']==period and (entity is None or r['entity']==entity)]
    require(bool(rows),'NO_ROWS')
    require(len({(r['tenant'],r['ledger']) for r in rows})==1,'MULTIPLE_TENANT_OR_LEDGER_SCOPES')
    if not converted: require(len({r['currency'] for r in rows})==1,'MIXED_CURRENCIES')
    result={'revenue':D(0),'cogs':D(0)}
    for r in rows:
        if r['account'] in ['REV','COGS']:
            a=D(r['credit'])-D(r['debit']) if r['account']=='REV' else D(r['debit'])-D(r['credit'])
            if converted:a=fx(a,r['currency'],'USD',period,fixture['fx'])
            result['revenue' if r['account']=='REV' else 'cogs']+=a
    result['profit']=result['revenue']-result['cogs']; result['margin']=ratio(result['profit'],result['revenue'])
    return result
@exact_calculation
def balanced(rows):
    groups={}
    for r in rows:
        k=tuple(r[x] for x in ['tenant','entity','ledger','period','currency','journal'])
        groups[k]=groups.get(k,D(0))+D(r['debit'])-D(r['credit'])
    return all(v==0 for v in groups.values())
@exact_calculation
def trial_balance(rows):
    groups={}
    for r in rows:
        k=(r['tenant'],r['ledger'],r['entity'],r['currency'],r['account'])
        groups[k]=groups.get(k,D(0))+D(r['debit'])-D(r['credit'])
    return groups
@exact_calculation
def compare(actual,budget):
    require(len({r['key'] for r in actual})==len(actual),'DUPLICATE_COMPARISON_KEY')
    require(len({r['key'] for r in budget})==len(budget),'DUPLICATE_COMPARISON_KEY')
    a={r['key']:r['amount'] for r in actual}; b={r['key']:r['amount'] for r in budget}
    return [dict(key=k,actual=a.get(k),budget=b.get(k),**variance(a.get(k),b.get(k))) for k in sorted(a.keys()|b.keys())]
def latest_version(versions,asof,entity):
    eligible=[v for v in versions if v['entity']==entity and v['state']=='APPROVED' and v['available_at']<=asof]
    require(bool(eligible),'NO_APPROVED_VINTAGE')
    latest=max(v['available_at'] for v in eligible)
    matches=[v for v in eligible if v['available_at']==latest]
    require(len(matches)==1,'AMBIGUOUS_VINTAGE')
    return matches[0]
@exact_calculation
def stitch(actual,forecast,cutoff):
    require(len({r['period'] for r in actual})==len(actual),'DUPLICATE_ACTUAL_PERIOD')
    require(len({r['period'] for r in forecast})==len(forecast),'DUPLICATE_FORECAST_PERIOD')
    return sum((D(r['amount']) for r in actual if r['period']<cutoff),D(0))+sum((D(r['amount']) for r in forecast if r['period']>=cutoff),D(0))
def lookup_interval(rows,key,when):
    matches=[r for r in rows if r['key']==key and r['start']<=when<r['end']]
    require(len(matches)==1,'MISSING_OR_OVERLAPPING_INTERVAL')
    return matches[0]['value']
def check_intervals(rows):
    for i,a in enumerate(rows):
        require(a['start']<a['end'],'INVALID_INTERVAL')
        for b in rows[i+1:]:
            require(a['key']!=b['key'] or a['end']<=b['start'] or b['end']<=a['start'],'OVERLAPPING_INTERVAL')
    return True
def check_dag(edges):
    graph={}
    for a,b in edges:graph.setdefault(a,[]).append(b)
    active=set(); done=set()
    def visit(n):
        require(n not in active,'DEPENDENCY_CYCLE')
        if n in done:return
        active.add(n)
        for child in graph.get(n,[]): visit(child)
        active.remove(n); done.add(n)
    for n in graph:visit(n)
    return True
def authorize(identity,entity,current_rights):
    require(identity.get('trusted') is True,'UNTRUSTED_IDENTITY')
    require(entity in current_rights.get((identity['tenant'],identity['principal']),[]),'UNAUTHORIZED')
    return True
def no_fanout(keys):
    require(len(keys)==len(set(keys)),'JOIN_FANOUT')
    return True
def idempotent(rows):
    """Deduplicate within a materialized release; delivery batch is not event identity."""
    seen={}
    for row in rows:
        require(bool(row.get('release')),'MISSING_REPLAY_RELEASE')
        key=(row['tenant'],row['source'],row['ledger'],row['journal'],row['line'],row['release'])
        payload={k:v for k,v in row.items() if k not in ['batch','batch_id','delivery_id']}
        if key in seen:require(payload==seen[key][1],'CONFLICTING_REPLAY')
        else:seen[key]=(row,payload)
    return [value[0] for value in seen.values()]
def validate_model(m):
    require(m['status'] in ['proposed','validated','approved'],'INVALID_STATUS')
    tables={t['id']:t for t in m['tables']}; names={t['name']:t for t in m['tables']}
    require(len(tables)==len(m['tables'])==len(names),'DUPLICATE_ID')
    for t in m['tables']:
        cols={c['name']:c for c in t['columns']}
        require(len(cols)==len(t['columns']),'DUPLICATE_COLUMN')
        require(all(k in cols and not cols[k]['nullable'] for k in t['primary_key']),'INVALID_PRIMARY_KEY')
        for c in t['columns']:
            require(c['type'].startswith(('VARCHAR2(','NUMBER(','CHAR(','TIMESTAMP(')) or c['type'] in ['DATE','CLOB'],'UNSUPPORTED_TYPE')
        for f in t['foreign_keys']:
            require(f['target'] in names,'MISSING_FK_TARGET')
            target=names[f['target']]; tc={x['name']:x for x in target['columns']}
            require(len(f['columns'])==len(f['target_columns']),'FK_ARITY')
            require(f['target_columns']==target['primary_key'] or f['target_columns'] in target['unique'],'NONUNIQUE_FK_TARGET')
            for a,b in zip(f['columns'],f['target_columns']):
                require(a in cols and b in tc and cols[a]['type']==tc[b]['type'],'FK_TYPE_MISMATCH')
            require('TENANT_ID' not in tc or 'TENANT_ID' in f['columns'],'MISSING_TENANT_PREDICATE')
    mids={x['id']:x for x in m['metrics']}; pids={x['id']:x for x in m['policies']}
    require(len(mids)==len(m['metrics']) and len(pids)==len(m['policies']),'DUPLICATE_ID')
    require(all(p['status'] in ['proposed','approved','retired'] for p in pids.values()),'INVALID_POLICY_STATUS')
    edges=[]
    for x in m['metrics']:
        require(x['status'] in ['proposed','approved','retired'],'INVALID_STATUS')
        require(all(p in pids for p in x['policy_ids']),'MISSING_POLICY')
        require(bool(x['policy_ids']),'MISSING_POLICY')
        require(all(z in tables for z in x['lineage_ids']),'MISSING_LINEAGE')
        require(set(x['grain']) >= {'tenant','entity','period','currency'},'INVALID_GRAIN')
        e=x['expression']; deps=e['input_metric_ids']
        require(all(d in mids for d in deps),'MISSING_METRIC_DEPENDENCY')
        require(e['operator'] in ['subtract','divide','sum_report_line','approved_recipe','closing_balance','versioned_plan'],'INVALID_OPERATOR')
        require(e['operator'] not in ['subtract','divide'] or len(deps)==2,'EXPRESSION_ARITY')
        if e['operator']=='subtract':require(all(mids[d]['expression']['output_unit']==e['output_unit'] and mids[d]['grain']==x['grain'] for d in deps),'UNIT_OR_GRAIN_MISMATCH')
        if e['operator']=='divide':require(mids[deps[0]]['expression']['output_unit']==mids[deps[1]]['expression']['output_unit'] and e['output_unit']=='fraction' and all(mids[d]['grain']==x['grain'] for d in deps),'UNIT_OR_GRAIN_MISMATCH')
        if x['certifiable']:require(x['status']=='approved' and x['source_binding']=='SOURCE_BOUND' and all(pids[p]['status']=='approved' for p in x['policy_ids']),'UNAPPROVED_CERTIFICATION')
        edges += [(x['id'],d) for d in deps]
    require(not m['solver_components'],'SOLVER_NOT_IMPLEMENTED_IN_SELECTED_CORE')
    check_dag(edges)
    def certified_dependency(identifier,visited):
        if identifier in visited:return
        visited.add(identifier);metric=mids[identifier]
        require(metric['status']=='approved' and metric['source_binding']=='SOURCE_BOUND','UNAPPROVED_DEPENDENCY')
        require(all(pids[p]['status']=='approved' and pids[p]['source_binding']=='SOURCE_BOUND' for p in metric['policy_ids']),'UNAPPROVED_DEPENDENCY_POLICY')
        require(all(tables[t]['status']=='approved' and tables[t]['source_binding']=='SOURCE_BOUND' for t in metric['lineage_ids']),'UNBOUND_CERTIFICATION_LINEAGE')
        require(metric['expression']['operator']!='approved_recipe' or bool(metric['expression']['input_metric_ids']),'MISSING_EXECUTABLE_RECIPE')
        for dependency in metric['expression']['input_metric_ids']:certified_dependency(dependency,visited)
    for metric in m['metrics']:
        if metric['certifiable']:certified_dependency(metric['id'],set())
    return True

@exact_calculation
def evaluate(case,fixture,model):
    op=case['operation']; a=case.get('arguments',{})
    if op=='balanced':return balanced(fixture['journals'])
    if op=='unbalanced':return balanced(fixture['journals'][:-1])
    if op=='total':return totals(fixture,**a)[case['field']]
    if op=='trial_balance':
        populations={}
        for key,amount in trial_balance(fixture['journals']).items():populations[key[:-1]]=populations.get(key[:-1],D(0))+amount
        require(bool(populations),'NO_ROWS')
        require(all(amount==0 for amount in populations.values()),'UNBALANCED_TRIAL_BALANCE')
        return D(0)
    if op=='bridge':return D(a['opening'])+sum(map(D,a['movements']),D(0))
    if op=='ratio':return ratio(a['a'],a['b'])
    if op=='variance':return variance(a['a'],a['b'])[case['field']]
    if op=='pp':return (D(a['a'])-D(a['b']))*D(100)
    if op=='fx':return fx(**a,rates=fixture['fx'])
    if op=='version':return latest_version(fixture['versions'],**a)['id']
    if op=='stitch':return stitch(**a)
    if op=='interval':return lookup_interval(fixture['hierarchy'],**a)
    if op=='interval_check':return check_intervals(a['rows'])
    if op=='dag':return check_dag(a['edges'])
    if op=='authorize':return authorize(a['identity'],a['entity'],{('T1','analyst'):a['allowed']})
    if op=='fanout':return no_fanout(a['keys'])
    if op=='replay':return len(idempotent(fixture['journals']+fixture['journals']))
    if op=='reverse':
        reversals=[dict(r,journal='REVERSAL-'+r['journal'],debit=r['credit'],credit=r['debit']) for r in fixture['journals']]
        balances=trial_balance(fixture['journals']+reversals)
        require(all(amount==0 for amount in balances.values()),'REVERSAL_ACCOUNT_MISMATCH')
        return D(0)
    if op=='reorder':return totals(dict(fixture,journals=list(reversed(fixture['journals']))),**a)[case['field']]
    if op=='compare':return len(compare(**a))
    if op=='allocation':
        return sum(allocate(a['pool'],a['weights']))
    if op=='scope_ratio':return ratio(sum(map(D,a['numerator'])),sum(map(D,a['denominator'])))
    if op=='distinct':return len(set(a['members']))
    if op=='ytd':return sum((D(r['amount']) for r in a['rows'] if r['year']==a['year'] and r['seq']<=a['end_seq']),D(0))
    if op=='rank_total':return sum(map(D,a['values']))
    if op=='intersection':require(a['combination'] in a['valid'],'INVALID_INTERSECTION'); return True
    if op=='route':require(len(a['domains'])==1,'CLARIFICATION_REQUIRED'); return a['domains'][0]
    if op=='decimal_roundtrip':return str(D(a['value']))
    if op=='metadata':return validate_model(model)
    raise ContractError('UNSUPPORTED_REFERENCE_OPERATION')
