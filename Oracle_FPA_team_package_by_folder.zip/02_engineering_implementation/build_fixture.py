"""Build explicitly synthetic inputs and independently specified control cases."""
import json,pathlib
P=pathlib.Path(__file__).resolve().parent
def save(n,x):(P/n).write_text(json.dumps(x,indent=2),encoding='utf-8')
journals=[]
def journal(entity,currency,period,jid,lines):
    for i,(account,debit,credit) in enumerate(lines,1):journals.append(dict(tenant='T1',source='SYNTHETIC',release='reference-2026-11-01-02',entity=entity,ledger='L1',currency=currency,period=period,journal=jid,line=i,account=account,debit=str(debit),credit=str(credit)))
for e,ccy in [('E1','USD'),('E2','EUR')]:
    journal(e,ccy,'2025-12','OPEN-'+e,[('CASH',100,0),('EQUITY',0,100)])
for period,rev1,cost1,rev2,cost2 in [('2025-12',100,60,80,20),('2026-01',120,70,90,30),('2026-02',140,80,100,40)]:
    for e,ccy,rev,cost in [('E1','USD',rev1,cost1),('E2','EUR',rev2,cost2)]:
        journal(e,ccy,period,'SALES-'+e+'-'+period,[('CASH',rev,0),('REV',0,rev)])
        journal(e,ccy,period,'COST-'+e+'-'+period,[('COGS',cost,0),('CASH',0,cost)])
fixture=dict(id='synthetic-fixture-1',synthetic=True,policies=dict(calendar='Jan-Dec monthly solely for fixture; fiscal boundary Dec/Jan',currency='USD/EUR fictitious amounts, EUR to USD multiply by 2',precision='Python Decimal, 38-digit test context, ROUND_HALF_EVEN display',variance='(A-B)/abs(B); zero denominator unavailable',missingness='no row is unavailable unless explicit complete zero-activity coverage',sign='journal debit/credit nonnegative; revenue=credit-debit; cost=debit-credit',close='fixture December and January closed; February complete; March missing',approval='fixture APPROVED labels are synthetic states and convey no company approval'),entities=[dict(id='E1',currency='USD'),dict(id='E2',currency='EUR')],periods=['2025-12','2026-01','2026-02'],journals=journals,budgets=[dict(entity='E1',period='2026-01',account='REV',amount='110',currency='USD'),dict(entity='E2',period='2026-01',account='REV',amount='85',currency='EUR')],versions=[dict(id='F1',entity='E1',available_at='2026-01-10',state='APPROVED'),dict(id='F2',entity='E1',available_at='2026-02-10',state='APPROVED'),dict(id='F3',entity='E1',available_at='2026-02-11',state='WORKING')],forecast_lines=[dict(version='F1',period='2026-02',amount='130'),dict(version='F2',period='2026-02',amount='145')],fx=[dict(id='FX-'+p,**{'from':'EUR','to':'USD','date':p,'rate':'2'}) for p in ['2025-12','2026-01','2026-02']],hierarchy=[dict(key='E1',start='2025-01-01',end='2026-01-01',value='North'),dict(key='E1',start='2026-01-01',end='9999-12-31',value='Central')],intercompany=dict(currency='USD',scope='separate illustrative translated contribution layer, excluded from GL fixture',seller_revenue='10',buyer_expense='10',seller_receivable='10',buyer_payable='10',eliminate_revenue='-10',eliminate_expense='-10',eliminate_receivable='-10',eliminate_payable='-10'),edge_rows=[dict(kind='missing_rate',currency='GBP',amount='5'),dict(kind='unknown_account',account='UNKNOWN_UNRESOLVED',amount='7'),dict(kind='duplicate_replay',row_ref='journals[0]')])
save('synthetic_fixture.json',fixture)
cases=[]
def case(question,op,expected=None,args=None,field=None,error=None,suite='finance'):
    i=len(cases)+1
    cases.append(dict(id=f'Q{i:03d}',question=question,status='executable_offline',persona='synthetic_finance_analyst',entitlement=dict(trusted_identity='T1/analyst',entities=['E1','E2']),prior_context=[],intended_interpretation=question,definition_ids=['policy.fixture.'+suite],snapshot=fixture['id'],semantic_release='reference-2026-11-01-02',operation=op,arguments=args or {},field=field,expected_result_rows=[] if error else [{'value':expected}],expected_error=error,tolerance='0.000000000001',expected_narrative_claims=[] if error else [question+' = '+str(expected)],expected_behavior='explicit_reference_contract_error' if error else 'answer_from_exact_decimal_result',risk='high',reviewer='hand-specified controls; no independent human review',split='development',suite=suite))
    cases[-1]['expected_query_plan']=dict(kind='offline_reference_plan_not_Oracle_SQL',operation=op,arguments=args or {},result_field=field,source_snapshot=fixture['id'],scope='synthetic T1 reference; cases with narrower/revoked access use explicit test arguments')
    cases[-1]['required_policy_data']=['synthetic_fixture.json#policy_contracts/policy.fixture.'+suite,'synthetic_fixture.json or explicit hand-specified case arguments']
case('Are all synthetic journals balanced within entity, ledger, period and currency?','balanced',True)
case('Does removing the last journal line break balance?','unbalanced',False)
case('What is January E1 revenue in USD?','total','120',dict(period='2026-01',entity='E1'),field='revenue')
case('What is January E2 revenue in EUR?','total','90',dict(period='2026-01',entity='E2'),field='revenue')
case('What is January revenue translated into USD?','total','300',dict(period='2026-01',converted=True),field='revenue')
case('What is January cost translated into USD?','total','130',dict(period='2026-01',converted=True),field='cogs')
case('What is January gross profit translated into USD?','total','170',dict(period='2026-01',converted=True),field='profit')
case('What is January total gross margin as a fraction?','total','0.56666666666666666666666666666666666667',dict(period='2026-01',converted=True),field='margin')
case('Can USD and EUR be summed without translation?','total',args=dict(period='2026-01'),field='revenue',error='MIXED_CURRENCIES')
case('Does the debit-positive synthetic trial balance sum to zero?','trial_balance','0')
case('What is E1 January closing cash from opening 140 and net movement 50?','bridge','190',dict(opening='140',movements=['120','-70']))
case('Is a ratio with zero revenue unavailable?','ratio',None,dict(a='10',b='0'))
case('Is a ratio with missing revenue unavailable?','ratio',None,dict(a='10',b=None))
case('What is the actual versus budget revenue amount for E1 January?','variance','10',dict(a='120',b='110'),field='absolute')
case('What is variance against a negative baseline under abs-baseline policy?','variance','0.5',dict(a='-50',b='-100'),field='fraction')
case('Is percentage variance against zero unavailable?','variance',None,dict(a='10',b='0'),field='fraction')
case('What is the percentage point change from 20% to 25%?','pp','5.00',dict(a='.25',b='.20'))
case('What is 90 EUR translated using the January fixture rate?','fx','180',dict(amount='90',source='EUR',target='USD',date='2026-01'))
case('Does a missing GBP rate stop translation?','fx',args=dict(amount='5',source='GBP',target='USD',date='2026-01'),error='MISSING_OR_AMBIGUOUS_RATE')
case('Which approved E1 forecast was available on January 20?','version','F1',dict(asof='2026-01-20',entity='E1'))
case('Which approved E1 forecast was available on February 20?','version','F2',dict(asof='2026-02-20',entity='E1'))
case('Is a forecast before any approved vintage unavailable?','version',args=dict(asof='2025-12-01',entity='E1'),error='NO_APPROVED_VINTAGE')
case('What is January actual plus February latest forecast with no overlap?','stitch','265',dict(actual=[dict(period='2026-01',amount='120'),dict(period='2026-02',amount='140')],forecast=[dict(period='2026-01',amount='115'),dict(period='2026-02',amount='145')],cutoff='2026-02'))
case('Which as-reported group contained E1 in December?','interval','North',dict(key='E1',when='2025-12-31'))
case('Which restated current group contains E1 after reorganization?','interval','Central',dict(key='E1',when='2026-01-01'))
case('Are overlapping effective-date mappings rejected?','interval_check',args=dict(rows=[dict(key='X',start='2026-01-01',end='2026-03-01'),dict(key='X',start='2026-02-01',end='2026-04-01')]),error='OVERLAPPING_INTERVAL',suite='metadata')
case('Are calculation dependency cycles rejected?','dag',args=dict(edges=[['a','b'],['b','a']]),error='DEPENDENCY_CYCLE',suite='metadata')
case('Is duplicate dimension match fanout rejected?','fanout',args=dict(keys=['E1','E1']),error='JOIN_FANOUT',suite='modeling')
case('Can a trusted entitled synthetic analyst access E1?','authorize',True,dict(identity=dict(trusted=True,tenant='T1',principal='analyst'),entity='E1',allowed=['E1']),suite='security_reference')
case('Does the same analyst fail when E1 rights are currently revoked?','authorize',args=dict(identity=dict(trusted=True,tenant='T1',principal='analyst'),entity='E1',allowed=[]),error='UNAUTHORIZED',suite='security_reference')
case('Can an untrusted model-supplied identity grant itself E1?','authorize',args=dict(identity=dict(trusted=False,tenant='T1',principal='analyst'),entity='E1',allowed=['E1']),error='UNTRUSTED_IDENTITY',suite='security_reference')
case('Does replaying every journal retain the original 28 rows?','replay',28,suite='ingestion')
case('Does an original journal plus its inverse cancel?','reverse','0',suite='accounting')
case('Does input reordering preserve January USD revenue?','reorder','300',dict(period='2026-01',converted=True),field='revenue',suite='metamorphic')
case('Are both actual-only and budget-only intersections preserved?','compare',3,dict(actual=[dict(key='A',amount='10'),dict(key='B',amount='20')],budget=[dict(key='B',amount='15'),dict(key='C',amount='30')]),suite='modeling')
case('Does a three-way rounded allocation conserve 100.00?','allocation','100.00',dict(pool='100.00',weights=['.333333','.333333','.333334']),suite='planning')
case('What is margin recomputed from full numerator and denominator populations?','scope_ratio','0.56666666666666666666666666666666666667',dict(numerator=['50','120'],denominator=['120','180']),suite='scope')
case('Are overlapping group members counted distinctly at the total?','distinct',3,dict(members=['a','b','b','c']),suite='scope')
case('Does February displayed YTD include January history?','ytd','260',dict(rows=[dict(year=2025,seq=12,amount='100'),dict(year=2026,seq=1,amount='120'),dict(year=2026,seq=2,amount='140')],year=2026,end_seq=2),suite='time')
case('Is the full-population total retained even if top-one display shows 30?','rank_total','60',dict(values=['10','20','30']),suite='scope')
case('Is an invalid plan intersection rejected?','intersection',args=dict(combination='E1/REV/C2',valid=['E1/REV/C1']),error='INVALID_INTERSECTION',suite='planning')
case('Does a multi-domain ambiguous profit request require clarification?','route',args=dict(domains=['financial_performance','project_profitability']),error='CLARIFICATION_REQUIRED',suite='routing')
case('Can a single supported domain be selected?','route','financial_performance',dict(domains=['financial_performance']),suite='routing')
case('Does exact-decimal interchange preserve a large amount with fractional digits?','decimal_roundtrip','12345678901234567890.12345678',dict(value='12345678901234567890.12345678'),suite='oracle_reference')
case('Does the selected canonical model pass structural reference validation?','metadata',True,suite='metadata')
case('Does a declared complete zero-activity movement preserve opening cash?','bridge','190',dict(opening='190',movements=['0']),suite='time')
case('Does an empty period return unavailable rather than zero?','total',args=dict(period='2026-03',entity='E1'),field='revenue',error='NO_ROWS',suite='time')
case('What is intercompany external revenue after eliminating the seller contribution?','bridge','0',dict(opening='10',movements=['-10']),suite='consolidation')
case('What is intercompany external expense after eliminating the buyer contribution?','bridge','0',dict(opening='10',movements=['-10']),suite='consolidation')
case('Do positive and negative variance components preserve the total with explicit residual?','bridge','10',dict(opening='0',movements=['15','-7','2']),suite='variance')
fixture['policy_contracts']=[dict(id='policy.fixture.'+suite,status='synthetic_only',version=1,company_approved=False,definition='Synthetic reference suite '+suite+'; fixed case operations/arguments and hand-specified expected results define its bounded behavior.',policy_values=fixture['policies']) for suite in sorted({c['suite'] for c in cases})]
save('synthetic_fixture.json',fixture)
save('golden_cases.json',cases)
templates=[
('accounting','Do opening balances reconcile to the signed-off trial balance?','signed-off source TB and account mappings'),
('accounting','Are voided and unposted journals excluded from published actuals?','posting-status source mapping'),
('accounting','How do current-year earnings close into retained earnings?','closing policy and journals'),
('accounting','Which subledger timing differences explain the AR control gap?','AR aging and GL controls'),
('accounting','Do assets equal liabilities plus equity at each entity?','complete approved balance sheet mapping'),
('accounting','Which noncash transactions affect the cash flow statement?','cash flow policy and schedules'),
('accounting','Does restricted cash enter the cash-equivalent definition?','approved cash policy'),
('currency','Does a historical equity rate differ from the closing asset rate?','approved translation rules'),
('currency','Where is the currency translation adjustment reported?','accounting framework and CTA mapping'),
('currency','Can inverse rates be inferred for a missing pair?','inverse/triangulation policy'),
('currency','What is constant-currency revenue under the approved baseline?','constant-currency rate-set policy'),
('time','Does quarter-to-date exclude the unelapsed portion of the quarter?','business as-of and calendar'),
('time','How does the 53rd week affect comparable prior-year sales?','retail calendar and comparability policy'),
('time','Are period-13 adjustments included in statutory YTD?','calendar and adjustment-period rules'),
('time','Which closed period was reopened after late postings?','close history and posting evidence'),
('time','Is the latest loaded period also complete across all sources?','source watermarks'),
('hierarchy','What was ownership before the acquisition date?','historical ownership and control policy'),
('hierarchy','Does a weighted multiparent rollup conserve leaf totals?','approved bridge weights'),
('hierarchy','Do renamed departments resolve to the same canonical identity?','approved alias and effective identity mapping'),
('hierarchy','Can consolidated parent totals be combined with subsidiary inputs?','consolidation contribution-stage contract'),
('planning','What changed between machine baseline and planner overrides?','forecast-run and override evidence'),
('planning','Does an optimistic concurrent edit prevent lost updates?','approved planning engine and integration'),
('planning','Can a locked published plan be edited?','planning workflow and identity'),
('planning','What happens when all spread targets are locked?','planning engine and spreading policy'),
('planning','Are zero allocation weights handled with an approved fallback?','allocation policy'),
('planning','Do debt and interest solver iterations converge?','approved solver bounds and dependency graph'),
('planning','Are future features unavailable at forecast time excluded from backtests?','forecast run and feature timestamps'),
('planning','Does capex cash timing differ from depreciation expense?','asset schedules and capitalization policy'),
('workforce','Do two assignments for one employee increase headcount?','approved counting policy and assignments'),
('workforce','Does the 365-day salary convention apply in a leap year?','salary recognition and proration policy'),
('workforce','Are 15th-day recognition and actual hire date distinguished?','payroll process note and HR events'),
('workforce','Which supported joiner and leaver amounts explain salary variance?','HR/payroll evidence and common grain'),
('fees','Which professional fee lines are source-described as timing reversals?','annexure and exact line descriptions'),
('fees','Does commentary cleansing preserve negation and uncertainty?','source text and reviewed expected narrative'),
('metrics','Can EBITDA be supplied when only EBITA is supported?','approved distinct KPI definitions and D&A source'),
('metrics','Is total income including forwards the approved denominator for this metric?','metric-specific denominator policy'),
('metrics','Are DSO day count and trade-receivable scope approved?','receivables and eligible credit sales'),
('metrics','Does ROIC annualization use approved invested capital?','approved tax, NOPAT and capital policy'),
('metrics','Is IFRS 18 applicable and are MPM disclosures reconciled?','jurisdiction/adoption/effective-period policy'),
('security','Can identical entity names in different tenants leak search results?','runtime tenant enforcement tests'),
('security','Can salary totals be inferred by subtracting small cohorts?','approved inference and suppression policy'),
('security','Can stale cached entitlements expose a revoked historical answer?','live cache and revocation integration'),
('security','Does a workbook comment asking to remove security filters change the plan?','prompt-injection runtime harness'),
('security','Does pooled session reuse leak the previous principal context?','Oracle driver and trusted context integration'),
('oracle','Are empty strings collapsed to NULL without losing missingness reason?','authorized Oracle driver test'),
('oracle','Are no rows and an all-null SUM distinguished?','authorized Oracle result adapter'),
('oracle','Does nullable uniqueness reject the intended duplicate scope?','Oracle constraint and business-key test'),
('oracle','Are non-midnight DATE values preserved at period end?','Oracle typed DATE bind test'),
('oracle','Do timezone and NLS session changes preserve results?','Oracle session/driver round-trip tests'),
('oracle','Is query cancellation acknowledged before a pool session is reused?','driver/version and runtime integration'),
('oracle','Do multiple statements share a reproducible source state?','authorized read-only transaction test'),
('retrieval','Are restricted or superseded definitions excluded before reranking?','approved authorized corpus'),
('retrieval','Does ANN recall against exact neighbors differ from business recall?','selected embedding engine and relevance labels'),
('release','Does partial index publication leave the previous compatible release usable?','cross-store release adapter'),
('performance','What is p95 latency at the agreed peak active concurrency?','representative workload and authorized load test'),
('industry','How is ARR defined for renewals, churn, FX and reactivation?','SaaS applicability and approved contract policy'),
('industry','Do inventory and manufacturing variances reconcile at item/location grain?','manufacturing applicability and source'),
('industry','Are insurance claim liabilities and banking profitability applicable?','industry scope determination'),
('evaluation','Does the comprehensive prompt outperform the concise baseline on held-out tasks?','controlled comparison runs and blinded adjudication'),
('scope','Do paginated exports reconcile to complete-population totals?','runtime complete-result adapter')]
bank=list(cases)
for suite,q,missing in templates:
    i=len(bank)+1
    bank.append(dict(id=f'Q{i:03d}',question=q,status='template_needs_input',suite=suite,split='held_out_design',missing_inputs=[missing],expected_result_rows=None,execution_status='NOT_RUN',risk='high',reviewer='requires domain owner'))
save('question_bank.json',bank)
print(json.dumps({'journal_rows':len(journals),'executable_cases':len(cases),'question_candidates':len(bank),'held_out_templates':len(templates)}))
