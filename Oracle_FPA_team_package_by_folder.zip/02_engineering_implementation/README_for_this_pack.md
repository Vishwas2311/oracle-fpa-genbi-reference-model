This document is included in the combined folder package. Use START_HERE.md at the ZIP root for current navigation.

# Engineering implementation pack

This is an implementation subset of the original full package, with raw workbook extraction omitted. The design remains proposed, all source mappings remain UNBOUND, and all Oracle SQL remains DRAFT_UNEXECUTED. Read model_design.md, oracle_and_operations.md and graph_vector_publication.md first. The JSON configuration separates proposed company settings from synthetic data.

The supplied generators can rebuild the core model, fixture, contracts and synthetic Oracle seed. For test runners and their frozen evidence, also use the validation pack. Use a separate Python environment with requirements.txt and run generators from this folder. Run build_reference.py, then build_fixture.py, then build_contracts.py and build_oracle_fixture.py. Keep the included configuration.json available for subsequent contract testing. Candidate policy extraction, complete workbook reconstruction, full handoff regeneration and original manifest verification require the complete archive and reference workbook.

Do not treat offline checks as Oracle compilation, source reconciliation or production approval. Wider workforce, capital, ownership, tax and integrated planning extensions remain tracked in continuation_manifest.json. No database connection or deployment has been performed.
