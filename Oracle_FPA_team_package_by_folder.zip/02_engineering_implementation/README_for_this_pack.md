# Engineering implementation folder

Read correction_release_notes.md and model_design.md. Release reference-2026-11-01-02 has 29 tables, 248 columns and 15 proposed metrics. This is a breaking proposed key revision, not an automatic database migration. Company bindings remain UNBOUND.

The supplied core generators can rebuild the model, fixture, contracts and synthetic seed. Complete workbook/policy extraction and handoff regeneration require 04_complete_reference. The offline publication validator checks only its documented supported candidate population and never publishes to Oracle. Native source loading, atomic publication and security remain future integration.

Use Python 3.12+ and requirements.txt in a separate environment. Run test_correction_release.py against the supplied frozen inputs, and publication_validation.py --input publication_fixture.json. Use 03_validation_and_tests for the complete offline suites. Do not interpret any test as company approval.
