# Proposed Oracle FP&A model and GenBI consumption design

This is a local reference implementation and proposed physical design. It implements a bounded financial core and offline proof suite. It does not implement a production application, source connector, Oracle security layer, predictive forecast engine or complete enterprise planning platform. The supplied workbook is a candidate semantic catalog. Its mixed version notes and Active/Approved strings do not establish policy approval or actual executed results.

## Inputs, authority and scope

The user supplied one standalone creation specification and one 284127-byte workbook. The workbook SHA256 is 9ff07cff5bd7540a67193bc29610499a54089951bd32c73d1b90bc1b909f5461, matching the reference identity. The actual Oracle release/RU/edition/service, source systems and original MIS/annexure/process notes are unavailable. The user confirmed continuing with configurable assumptions and candidate policies.

| Input | Authority | What it can support | What it cannot prove |
|---|---|---|---|
| Current user instructions | Scope and Oracle target | Proposed design and offline execution | Company policy approval or deployment authorization |
| Pasted standalone specification | Requirements | Traceability and acceptance design | Independent business/source facts |
| Supplied workbook | Candidate catalog/requirements/glossary | Observed definitions, identifiers, conflicts and coordinates | GL completeness, source binding, original report parity |
| Public primary documentation | Product/modeling guidance | Version-specific design evidence | Installed capabilities, licensing, company policy |
| Synthetic fixture | Explicit test data | Finite numerical and contract tests | Company financial performance or live security |

The selected core covers journal movements, closing balances, actual-versus-budget, forecast vintage consumption, configurable period spines, currencies/FX, financial hierarchies, MIS reporting lines, coverage, assumptions, metadata and trusted entitlement design. Workforce detail, capex/debt/tax schedules, ownership calculation and industry-specific facts are extension contracts. Their absence does not block the selected core. Those are not claimed implemented merely because the workbook names them.

The workbook-derived policy extraction is in candidate_policy_review.md and workbook_candidate_policies.json. Calendar, currency, scale, signs and KPI candidates are extracted before design decisions are finalized. configuration.json records candidate references, pending approvals and UNBOUND column mappings. The synthetic USD/EUR Jan–Dec fixture is a separate profile, not an adoption of company currency/calendar defaults.

## Architecture decisions

ADR-01: propose a dedicated Oracle analytical schema for controlled history and reproducible financial releases. An overlay remains a viable alternative if verified upstream reporting products already provide those contracts; no such objects were supplied. A hybrid may reuse approved facts later. The dedicated schema is proposed, not a mandate to duplicate operational data. It cannot recover unavailable source history. Revisit after source/volume/operations discovery.

ADR-02: use conformed dimensions and separate facts by grain. Journal lines, period snapshots and plans have different temporal and dimensional meaning. Cross-fact analysis aggregates independently to shared keys. This follows the Kimball drill-across principle recorded in research_register.json. It avoids financial fanout and preserves unsupported dimensions as unavailable.

ADR-03: one offline canonical JSON model generates the DDL, dictionary, joins and graph projection. Oracle publication becomes the runtime authority only after controlled import, approval and cutover. Files and database must not remain competing writable masters. Workbook strings are stored as evidence, never compiled as SQL.

ADR-04: start with relational metadata and exact approved alias lookup. Defer separate graph/vector infrastructure, Data Vault and medallion products pending measured need. Relational edges serve lineage and impact analysis without turning relationships into numeric joins. Source volatility may later justify a historized integration layer; current evidence does not justify generating one.

ADR-05: no official Oracle version assumption. Conventional relational artifacts use an explicit provisional 19c authoring baseline. Release/edition compatibility, native execution and optional capabilities remain unverified. No Oracle-native graph/vector/Text syntax is mixed into core DDL.

```mermaid
flowchart LR
  W[Candidate workbook evidence] --> Q[Alignment and policy review]
  S[Future authorized sources] --> L[Immutable landing and source controls]
  L --> T[Typed staging and quarantine]
  T --> F[Reconciled Oracle journal / balance / plan products]
  Q --> M[Canonical versioned metadata]
  F --> V[Approved domain serving projections]
  M --> V
  M --> X[Derived aliases / graph / optional vectors]
  I[Trusted current identity] --> A[Authorization before discovery and execution]
  A --> X
  A --> V
  X --> P[Validated intent and constrained template selection]
  P --> V
  V --> R[Complete typed result and evidence envelope]
  R --> N[Numbers, table, chart and grounded narrative]
```

Trust boundaries occur at file/source extraction, canonical publication, identity acquisition, retrieval, query compilation and result export. A failed mapping, reconciliation, permission check or release compatibility check blocks the affected capability. Last-known compatible metadata may remain available only if current access still permits it.

## Conceptual relationships and grains

```mermaid
erDiagram
  SOURCE ||--o{ BATCH : extracts
  BATCH ||--o{ JOURNAL_LINE : accepts
  BATCH ||--o{ QUARANTINE : rejects
  ENTITY ||--o{ JOURNAL_LINE : posts
  ENTITY ||--o{ PLAN : plans
  ACCOUNT ||--o{ JOURNAL_LINE : classifies
  PERIOD ||--o{ JOURNAL_LINE : dates
  CALENDAR ||--o{ PERIOD : defines
  VERSION ||--o{ PLAN : freezes
  ENTITY ||--o{ BALANCE : closes
  ACCOUNT ||--o{ REPORT_MAP : maps
  REPORT_LINE ||--o{ REPORT_MAP : presents
  HIER_VERSION ||--o{ HIER_EDGE : contains
  HIER_NODE ||--o{ HIER_EDGE : links
  RELEASE ||--o{ META_OBJECT : publishes
```

physical_dictionary.csv covers every selected-core column. canonical_model.json declares every table's grain, PK, unique keys, constraints, owner, history and source-binding state. physical_erd.mmd includes the full column-level model and physical FKs. All identifiers are target design choices, not discovered production tables.

| Fact/product | One row means | Allowed aggregation | Forbidden aggregation |
|---|---|---|---|
| FPA_GL_LINE | Accepted source journal line in functional currency and immutable batch/release | Posted eligible debit/credit movement over compatible ledger/entity/account/period/layer | Mixed currencies/bases/layers, duplicate releases, unverified report signs |
| FPA_BALANCE | Account/period closing snapshot in a declared release/layer | Disjoint eligible accounts/entities at one snapshot after approved mapping | Sum across snapshots, parent plus subsidiaries, sum opening and closing as movement |
| FPA_PLAN | Entity/ledger/account/period/currency/version amount | Within supported plan dimensions and one approved vintage | Product/customer budget drill, summing multiple versions, actual-plan raw line join |
| FPA_FX_RATE | Pair/date/type/rate-version conversion | Lookup one approved rate | Sum/average rates without policy, infer missing rates automatically |
| FPA_COVERAGE | Source/entity/period/currency completeness and close assertion | Minimum combined completeness watermark under policy | Treat missing/partial as zero, infer hard close from load timestamp |
| FPA_ASSUMPTION | Scoped driver at entity/period/version | Typed recipe-specific behavior | Sum rates/ratios or substitute unresolved values with zero |

Journal and plan comparisons include ledger, currency, release and reporting-basis compatibility. Budget dimensions stop at the actual plan grain. FULL OUTER comparison preserves unbudgeted actuals and unspent budgets. Absent sides remain unavailable unless explicit approved coverage says zero activity. A source Budget Code is never a budget amount. Prior Year is resolved through calendar comparison, not a fictitious planning scenario.

## Identity, time and hierarchy

Business identifiers are source/tenant scoped character values. Names, OCR-like identifiers and case variants do not authorize joins. Preserve leading zeros and source raw values. Legal entities, management nodes, ledgers, accounts and planning versions have distinct keys. Source-to-canonical collision/merge/split decisions require stewards and effective dates. Unsupported IDs remain quarantined rather than guessed.

Calendar records are separate from period records. Each ledger references a calendar, and period keys are unique within tenant/calendar order. Multiple fiscal calendars coexist; periods explicitly carry fiscal year/period, start/end and adjustment classification. Validate a fact's ledger calendar against its period calendar at loading. Date role is explicit: posting instant differs from accounting period, snapshot time and ingestion cutoff. A local business DATE is not an instant. End boundaries are exclusive.

Entity label history has business and recorded intervals. Event-time joins must match exactly one version under both time axes. The draft stores stable master currency/chart identity outside a complete bitemporal master, so currency/identity changes require versioned migration and retained snapshots; full generalized master history is a named extension. Historical renames preserve identity. Management hierarchy versions permit typed nodes and alternate parent paths. Cycles, duplicate paths, overlapping memberships and weights must be validated before publication. FKs alone cannot prove these rules. Single-parent taxonomies and weighted multi-parent analytical hierarchies are distinct policy choices.

As-reported uses the historical approved hierarchy version. Restated uses a selected current hierarchy, with explicit effect on comparability. Do not sum parents and descendants. Nodes of account/reporting/consolidation hierarchies carry typed canonical references through metadata; the publication validator must check domain/range compatibility before runtime use.

## Accounting, MIS and planning rules

Raw journals retain separate nonnegative debit and credit. Debit-positive movement, normal balance, MIS sign and favorability are different concepts. Candidate negative-income annexure values require an approved source transformation; do not invert all expenses or treat a negative income posting as a decline. An unexpected mapping or rate stops the affected metric.

Reconcile debit/credit within correct journal/entity/ledger/currency scope; source TB by account/period; opening plus each classified movement exactly once to closing; complete mapped assets against liabilities/equity; cash opening to closing; subledger controls with explicit timing differences; retained/current-year earnings under closing policy. A balance CHECK is an identity, not proof of source truth. Owner-approved tolerances must preserve subordinate discrepancies and not mask offsetting differences.

FPA_REPORT_LINE holds MIS line order, indentation, leaf/subtotal/ratio type and typed expression reference. Ratios recompute at totals. Line mapping is effective and policy-specific. The candidate EBITA spine is preserved separately from generic reference KPI recipes; EBITDA never substitutes EBITA and PAT never substitutes PBT. External lines remain unavailable until sourced. Gross margin under a generic COGS definition is not the workbook's delivery-cost/forwards-denominator definition.

Scenarios, versions, vintages, workflow states, actual cutoff and horizon are separate. Resolve latest approved forecast by entity and decision-time availability, rejecting tied/ambiguous vintages. Actuals before cutoff plus forecast from cutoff onward prevent overlap. Version states include working, submitted, approved, locked, superseded and archived; publication freezes both values and policy references. Locked baseline edits create a new version.

Planning writeback is a future separate workflow, not a privilege of the analytical SQL path. It needs authorized role, valid intersections, optimistic concurrency, idempotent request ID, affected-cell preview, atomic save, approvals and rollback evidence. Parent entry distributes only to eligible unlocked leaves under an approved engine/rule. Store leaf values or parent values with explicit semantics, never both as additive facts. Allocate with approved weights, exact conservation, deterministic rounding residual and a no-eligible-target error. No invented economic drivers or residual force-balancing.

Integrated statement extensions require linked AR/collections, AP/payments, inventory, accrual/prepayment, deferred revenue, asset/depreciation, debt/interest, tax/dividend/equity/retained earnings schedules. Define each schedule's independent grain and authoritative source before adding tables. Circular debt/interest/cash needs an approved solver component, bounded convergence and failure behavior. Predictive forecasting is conditional; require decision-time features, vintage backtests, baseline comparison and separate planner overrides. It is not implemented here.

Salary and professional-fee commentary families are retained as requirements. Salary needs approved amount-column/entity matrix, compensation basis, HR events, counting/proration/cutoff policy and restricted common-grain comparison. Fees need source line descriptions, period/segment/master mapping, case normalization policy and prior-year population coverage. Return observed amount, arithmetic contribution, exact source-described reason, residual and excluded inputs separately. Preserve negation/reversal/timing/uncertainty in text cleansing. No unsupported joiner, merit, vendor or FX cause may appear in narrative.

## GenBI domain serving and calculation scope

The initial serving domain is financial_performance with shared time/currency/entity/ledger/account context. Cash/working capital, workforce and capital are separate routes requiring their own supported facts. Domain objects are filtered by current authorization before any model sees definitions, entity values, examples or snippets. Ambiguous profit/margin/calendar/entity/version requests require specific clarification unless a disclosed approved default resolves them. Unsupported budget dimensions return a limitation rather than an allocated product budget.

Order: authenticate/current entitlement; source/posting eligibility; release and business-time selection; scenario/vintage; authorized metric population; currency transformation; aggregate compatible facts; numerator/denominator calculation; cumulative/offset window; comparison; ranking; display limit. A displayed February YTD requires January history even if January is hidden. Top-N is deterministic with a stable canonical-ID tiebreaker. Full-population totals are computed before pagination and remain distinct from displayed subset sums. Distinct counts recompute over union populations. Null, zero, empty, all-null, partial, timeout and denied results remain different states.

The JSON schemas are internal contracts. Additional semantic checks must resolve IDs, check approval/current rights, align grain/units/currencies/calendars, ensure interval uniqueness and enforce limits. JSON Schema cannot authenticate a trusted identity or approve a metric. Structured intents and fixed Oracle template shapes are delivered; no arbitrary SQL compiler or NLP parser is claimed implemented. Exact decimal strings survive API/export. One validated result object supplies narrative, table and chart numbers.

## Evaluation and acceptance

50 hand-specified offline cases cover arithmetic, policies, selected references and negative behaviors. 60 additional templates bring the bank to 110 candidates, with missing data/runtime dependencies and a held-out design label. They have not been executed as a real NLP benchmark or independent held-out evaluation. The fixture and expected values are inspectable and hand-verifiable; no independent human reviewer has signed them off. Seven metadata mutations and three independent account/scope controls supplement the cases. Contract checks validate positive/negative examples separately.

Accounting/security release gates remain mandatory pass/fail controls, not an average quality score. Answered accuracy denominator is substantive answers issued; coverage denominator is all in-scope answerable questions. Score clarification, refusal and missing-data responses separately. Retrieval recall/precision require authorized relevance labels; latency/cost require runtime measurement. No scores are invented. Same-model review passes do not constitute independent review. Prompt comparison against original/comprehensive/concise baselines remains NOT_RUN, with identical sanitized inputs, model/tool budget, held-out templates and blinded finance/security adjudication required.

Core technical checks do not certify real sources, Oracle syntax/runtime behavior, financial policy, access controls or production acceptance. completion_matrix.csv and continuation_manifest.json identify exact remaining extensions and blockers. Useful proposed development continues with configurable unbound sources throughout.

## Version 2 corrections

The current core is 29 tables and 248 columns with 15 proposed metric contracts. FPA_ENTITY_ID is the stable legal identity registry. All records carrying RELEASE_ID use release-aware keys and references, apart from the root release itself. Current entitlements reference stable identity, independently of numeric releases. FPA_ENTITY attributes and functional currency are release snapshots. FPA_PLAN_LINE preserves native MIS line planning separately from account plans. FPA_COVERAGE includes ledger. FPA_LEDGER now declares its account-chart namespace. See correction_release_notes.md for the supported offline admission gate and the breaking migration boundary.

The earlier description of stable master currency/chart attributes does not mean those attributes can be overwritten in version 2. Retain immutable release snapshots and preserve canonical identities. A new reporting grain never creates an unapproved allocation. Wider bitemporal master/source-crosswalk governance remains an extension.
