"""Generate a separately labeled synthetic Oracle seed script. Does not execute SQL."""
import hashlib,json,pathlib
from decimal import Decimal
P=pathlib.Path(__file__).resolve().parent
f=json.loads((P/'synthetic_fixture.json').read_text(encoding='utf-8'))
model=json.loads((P/'canonical_model.json').read_text(encoding='utf-8'))
release=model['release_id']; statements=['-- SYNTHETIC ONLY. DRAFT_UNEXECUTED. Requires an authorized empty proposed schema.','-- Do not load alongside actual source data or treat fixture APPROVED states as company approval.','-- No COMMIT is supplied. Review/load controls and transaction boundary must be selected explicitly.']
seed_rows={}
def text(s):return "'"+str(s).replace("'","''")+"'"
class SQL(str):pass
def date(s):return SQL('DATE '+text(s))
def ts(s):return SQL('TO_TIMESTAMP_TZ('+text(s)+', '+text('YYYY-MM-DD"T"HH24:MI:SSTZH:TZM')+')')
def insert(table,**v):
    def sql(x):return str(x) if isinstance(x,(SQL,int,Decimal)) else 'NULL' if x is None else text(x)
    statements.append('INSERT INTO '+table+' ('+', '.join(v)+') VALUES ('+', '.join(sql(x) for x in v.values())+');')
    seed_rows.setdefault(table,[]).append(v)
insert('FPA_RELEASE',RELEASE_ID=release,CONTRACT_VERSION=model['contract_version'],STATUS='PROPOSED',MODEL_HASH=hashlib.sha256((P/'canonical_model.json').read_bytes()).hexdigest(),PUBLISHED_AT=None,ROLLBACK_REF=None)
policies=['fixture.calendar','fixture.basis','fixture.sign','fixture.fx','fixture.hierarchy','fixture.reporting']
for pid in policies:
    insert('FPA_POLICY',RELEASE_ID=release,POLICY_ID=pid,POLICY_TYPE=pid.split('.')[-1],STATUS='PROPOSED',OWNER_ROLE='synthetic_owner',APPROVER_ROLE='synthetic_reviewer',DEFINITION='Synthetic fixture only; not approved company policy',VALID_FROM=date('2025-01-01'),VALID_TO=date('9999-12-31'))
for code in ['USD','EUR']:
    insert('FPA_CURRENCY',CURRENCY_CODE=code,CURRENCY_NAME='Synthetic denomination '+code,MINOR_UNITS=2,VALID_FROM=date('2025-01-01'),VALID_TO=date('9999-12-31'))
insert('FPA_SOURCE',TENANT_ID='T1',SOURCE_ID='SYNTHETIC',SOURCE_NAME='Explicit synthetic reference fixture',AUTHORITY_STATE='UNBOUND',DATA_ORIGIN='SYNTHETIC',OWNER_ROLE='synthetic_owner',RELEASE_ID=release)
insert('FPA_CALENDAR',TENANT_ID='T1',CALENDAR_ID='fixture.calendar',CALENDAR_NAME='Synthetic January-December monthly calendar',TIMEZONE_NAME='UTC',POLICY_ID='fixture.calendar',RELEASE_ID=release)
for i,(period,end) in enumerate([('2025-12','2026-01-01'),('2026-01','2026-02-01'),('2026-02','2026-03-01')],1):
    insert('FPA_PERIOD',TENANT_ID='T1',PERIOD_ID=period,CALENDAR_ID='fixture.calendar',PERIOD_SEQ=i,PERIOD_START=date(period+'-01'),PERIOD_END=date(end),FISCAL_YEAR=int(period[:4]),FISCAL_PERIOD=int(period[-2:]),PERIOD_KIND='REGULAR',RELEASE_ID=release)
insert('FPA_LEDGER',TENANT_ID='T1',LEDGER_ID='L1',LEDGER_NAME='Synthetic ledger',BASIS_POLICY_ID='fixture.basis',CALENDAR_ID='fixture.calendar',COA_ID='fixture.coa',RELEASE_ID=release)
for account,kind,side in [('CASH','ASSET','D'),('EQUITY','EQUITY','C'),('REV','REVENUE','C'),('COGS','EXPENSE','D')]:
    insert('FPA_ACCOUNT',TENANT_ID='T1',ACCOUNT_ID=account,SOURCE_ID='SYNTHETIC',COA_ID='fixture.coa',ACCOUNT_CODE='000'+str(['CASH','EQUITY','REV','COGS'].index(account)+1),ACCOUNT_NAME='Synthetic '+account,ACCOUNT_CLASS=kind,NORMAL_SIDE=side,RELEASE_ID=release)
for entity,currency in [('E1','USD'),('E2','EUR')]:
    insert('FPA_ENTITY_ID',TENANT_ID='T1',ENTITY_ID=entity)
    insert('FPA_ENTITY',TENANT_ID='T1',ENTITY_ID=entity,SOURCE_ID='SYNTHETIC',SOURCE_KEY=entity,FUNCTIONAL_CCY=currency,RELEASE_ID=release)
    insert('FPA_ENTITY_VER',TENANT_ID='T1',ENTITY_ID=entity,ENTITY_VER_ID=entity+'-V1',ENTITY_NAME='Synthetic '+entity,VALID_FROM=date('2025-01-01'),VALID_TO=date('9999-12-31'),RECORDED_FROM=ts('2025-01-01T00:00:00+00:00'),RECORDED_TO=ts('9999-12-31T00:00:00+00:00'),RELEASE_ID=release)
    rows=[r for r in f['journals'] if r['entity']==entity]
    debit=sum((Decimal(r['debit']) for r in rows),Decimal(0));credit=sum((Decimal(r['credit']) for r in rows),Decimal(0))
    insert('FPA_BATCH',TENANT_ID='T1',BATCH_ID='B-'+entity,SOURCE_ID='SYNTHETIC',SOURCE_CUTOFF=ts('2026-03-01T00:00:00+00:00'),INPUT_ROWS=len(rows),ACCEPTED_ROWS=len(rows),REJECTED_ROWS=0,INPUT_DEBIT=debit,INPUT_CREDIT=credit,CONTROL_CCY=currency,STATE='STAGED',TRANSFORM_VERSION='fixture-1',RELEASE_ID=release)
    insert('FPA_ENTITLEMENT',TENANT_ID='T1',PRINCIPAL_ID='synthetic_analyst',ENTITY_ID=entity,PURPOSE_CODE='fixture_test',VALID_FROM=ts('2025-01-01T00:00:00+00:00'),VALID_TO=ts('9999-12-31T00:00:00+00:00'),REVISION=1)
for v in f['versions']:
    insert('FPA_VERSION',TENANT_ID='T1',VERSION_ID=v['id'],SCENARIO='FORECAST',VINTAGE_AT=ts(v['available_at']+'T00:00:00+00:00'),STATE=v['state'],ACTUAL_CUTOFF=date('2026-02-01'),HORIZON_END=date('2027-01-01'),RELEASE_ID=release)
insert('FPA_VERSION',TENANT_ID='T1',VERSION_ID='BUDGET1',SCENARIO='BUDGET',VINTAGE_AT=ts('2025-12-01T00:00:00+00:00'),STATE='APPROVED',ACTUAL_CUTOFF=date('2026-01-01'),HORIZON_END=date('2027-01-01'),RELEASE_ID=release)
for r in f['journals']:
    insert('FPA_GL_LINE',TENANT_ID=r['tenant'],ENTITY_ID=r['entity'],LEDGER_ID=r['ledger'],ACCOUNT_ID=r['account'],PERIOD_ID=r['period'],CURRENCY=r['currency'],BATCH_ID='B-'+r['entity'],JOURNAL_ID=r['journal'],LINE_NO=r['line'],SOURCE_ID='SYNTHETIC',POSTED_AT=ts(r['period']+'-01T12:00:00+00:00'),DEBIT=Decimal(r['debit']),CREDIT=Decimal(r['credit']),COUNTERPARTY_ID=None,POSTING_STATE='POSTED',LAYER_CODE='INPUT',RELEASE_ID=release)
for r in f['budgets']:
    # Fixture plan storage uses debit-positive revenue, distinct from positive display revenue.
    insert('FPA_PLAN',TENANT_ID='T1',ENTITY_ID=r['entity'],LEDGER_ID='L1',ACCOUNT_ID=r['account'],PERIOD_ID=r['period'],CURRENCY=r['currency'],VERSION_ID='BUDGET1',AMOUNT=-Decimal(r['amount']),SIGN_POLICY_ID='fixture.sign',RELEASE_ID=release)
for r in f['forecast_lines']:
    insert('FPA_PLAN',TENANT_ID='T1',ENTITY_ID='E1',LEDGER_ID='L1',ACCOUNT_ID='REV',PERIOD_ID=r['period'],CURRENCY='USD',VERSION_ID=r['version'],AMOUNT=-Decimal(r['amount']),SIGN_POLICY_ID='fixture.sign',RELEASE_ID=release)
for r in f['fx']:
    insert('FPA_FX_RATE',TENANT_ID='T1',RATE_ID=r['id'],FROM_CCY=r['from'],TO_CCY=r['to'],RATE_DATE=date(r['date']+'-01'),RATE_TYPE='FIXTURE_AVERAGE',RATE_VERSION='fixture-rates-1',RATE=Decimal(r['rate']),POLICY_ID='fixture.fx',RELEASE_ID=release)
insert('FPA_REPORT_LINE',RELEASE_ID=release,REPORT_LINE_ID='fixture.mis.revenue',STATEMENT_ID='fixture.mis',LINE_NAME='Synthetic revenue',LINE_KIND='LEAF',DISPLAY_ORDER=1,EXPRESSION_ID=None,POLICY_ID='fixture.reporting',INDENT_LEVEL=0)
insert('FPA_PLAN_LINE',TENANT_ID='T1',ENTITY_ID='E1',LEDGER_ID='L1',REPORT_LINE_ID='fixture.mis.revenue',PERIOD_ID='2026-01',CURRENCY='USD',VERSION_ID='BUDGET1',AMOUNT=Decimal('-110'),SIGN_POLICY_ID='fixture.sign',RELEASE_ID=release)
insert('FPA_REPORT_MAP',TENANT_ID='T1',MAP_ID='fixture.map.revenue',ACCOUNT_ID='REV',REPORT_LINE_ID='fixture.mis.revenue',SIGN_MULTIPLIER=1,POLICY_ID='fixture.reporting',VALID_FROM=date('2025-01-01'),VALID_TO=date('9999-12-31'),RELEASE_ID=release)
(P/'oracle_synthetic_seed.sql').write_text('\n\n'.join(statements)+'\n',encoding='utf-8')
assert sum(s.startswith('INSERT INTO FPA_GL_LINE ') for s in statements)==28
checks=[]
for t in model['tables']:
    rows=seed_rows.get(t['name'],[]);columns={c['name']:c for c in t['columns']}
    keys=[]
    for row in rows:
        assert set(row)<=set(columns)
        assert all(row.get(c['name']) is not None for c in t['columns'] if not c['nullable'] and c['default'] is None)
        keys.append(tuple(row[k] for k in t['primary_key']))
        for fkey in t['foreign_keys']:
            key=tuple(row[k] for k in fkey['columns'])
            if any(k is None for k in key):continue
            assert any(key==tuple(parent[k] for k in fkey['target_columns']) for parent in seed_rows.get(fkey['target'],[])),(t['name'],fkey,key)
    assert len(keys)==len(set(keys))
    checks.append(dict(table=t['name'],seed_rows=len(rows),required_columns_pk_fk_passed=True))
(P/'oracle_seed_static_report.json').write_text(json.dumps(dict(checks=checks,status='offline seed shape/reference checks passed; Oracle execution NOT_RUN'),indent=2),encoding='utf-8')
# Typed offline payload mirrors SQL seed inputs without SQL-expression strings.
def plain(value):
    if isinstance(value,SQL):
        import re
        return re.search(r"'([^']*)'",str(value))[1]
    return str(value) if isinstance(value,Decimal) else value
(P/'publication_fixture.json').write_text(json.dumps(dict(release_id=release,tables={name:[{key:plain(value) for key,value in row.items()} for row in rows] for name,rows in seed_rows.items()}),indent=2),encoding='utf-8')
print(json.dumps({'synthetic_inserts':sum(s.startswith('INSERT') for s in statements),'execution':'NOT_RUN'}))
