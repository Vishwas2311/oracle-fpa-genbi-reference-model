# Public copy notes

This repository and archive are intentionally public as requested. Two local computer paths were removed from inspect_workbook.py and workbook_manifest.json, and affected reference hashes were regenerated. The original workbook is not included; extracted candidate evidence remains included. Company approvals and source bindings were not manufactured. Numeric fixture changes and version-2 model corrections are documented in RELEASE_NOTES.md.
