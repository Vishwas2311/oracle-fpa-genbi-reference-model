# Public copy notes

This is the publicly shared copy of the proposed Oracle FP&A reference package. Two local computer path strings were removed from the inspection script and workbook manifest. The script now defaults to a workbook filename in the current working directory. The original workbook was not edited and is not included. Its extracted catalog evidence remains in the complete-reference folder.

The affected artifact hashes and combined archive inventory were regenerated. Financial fixture amounts, model definitions, SQL, policies and test assertions were not changed by this publication cleanup. Earlier statements about a byte-identical reference copy refer to the internal package before this cleanup.

The package remains a partially implemented enterprise proposal with bounded offline test evidence. It is not a production-approved model. See final_review.md for known gaps. A public repository is accessible to anyone; the included reference evidence is intentionally part of this publication.
