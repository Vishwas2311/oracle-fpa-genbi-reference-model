from pathlib import Path
import csv,datetime,hashlib,json,re
import openpyxl

import argparse
parser=argparse.ArgumentParser(description='Read-only audit against the supplied original prompt and workbook')
parser.add_argument('--prompt',required=True)
parser.add_argument('--workbook',required=True)
args=parser.parse_args()
p=Path(__file__).resolve().parent
prompt=Path(args.prompt)
source=Path(args.workbook)
load=lambda name:json.loads((p/name).read_text(encoding='utf-8'))
wb=openpyxl.load_workbook(source,data_only=False);cache=openpyxl.load_workbook(source,data_only=True)
observed={(c['sheet'],c['cell']):c for c in load('workbook_cells.json')}
checks=[]
def record(name,ok,detail):checks.append(dict(id=name,passed=bool(ok),detail=detail))
def value(v):return v.isoformat() if isinstance(v,(datetime.datetime,datetime.date,datetime.time)) else v
actual={}
for sheet in wb:
    for row in sheet:
        for c in row:
            if c.value is not None:actual[(sheet.title,c.coordinate)]=c
record('ALL_EXTRACTED_CELL_COORDINATES',set(actual)==set(observed),dict(actual=len(actual),extracted=len(observed)))
differences=[]
for key,c in actual.items():
    saved=observed[key]
    if value(c.value)!=saved['raw'] or c.data_type!=saved['type'] or c.number_format!=saved['number_format'] or (value(cache[key[0]][key[1]].value) if c.data_type=='f' else None)!=saved['cached']:
        differences.append('/'.join(key))
record('EVERY_RAW_VALUE_TYPE_FORMAT_AND_FORMULA_CACHE_MATCHES',not differences,dict(discrepancies=differences))
record('ALL_SHEETS_REPRESENTED',wb.sheetnames==[s['name'] for s in load('workbook_manifest.json')['sheets']],dict(sheets=len(wb.sheetnames)))
record('FROZEN_WORKBOOK_HASH_MATCHES',hashlib.sha256(source.read_bytes()).hexdigest()==load('workbook_manifest.json')['sha256'],'Reference workbook unchanged')
policy_discrepancies=[];evidence_count=0
for policy in load('workbook_candidate_policies.json'):
    for e in policy['evidence']:
        sheet,coord=e['reference'].split('!');evidence_count+=1
        if value(wb[sheet][coord].value)!=e['raw_value']:policy_discrepancies.append(e['reference'])
    if policy['business_approved'] or policy['source_verified']:policy_discrepancies.append(policy['id']+' false approval')
record('CANDIDATE_POLICY_EVIDENCE_RECHECKED',not policy_discrepancies,dict(evidence_references=evidence_count,discrepancies=policy_discrepancies))
rows=load('workbook_kpi_catalog.json')['raw_metric_records']
bad=[]
for r in rows:
    row=int(re.search(r'!A(\d+):',r['coordinate']).group(1))
    for i,(header,v) in enumerate(r['raw_fields'].items(),1):
        if wb['09_KPI_Metric'].cell(row,i).value!=v:bad.append(r['coordinate']+'/'+header)
record('ALL_84_RAW_KPI_ROWS_RECHECKED',len(rows)==84 and not bad,dict(rows=len(rows),discrepancies=bad))
domains={wb['01_Domain'].cell(r,1).value for r in range(2,21)}
values=[wb['02_Subdomain'].cell(r,2).value for r in range(2,113)]
record('REPORTED_NARROW_DOMAIN_ISSUE_REPRODUCED',sum(v is not None and v not in domains for v in values)==36 and sum(v is None for v in values)==4,dict(unmatched_nonblank=36,blank=4))
record('FORMULA_AND_ERROR_COUNTS_REPRODUCED',sum(c.data_type=='f' for c in actual.values())==6 and sum(c.data_type=='e' for c in actual.values())==1,'6 formula-like prose cells; 1 stored Excel error; no recalculation')
text=prompt.read_text(encoding='utf-8')
headings=re.findall(r'^## (\d+)\. (.+)$',text,re.M)
with (p/'completion_matrix.csv').open(encoding='utf-8',newline='') as f:matrix=list(csv.DictReader(f))
record('ALL_ORIGINAL_PROMPT_SECTIONS_ACCOUNTED_FOR',[int(i) for i,_ in headings]==list(range(56)) and {r['requirement_id'] for r in matrix}=={f'REQ{i:02d}' for i in range(56)},dict(sections=len(headings),note='Presence in traceability is not proof of completed implementation'))
artifacts_missing=[]
for r in matrix:
    for item in r['artifacts'].split(';'):
        pattern=item.strip()
        if not list(p.glob(pattern)):artifacts_missing.append(dict(section=r['section'],artifact=pattern))
record('SECTION_REFERENCED_ARTIFACTS_EXIST',not artifacts_missing,artifacts_missing)
all_json=[];all_python=[];all_csv=[]
for f in p.iterdir():
    if f.suffix=='.json':json.loads(f.read_text(encoding='utf-8'));all_json.append(f.name)
    elif f.suffix=='.py':compile(f.read_text(encoding='utf-8'),f.name,'exec');all_python.append(f.name)
    elif f.suffix=='.csv':
        with f.open(encoding='utf-8',newline='') as handle:
            values=list(csv.reader(handle));assert all(len(r)==len(values[0]) for r in values),f.name
        all_csv.append(f.name)
record('EVERY_STRUCTURED_FILE_READS',True,dict(json=len(all_json),python=len(all_python),csv=len(all_csv)))
cases=load('golden_cases.json');bank=load('question_bank.json');fixture=load('synthetic_fixture.json')
pids={x['id'] for x in fixture['policy_contracts']}
record('BENCHMARK_COUNTS_AND_OFFLINE_PLANS',len(cases)>=30 and len(bank)>=100 and all(q.get('expected_query_plan') and set(q['definition_ids'])<=pids for q in cases),dict(executable=len(cases),candidates=len(bank),note='Offline plans only; no NL/Oracle end-to-end execution'))
model=load('canonical_model.json')
record('NO_COMPANY_CERTIFICATION_OR_BOUND_SOURCE_INVENTED',all(not m['certifiable'] for m in model['metrics']) and all(b['state']=='UNBOUND' and not b['column_map'] for b in load('configuration.json')['source_bindings']),'No source mapping or policy approval is manufactured')
report=dict(review_date='2026-11-01',prompt_sha256=hashlib.sha256(prompt.read_bytes()).hexdigest(),workbook_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),checks=checks,passed=sum(x['passed'] for x in checks),total=len(checks),limitations=['No Excel formula recalculation or visual rendering','No binary DAX/Power Query decoding','No native Oracle parsing/execution/driver/security/performance test','No company-original MIS/annexure reconciliation','No independent finance/security reviewer'],verdict='Ready for proposed-core design review and further offline development; original enterprise prompt remains partially implemented; not production ready')
(p/'source_prompt_review_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
special={
5:'Selected-core dictionary exists; optional operational entities and complete attribute histories remain incomplete.',
6:'Hierarchy structures exist; general closure, type-specific membership validation and complete bitemporal masters remain incomplete.',
8:'Fixture journal/TB controls run; full real-source statement, cash, subledger and retained-earnings reconciliation is unavailable.',
10:'Intercompany contribution amounts are illustrative; complete ownership/elimination engine and native integration remain incomplete.',
14:'Integrated statements, governed circular solvers and predictive backtesting are specifications/extensions, not a running planner.',
15:'Allocation arithmetic exists; workforce/capital schedules and production spreading/writeback are not implemented.',
16:f"{len(model['metrics'])} generic proposed metrics and 84 raw workbook candidates exist; complete approved executable KPI catalog remains incomplete.",
17:'Selected structural/unit/grain validators and schemas exist; no complete typed financial expression compiler is implemented.',
20:'Retrieval specification exists; no approved production corpus, embeddings, relevance labels or measured retrieval engine.',
21:'Intent schemas and bounded routing predicates exist; no complete natural-language interpretation runtime.',
22:'Fixed Oracle templates exist; no dialect AST compiler or execution gateway is implemented.',
24:'Security design and predicate examples exist; current identity, database enforcement and inference protections are not implemented.',
25:'Batch/quarantine design and supported offline candidate admission exist; source-specific extraction, rejected-amount reconciliation, native publication and full source/report controls remain incomplete.',
27:'110 candidate questions and 50 executable helper cases exist with offline plans; 60 templates remain unexecuted and not held-out performance evidence.',
28:'Finite selected numeric proofs run; intercompany, variance bridge and security examples are bounded demonstrations rather than a complete financial runtime.',
30:'Performance/operations design exists; no measured load/cost or owner-approved SLOs.',
33:'Same-assistant regression review only; independent human/agent review and approvals not performed.',
35:'Vector contract/specification only; engine/model/index/filter-recall adapter not deployed or tested.',
36:'Proposed graph and dependency checks exist; full domain/range/security projection and traversal enforcement remain incomplete.',
37:'Release/revocation design exists; runtime cross-store publication consumers and failure recovery are not implemented.',
39:'Selected offline admission checks run; actual source/identity/query/index/answer end-to-end admission remains incomplete.',
41:'Release-aware period and ledger-specific coverage structures plus supported offline ledger/calendar/chart admission exist; generalized intersection and native publication enforcement remain incomplete.',
42:'Material primary-source register exists; broad product comparison and controlled prompt comparison NOT_RUN.',
43:'All 57 sheets/cells rechecked; rendered views, recalculation and binary semantic payloads not verified.',
44:'Raw reversible evidence and candidate mapping exist; original-report parity and approved record reconstruction unavailable.',
48:f"Complete {len(model['tables'])}-table physical dictionary generated against a provisional syntax baseline; installed-release compatibility unverified.",
49:'Release-aware draft constraints, compound currency/source references, diagnostic examples and supported offline temporal/calendar controls exist; native loader integration, generalized admission and native constraint/performance evidence remain required.',
50:'Draft typed template design only; native SQL parsing/execution, driver round-trip and cancellation/snapshot behavior NOT_RUN.',
51:'Current-rights security design only; trusted Oracle session context/pool reset/revocation tests NOT_RUN.',
52:'Relational metadata proposal and optional native feature specifications exist; native publication adapters remain incomplete.',
53:'Candidate policy conflicts/evidence documented; missing source originals prevent company-specific financial verification.',
54:'Selected-core package and tests delivered; full requested validator set, native tests and enterprise extensions remain incomplete.',
55:'Staged handoff exists; broad scope is not completely implemented and production acceptance is not approved.'}
rows=[]
for i,title in headings:
    section=int(i);base=matrix[section]
    rows.append(dict(requirement_id=f'REQ{section:02d}',original_section_title=title,artifacts=base['artifacts'],review_conclusion=special.get(section,'Proposed design/evidence is present as described in the existing completion matrix; runtime behavior and company approval are not inferred.'),completion_claim='partial_or_proposed_not_full_acceptance',remaining_reference='continuation_manifest.json',reviewer='same assistant; no independence claim'))
with (p/'prompt_requirement_review.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(dict(passed=report['passed'],total=report['total'],cells=len(actual),policy_evidence=evidence_count,sections=len(headings),verdict=report['verdict'])))
assert all(r['passed'] for r in checks)
