"""Check current documentation, derived counts and optional distributed archive/PPT claims."""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import argparse,csv,datetime,hashlib,io,json,re,sys
P=Path(__file__).resolve().parent
load=lambda name:json.loads((P/name).read_text(encoding='utf-8'))
model=load('canonical_model.json');graph=load('graph.proposed.json');results=[]
counts=dict(tables=len(model['tables']),columns=sum(len(t['columns']) for t in model['tables']),metrics=len(model['metrics']),nodes=len(graph['nodes']),edges=len(graph['edges']))
def check(name,fn):
    try:fn();results.append(dict(id=name,passed=True))
    except Exception as exc:results.append(dict(id=name,passed=False,error=repr(exc)))
def dictionary():
    with (P/'physical_dictionary.csv').open(encoding='utf-8',newline='') as handle:rows=list(csv.DictReader(handle))
    assert len(rows)==counts['columns']
    assert {row['table'] for row in rows}=={t['name'] for t in model['tables']}
check('DICTIONARY_MATCHES_CURRENT_MODEL',dictionary)
def bindings():
    config=load('configuration.json')
    assert {b['target'] for b in config['source_bindings']}=={t['name'] for t in model['tables']}
    assert all(b['state']=='UNBOUND' for b in config['source_bindings'])
    assert not config['publication']['production_approved'] and not any(m['certifiable'] for m in model['metrics'])
check('CONFIGURATION_HAS_ALL_TARGETS_AND_NO_FALSE_APPROVAL',bindings)
def traceability():
    with (P/'prompt_requirement_review.csv').open(encoding='utf-8',newline='') as handle:rows={r['requirement_id']:r for r in csv.DictReader(handle)}
    assert str(counts['metrics'])+' generic proposed metrics' in rows['REQ16']['review_conclusion']
    assert str(counts['tables'])+'-table physical dictionary' in rows['REQ48']['review_conclusion']
    assert 'offline' in rows['REQ49']['review_conclusion']
check('PROMPT_TRACEABILITY_USES_CURRENT_COUNTS_AND_SCOPE',traceability)
def continuation():
    row=next(r for r in load('continuation_manifest.json')['remaining'] if r['id']=='EXT.LOADER')
    assert 'offline candidate validator' in row['implemented']
    assert 'Integrate publication_validation.py' in row['work']
    assert load('continuation_manifest.json')['release']==model['release_id']
check('CONTINUATION_DISTINGUISHES_IMPLEMENTED_AND_REMAINING_LOADER_WORK',continuation)
def current_documents():
    obsolete=re.compile(r'\b(?:27 (?:proposed )?(?:tables|database tables)|233 (?:documented |proposed )?(?:columns|column definitions)|13 generic proposed metrics|90/90|90 of 90|31 proposed nodes|19 dependency edges)\b',re.I)
    for name in ['README.md','final_review.md','model_design.md','oracle_and_operations.md','correction_release_notes.md']:
        assert not obsolete.search((P/name).read_text(encoding='utf-8')),name
    text=(P/'README.md').read_text(encoding='utf-8')
    assert str(counts['tables'])+' proposed tables' in text
    assert str(counts['columns'])+' column definitions' in text
check('ACTIVE_DOCUMENTS_HAVE_CURRENT_COUNTS',current_documents)
def history():
    for name in ['prior_review_2026_10_30.md','audit_findings_2026_11_01.md']:
        text=(P/name).read_text(encoding='utf-8')
        assert 'historical' in text.splitlines()[0].lower()
check('OLDER_REVIEWS_EXPLICITLY_LABELED_HISTORICAL',history)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--archive',help='Optional current organized ZIP to check folder copies, inventory and PPT')
args=parser.parse_args()
if args.archive:
    with ZipFile(args.archive) as archive:files={name:archive.read(name) for name in archive.namelist()}
    def inventory():
        manifest=json.loads(files['PACKAGE_CONTENTS.json'])
        assert set(files)=={item['file'] for item in manifest['files']}|{'PACKAGE_CONTENTS.json'}
        assert all(len(files[item['file']])==item['bytes'] and hashlib.sha256(files[item['file']]).hexdigest()==item['sha256'] for item in manifest['files'])
    check('DISTRIBUTED_INVENTORY_COVERS_EVERY_FILE',inventory)
    def copies():
        complete={name.split('/',1)[1]:data for name,data in files.items() if name.startswith('04_complete_reference/')}
        for folder in ['01_team_review','02_engineering_implementation','03_validation_and_tests']:
            for name,data in files.items():
                if name.startswith(folder+'/'):
                    basename=Path(name).name
                    if basename in complete and basename!='Contents_of_this_pack.md':assert data==complete[basename],name
    check('DISTRIBUTED_SHARED_FILES_MATCH_COMPLETE_REFERENCE',copies)
    def indexes():
        for folder in ['01_team_review','02_engineering_implementation','03_validation_and_tests','04_complete_reference']:
            text=files[folder+'/Contents_of_this_pack.md'].decode('utf-8')
            listed={line[2:].split(' — ',1)[0] for line in text.splitlines() if line.startswith('- ') and ' — ' in line}
            assert listed=={Path(name).name for name in files if name.startswith(folder+'/')},folder
    check('EACH_FOLDER_INDEX_LISTS_EVERY_FILE_ONCE',indexes)
    def guide_index():
        text=files['01_team_review/Start_here_Oracle_FPA_guide.md'].decode('utf-8')
        listed={line[2:].split(' — ',1)[0] for line in text.splitlines() if line.startswith('- ') and ' — ' in line}
        assert {Path(name).name for name in files if name.startswith('04_complete_reference/') and not name.endswith('Contents_of_this_pack.md')}<=listed
    check('SINGLE_GUIDE_DESCRIBES_COMPLETE_REFERENCE_FILES',guide_index)
    def presentation():
        ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
        with ZipFile(io.BytesIO(files['01_team_review/Oracle_FPA_GenBI_leadership_brief.pptx'])) as deck:
            slides=[name for name in deck.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml',name)]
            assert len(slides)==4
            text=lambda i:' '.join(node.text or '' for node in ET.fromstring(deck.read(f'ppt/slides/slide{i}.xml')).findall('.//a:t',ns))
            assert f"{counts['tables']} proposed tables" in text(1) and f"{counts['columns']} documented columns" in text(1)
            assert 'Confirmations needed before production approval' in text(3)
            assert 'Proposed GenBI architecture and answer flow' in text(4)
            assert 'still require implementation' in text(4)
            assert f"{counts['metrics']} metrics + 84 KPI candidates" in text(4)
            assert f"{counts['nodes']} proposed nodes, {counts['edges']} edges" in text(4)
            assert 'No embeddings or live index' in text(4)
    check('PPT_COUNTS_CONFIRMATIONS_AND_PROPOSED_ARCHITECTURE_MATCH',presentation)
    def restrictions():
        for name in ['START_HERE.md','RELEASE_NOTES.md','01_team_review/final_review.md']:
            text=files[name].decode('utf-8').lower()
            assert 'unbound' in text and 'native' in text and ('pending' in text or 'not_run' in text or 'not run' in text),name
    check('CURRENT_ENTRY_DOCUMENTS_RETAIN_MATERIAL_LIMITS',restrictions)
report=dict(release_id=model['release_id'],executed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),counts=counts,archive_checked=bool(args.archive),checks=results,passed=sum(r['passed'] for r in results),total=len(results),scope='Artifact/document consistency only, not native Oracle, real-source or production certification')
(P/'delivery_consistency_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if all(r['passed'] for r in results) else 1)
