> Historical pre-correction audit. Findings F01-F08 are addressed within the supported offline scope in reference-2026-11-01-02. Read correction_release_notes.md and final_review.md for current status.

# Review of the published Oracle FP&A model against its reference workbook

Review date: 1 November 2026

## Decision

Continue development, but correct the structural findings below before freezing the database schema or beginning company-data integration. The package is a useful proposed foundation, not a completed enterprise implementation. Passing its existing tests does not resolve the new counterexamples.

The GitHub package was inspected without changing the published ZIP or repository. This report and the new audit evidence are separate deliverables.

## Exact material reviewed

- Repository: https://github.com/Vishwas2311/oracle-fpa-genbi-reference-model
- Pinned commit: `00da5d1bb862e804a90ab42b7a182f1d57fec3ee`.
- Archive: `Oracle_FPA_team_package_by_folder.zip`.
- Archive SHA256: `4bd22ae02be85fd354e75ba605146a4e08c02c0aa9ceef903933e28b79dbe869`.
- A direct download of the archive at that commit matched the reviewed local bytes: 1,004,805 bytes.
- Reference: `Corporate_Finance_Enterprise_Semantic_Model_v3.xlsx`.
- Verified workbook SHA256: `9ff07cff5bd7540a67193bc29610499a54089951bd32c73d1b90bc1b909f5461`.
- Workbook contents were treated as candidate evidence. Embedded instructions and approval labels were not promoted to user instructions or approved company policies.

## Findings and required improvements

| ID | Priority and timing | Finding | Required improvement |
|---|---|---|---|
| F01 | High, before schema freeze | Release keys and query joins do not consistently support successive immutable releases | Decide stable identity versus release-specific records, then align primary/unique keys, foreign keys and query predicates. Prove R1 and R2 coexist and remain queryable. |
| F02 | High, before MIS plan integration | Plan storage requires an account, while the workbook describes plans/forecasts at report-line grain | Add explicit support for the native report-line grain, preferably as a separate fact when needed. Do not fabricate account-level allocation. |
| F03 | High, before multi-ledger use | Coverage and closing state cannot distinguish two ledgers under the same source/entity/period/currency | Add ledger scope or an explicit coverage scope mapping, then validate dependent queries at that scope. |
| F04 | High, before data publication | Independent foreign keys and diagnostic examples do not form an executable admission/publication gate | Implement rejection/quarantine for incompatible source, batch, currency, release, ledger/calendar and account-chart intersections. Gate queryable publication on successful controls. |
| F05 | Medium, before reference helpers become runtime code | Precision depends on the caller, and helpers accept non-finite Decimal values | Establish an explicit calculation context and finite/range/scale validation at the supported boundary. Test large aggregates, FX products and non-finite inputs. |
| F06 | Medium, before loader reuse | Replay helper omits release while the declared GL unique key includes release | Separate transport replay, source event identity and release-specific materialization. Align the helper and tests with that decision. |
| F07 | High, before any metric certification | Certification validation checks a metric's own flags and policies but not approval/binding of its full dependency chain | Require approved, bound dependencies and compatible lineage/release evidence recursively. Reject false certification. |
| F08 | Medium, before allocation support | Allocation helper preserves the pool total while potentially assigning a negative adjustment to a zero-weight target | Adopt an explicit deterministic residual policy over eligible receivers and verify every allocation line, not just the total. Company allocation policy remains unapproved. |

### F01: release history and query consistency

Evidence: `build_reference.py:24`, `oracle_queries.sql` period/version joins, and generated keys in `canonical_model.json`.

`FPA_PERIOD` carries `RELEASE_ID`, but its primary key is tenant/period and its calendar/sequence unique key also omits release. A copy of the same period for R2 conflicts with R1. However, activity and actual/plan queries require the fact's release to equal the period's release. The current keys allow a fact in R2 to reference a period in R1, and the query then removes that fact from its result.

A synthetic portable constraint test reproduced both the duplicate-period rejection and a stored fact disappearing at the period-release join. This was not Oracle execution. Existing diagnostic SQL catches some mismatches; it does not solve how the second valid release is stored.

Several other stable-identity tables also carry a release field without release-aware primary keys. Review the design consistently rather than adding release to every key blindly. A supported alternative is stable dimensions plus explicit version/publication membership; another is separate stable identity and release-version tables. Document the choice and test rename, correction, restatement and rollback.

### F02: preserve the source planning grain

Evidence: `candidate_policy_review.md` scenarios section, `build_reference.py:32`, `FPA_PLAN` required columns and primary key.

The supplied workbook describes MIS plan and forecast at report-line grain. `FPA_PLAN` requires `ACCOUNT_ID` and has no `REPORT_LINE_ID`. A total planned for a report line containing multiple accounts cannot be loaded faithfully without an additional structure or an explicitly approved allocation.

The original MIS is unavailable, so this is a documented source-grain design gap, not proof of an observed operational load failure. Preserve both supported grains separately if both are needed. Aggregate actuals through an approved account-to-report-line mapping before comparison. A synthetic account such as a balancing bucket would not resolve the semantic issue.

### F03: completeness and close state need sufficient scope

Evidence: `build_reference.py:45`, `FPA_COVERAGE`.

Two ledgers can belong to the same source/entity/period/currency population yet have different completion or closing states. The existing coverage key has no ledger and cannot store those states independently. The synthetic key test reproduced the collision.

The design must either represent ledger-specific assertions or explicitly prove that each coverage assertion applies to the complete associated ledger population. The same decision must reach close checks, queries and answer completeness indicators.

### F04: executable publication controls

Evidence: physical foreign keys; `oracle_validation.sql`; `oracle_and_operations.md` loading requirements; continuation item `EXT.LOADER`.

The portable key/check projection accepted a functional-currency fact whose currency differed from its entity and batch controls, and whose release differed from the referenced period. This demonstrates that individually valid references do not establish a valid combined financial context.

Some relevant diagnostics already exist, and the documentation explicitly assigns responsibilities to future loaders. This finding is therefore partly known unfinished implementation. It becomes a blocking gap if the DDL or query templates are used as a complete loader/reporting system. Do not claim such invalid data has occurred in company records.

Implement the gate with accepted/rejected record and amount conservation, compatible intersections, temporal uniqueness, approved mapping and coverage checks. Queries currently describe preconditions; they do not themselves implement the entire publication gate.

### F05: numerical boundary behavior

Evidence: `reference_engine.py:2–11`; calculation helpers; `run_tests.py` local context; documented precision requirements in `oracle_and_operations.md`.

The golden-case runner sets a 38-digit Decimal context, which is why this finding does not invalidate the rerun golden results. Standalone engine calls depend on the caller's context, normally 28 digits.

Two individually valid proposed money inputs of `99999999999999999999.12345678` produced `199999999999999999998.2469136` through the default-context bridge helper. A 38-digit working calculation produced `199999999999999999998.24691356`. The aggregate also exceeds the proposed storage integer bound and should trigger a deliberate publication range decision instead of silent loss or implicit storage coercion.

The ratio helper also accepted `Infinity` and returned `Infinity`. The answer schema excludes such strings, but validation after calculation is not a substitute for validating numerical inputs. Establish the public entry point, working precision, finite-value checks, output bounds and explicit rounding. The contract should distinguish intentional ratio rounding from unwanted monetary precision loss.

### F06: replay versus new release

Evidence: `reference_engine.py:91–97` and the GL unique key.

The helper identifies an event by tenant/source/ledger/journal/line. Repeating that event in R2 with a release field produces `CONFLICTING_REPLAY`, whereas the model's unique key allows the event in separate releases.

This is a bounded offline helper, not a deployed loader. Before reuse, distinguish a duplicate delivery within one publication from legitimate materialization of the same source event into another immutable release. Do not simply add release to a transport-level deduplication key without defining these layers.

### F07: transitive certification

Evidence: `reference_engine.py:132`, metric dependencies and lineage.

After setting a derived gross-profit metric to approved, source-bound and certifiable and approving its policy records, the validator accepted it even though its revenue and COGS inputs remained proposed/unbound and the lineage table remained unbound.

No current published metric is certified, so no live company certification is alleged. Add dependency-closure and evidence checks before permitting certification to be enabled. A related metric's approval must not be inferred from the parent's label.

### F08: allocation row correctness

Evidence: `reference_engine.py:168–175`.

For a synthetic pool of `0.06`, weights `[0.25, 0.25, 0.25, 0.25, 0]` and the helper's half-even cent rounding, the intermediate allocations become `[0.02, 0.02, 0.02, 0.02, 0]`. Assigning the whole residual to the last row makes the final zero-weight receiver `-0.02`. The helper returns only the conserved total `0.06`, hiding the incorrect receiver behavior.

Allocation is an extension, not an implemented company allocation engine. Test row-level eligibility, sign/range rules, receiver order, total conservation and rounding bounds under a clearly labeled proposed allocation policy. Obtain the company policy before company use.

## Verification performed

| Check | Result | Boundary |
|---|---|---|
| Published archive download and identity | Matched pinned commit and SHA256 | No repository mutation |
| ZIP CRC and inventory | 169 archive entries, all 168 indexed files matched | Inventory excludes itself |
| Saved complete-reference manifest | Passed | Checked before audit-generated reports altered scratch copies |
| Original workbook comparison | All 20,503 populated cells across 57 sheets matched | Raw value/type/format/formula cache, no Excel recalculation |
| Workbook policies and KPIs | 79 evidence references and all 84 raw KPI records matched | Candidate evidence, not company approval |
| Original prompt traceability | 56 sections represented; 13 source/prompt checks passed | Traceability is not full implementation |
| Golden cases | 50/50 passed again | Synthetic reference calculations |
| Metadata mutations | 7/7 passed again | Selected invalid metadata |
| Additional controls | 3/3 passed again | Selected independent checks |
| Contract checks | 90/90 passed again | Schema and selected semantic checks |
| Existing final-review regressions | 12/12 passed again | Previously identified regressions |
| Fresh reconstruction | 11 build/test/verification commands exited successfully | Isolated scratch copy |
| Rebuilt deterministic artifacts | Nine selected model/DDL/dictionary/ERD/join/fixture/case/graph artifacts matched byte-for-byte | Timestamped reports intentionally vary |
| New adversarial probes | Ten probes reproduced gaps, grouped into eight findings | Synthetic and scoped; portable SQL projection is not Oracle certification |

The existing tests passing is compatible with new findings: their tested populations did not include these counterexamples. No overall accuracy percentage is inferred.

## Separate implementation and business dependencies

Existing open engineering work remains: applicable workforce/capital/working-capital/debt/tax/consolidation schedules; source-specific loaders and publication enforcement; executable approved metric recipes; trusted identity and secure query execution; lexical/graph/vector adapters; real end-to-end evaluation.

The graph currently has 31 proposed nodes and 19 dependency edges. Vector work remains metadata/corpus specifications with no generated embeddings, live index or retrieval adapter. These are documented limitations, not evidence of a complete GenBI service.

Original MIS/annexure/process notes, Oracle environment details, actual source samples/mappings, approved formula exceptions, security policies and workload targets remain unavailable. No company policies were invented to close these gaps.

## Recommended order

1. Resolve F01–F03 before the physical model is frozen. Keep all decisions proposed until business evidence supports them.
2. Implement F04 and F07 before publishing company data or enabling certified answers.
3. Correct F05–F06 in the supported runtime/loading boundary and add the reproduced cases as regressions. Correct F08 before allocation support.
4. Regenerate the dictionary, ERD, DDL, joins, graph, fixtures, contracts and affected tests from the maintained source. Update all role copies, counts, presentation claims and checksums where affected.
5. Validate natively on an identified, authorized Oracle environment. Perform real-source reconciliation and finance/security/operations review before release.

No change was pushed by this audit. The source workbook and published reference archive remain unchanged.

## Limits

This was an additional review by the same assistant, not independent finance/security certification. No native Oracle database/driver execution, real-source MIS reconciliation, live identity/revocation test, performance benchmark, Excel recalculation or full natural-language/GenBI benchmark was possible. The new SQL probes used an in-memory SQLite projection only for portable key/check behavior; no Oracle compatibility conclusion follows from them.

