# Workbook intake report

## Identity and authority

Inspected 57 worksheets and 20503 nonempty cells with openpyxl 3.1.5. SHA256: 9ff07cff5bd7540a67193bc29610499a54089951bd32c73d1b90bc1b909f5461. File size: 284127 bytes. Extraction UTC: 2026-10-29T17:52:46.112235+00:00. The supplied copy matches the reference identity. Author/reporting as-of is not an approval. See workbook_manifest.json properties and raw ZIP/cell evidence.

The content is a candidate enterprise semantic catalog, requirements/glossary/source-mapping proposal and mixed-version illustrative reference. The observed catalogs are not a populated operational GL/MIS data extract. Per-sheet profiles preserve header/row/column counts, types, null/distinct values, duplicates, visibility and formula locations. All meaningful cells retain original types, formula/cached distinction, number format and coordinates. No original file was modified, macros/links refreshed, formulas executed or private data sent to research.

## Observed issues

The narrow Subdomain B2:B112 check has 36 unmatched nonblank values and four blanks. Broad full-catalog literal scans performed 3430 candidate reference checks and found 2776 nonmatches. These are diagnostic candidates, not proven dangling foreign keys: displaced, concatenated, polymorphic and continuation fields require reconstruction first. 9 README claimed counts differ from populated catalog-row counts. Physical counts do not prove semantic record counts.

Six cells are stored as formula-like prose and have no cached values. One stored error occurs at 08_Glossary!D94. Preserve these as unvalidated expressions/errors, not executable calculations. Candidate type N/A at 07_Business_Attribute!E2 and residual force-balancing wording at 41_Metric_Component!E16/J17/K17 were reproduced. M067 is absent from the literal metric-ID column. M076/M077 contain displaced/continuation fragments. Repair proposals are separate and none was applied.

## Extraction and feature limits

All worksheets, cells/formula text/caches, number formats, named ranges, tables, merges, hidden dimensions, comments and validation metadata were inventoried. ZIP inspection found no named chart/pivot/cache/external-link/connection/query-table/VBA/model/customXML parts in their conventional package locations. Binary DAX/M/embedded payloads were not decoded, so this is not a universal proof of semantic absence. No visual rendering or recalculation was performed. Cache freshness and original formula/report parity remain unverified. The epoch is 1899-12-30 (Excel 1900 system). Raw values and formats are distinct from rendered strings. The source-annexure epoch is not established by the catalog epoch.

## Safe normalization and intake gate

Keep raw coordinate evidence immutable. Candidate records use source workbook hash/sheet/row/column lineage. Multi-cell narrative fragments are not shifted/repaired automatically. Numeric blanks are never filled down; only verified structural labels may be inherited in future source adapters. Do not load metadata rows as financial facts, or load both report subtotals and their leaf amounts. Source-system labels remain UNBOUND. workbook_to_model.csv inventories candidate header fields; selected_source_to_target_trace.csv explicitly distinguishes target proposals from physical source proof.

Intake gate passed for evidence-backed proposed design. Certification of damaged definitions, source mappings and business policies remains blocked individually. Cosmetic and missing-source issues do not block generic/proposed Oracle engineering.

## Worksheet coverage

| Sheet | Rows incl header | Columns | Formula cells | Stored errors | Visibility |
|---|---:|---:|---:|---:|---|
| 00_README_v3 | 22 | 2 | 0 | 0 | visible |
| 00_README | 51 | 2 | 0 | 0 | visible |
| 01_Domain | 20 | 7 | 0 | 0 | visible |
| 02_Subdomain | 112 | 6 | 0 | 0 | visible |
| 03_Data_Domain | 64 | 8 | 0 | 0 | visible |
| 04_Process | 105 | 9 | 0 | 0 | visible |
| 05_Process_Step | 113 | 7 | 0 | 0 | visible |
| 06_Business_Object | 114 | 9 | 0 | 0 | visible |
| 07_Business_Attribute | 175 | 10 | 0 | 0 | visible |
| 08_Glossary | 107 | 10 | 0 | 1 | visible |
| 09_KPI_Metric | 85 | 12 | 0 | 0 | visible |
| 10_Relationship | 103 | 9 | 0 | 0 | visible |
| 11_Bridge | 52 | 13 | 0 | 0 | visible |
| 12_Source_System | 32 | 7 | 0 | 0 | visible |
| 13_Source_Table | 38 | 8 | 0 | 0 | visible |
| 14_Source_Field | 96 | 10 | 0 | 0 | visible |
| 15_Business_Rule | 85 | 10 | 2 | 0 | visible |
| 16_Data_Quality | 51 | 11 | 0 | 0 | visible |
| 17_Owner_Steward | 40 | 10 | 0 | 0 | visible |
| 18_Code_Set | 48 | 8 | 0 | 0 | visible |
| 19_Hierarchy | 31 | 9 | 0 | 0 | visible |
| 20_Lineage | 36 | 9 | 0 | 0 | visible |
| 21_MECE_Checklist | 30 | 4 | 0 | 0 | visible |
| 22_Automation_Opportunity | 38 | 11 | 0 | 0 | visible |
| 23_Change_Log | 12 | 4 | 0 | 0 | visible |
| 24_Capability | 20 | 8 | 0 | 0 | visible |
| 25_Value_Stream | 16 | 9 | 0 | 0 | visible |
| 26_Business_Event | 17 | 10 | 0 | 0 | visible |
| 27_Semantic_Concept | 31 | 10 | 0 | 0 | visible |
| 28_Predicate_Vocabulary | 36 | 6 | 0 | 0 | visible |
| 29_Term_Synonym | 47 | 7 | 0 | 0 | visible |
| 30_Concept_Context | 20 | 7 | 0 | 0 | visible |
| 31_Finance_Dimension | 28 | 7 | 0 | 0 | visible |
| 32_Dimension_Member | 54 | 11 | 0 | 0 | visible |
| 33_Dimension_Hierarchy | 14 | 10 | 0 | 0 | visible |
| 34_Dimension_Mapping | 21 | 10 | 0 | 0 | visible |
| 35_Accounting_Semantics | 20 | 9 | 0 | 0 | visible |
| 36_Time_Semantics | 19 | 9 | 0 | 0 | visible |
| 37_Currency_FX | 14 | 9 | 0 | 0 | visible |
| 38_KG_Node | 113 | 7 | 0 | 0 | visible |
| 39_KG_Edge | 99 | 7 | 0 | 0 | visible |
| 40_Semantic_Query_Pattern | 15 | 9 | 0 | 0 | visible |
| 41_Metric_Component | 40 | 12 | 4 | 0 | visible |
| 42_Metric_Dimension | 28 | 7 | 0 | 0 | visible |
| 43_Risk | 15 | 12 | 0 | 0 | visible |
| 44_Control_Objective | 18 | 7 | 0 | 0 | visible |
| 45_Control | 20 | 15 | 0 | 0 | visible |
| 46_Control_Evidence | 14 | 10 | 0 | 0 | visible |
| 47_Exception_Remediation | 15 | 12 | 0 | 0 | visible |
| 48_Tax_Semantics | 9 | 13 | 0 | 0 | visible |
| 49_Treasury_Semantics | 9 | 11 | 0 | 0 | visible |
| 50_Security_Privacy | 12 | 15 | 0 | 0 | visible |
| 51_Data_Product | 11 | 13 | 0 | 0 | visible |
| 52_Data_Contract | 10 | 13 | 0 | 0 | visible |
| 53_Semantic_Validation | 14 | 11 | 0 | 0 | visible |
| 54_Reference_Data | 39 | 11 | 0 | 0 | visible |
| 55_Implementation_Roadmap | 23 | 7 | 0 | 0 | visible |
