# Proposed Oracle FP&A data model, candidate policies and offline validation package

Current release: reference-2026-11-01-02, internal contract version 2. Read correction_release_notes.md for audit corrections and breaking schema changes.

Start with final_review.md for the latest prompt/workbook review and corrected defects, then candidate_policy_review.md, model_design.md, oracle_and_operations.md and graph_vector_publication.md. The supplied reference workbook was preserved. Its documented policies are candidate evidence; no company policy, Oracle release or production deployment is approved by this package.

The latest selected core contains 29 proposed tables and 248 column definitions, multiple fiscal calendars and currencies, typed financial hierarchies, journal actuals, coarse budgets/forecasts, MIS reporting lines, source coverage and scoped assumptions. [Configuration](configuration.json) keeps all actual source bindings UNBOUND and separates workbook-derived candidates from the synthetic fixture. Unknown business inputs do not block proposed development.

The [candidate KPI catalog](workbook_kpi_catalog.json) preserves all 84 populated metric rows with raw fields and coordinates. The readable policy review extracts 12 candidate groups and nine clear KPI expressions. It records contradictions instead of silently repairing fields. No workbook record was modified. Calendar/currency/sign values already stated in the workbook are not treated as wholly unknown; their specific unresolved applicability, exceptions and approvals are listed.

Core files:

- canonical_model.json is the single offline model authority. physical_dictionary.csv, physical_erd.mmd, join_registry.json and oracle_ddl.sql are generated from it.
- oracle_queries.sql supplies proposed target templates. oracle_synthetic_seed.sql is an isolated synthetic seed, and oracle_validation.sql supplies native diagnostic examples. All SQL is DRAFT_UNEXECUTED.
- *.schema.json, parameter_dictionary.csv and example intents/results are internal GenBI contracts, not native vendor configuration.
- synthetic_fixture.json, golden_cases.json and question_bank.json contain 50 fully specified executable development cases and 60 unexecuted templates, 110 candidates total.
- test_report.json and contract_test_report.json hold actual observed offline evidence. They do not certify native Oracle, real sources, natural-language interpretation or access enforcement.
- intake_report.md, workbook_manifest.json, workbook_cells.json, workbook_records.json, issue/repair/reference checks and traceability CSVs preserve inspectable source evidence.
- completion_matrix.csv tracks all 56 specification sections. continuation_manifest.json lists remaining enterprise extension and integration work. acceptance_status.json separates design, testing, source binding, native execution and approvals.
- manifest.json provides artifact identity, status and hashes. The broader enterprise scope is tracked, not claimed fully implemented by the bounded core.

## Reproduce offline artifacts and tests

Use Python 3.12+ with requirements.txt in your own environment. Core numerical/metadata tests use the standard library; JSON Schema validation needs jsonschema. The intake reader needs openpyxl. Scripts do not connect to Oracle. From this directory:

```powershell
python build_reference.py
python build_fixture.py
python extract_candidate_policies.py
python assess_intake.py
python build_contracts.py
python build_oracle_fixture.py
python run_tests.py
python test_contracts.py
python test_final_review.py
python test_correction_release.py
python publication_validation.py --input publication_fixture.json
python build_handoff.py
```

The frozen intake JSON is already supplied. inspect_workbook.py can refresh it with an explicitly supplied source path; a replacement workbook requires rechecking all candidate mappings and policies before rerunning publication. Generation does not grant approval or authorize SQL execution. Change canonical definitions in build_reference.py, candidate extraction rules in extract_candidate_policies.py, and frozen approved input profiles separately; do not hand-edit derived DDL or graph files as competing authorities.

Actual observed results are in the test reports. The initial synthetic suite passed 50/50 cases, 7/7 mutations and 3/3 separate controls; the final schema-check count is in contract_test_report.json. Production acceptance remains NOT_APPROVED. Exact remaining confirmations are in assumptions_and_confirmations.md. No universal financial accuracy or Oracle compatibility guarantee is claimed.

The requested words “most, best, bestest prompt, biggest, descriptive, everything” describe the ambition for useful completeness, not an independently measured ranking. The usable result here is a traceable proposed implementation with finite test evidence and explicit remaining work.
