# GenBI metadata, graph and vector publication specification

## Authority and serving boundary

canonical_model.json is the offline authority for proposed selected-core objects; workbook evidence and candidate policy/KPI catalogs are separate namespaces with source coordinates. Oracle FPA_META_OBJECT/FPA_META_EDGE are the proposed runtime publication targets after controlled import. SQL/graph/lexical/vector outputs are derived projections. None may independently change a formula or approval. A source numerical refresh updates watermarks/results, not every unchanged definition embedding.

At present every company metric is proposed/unbound. The certified retrieval corpus is therefore empty. Do not embed the whole workbook or promote Active labels to approval. A design-review index could contain candidate definitions in a separately labeled restricted namespace, but it cannot feed certified financial answers. Original private files were not uploaded to research services.

## Relational graph implementation

Use FPA_META_OBJECT typed nodes and FPA_META_EDGE relationships on the conventional Oracle baseline. graph.schema.json defines the richer internal record; graph.proposed.json is the derived demonstrator, with node/edge versions, validity, provenance, approval and security references. It contains proposed selected-core metrics, facts/dimensions and dependency edges, not every workbook graph record. Numeric facts remain in governed financial tables.

Required node vocabulary includes Metric, Fact, Dimension, Column, Account, ReportingLine, Entity, HierarchyVersion, Policy, ScenarioVersion, Driver, Assumption, Transformation, Source, OwnerRole, VerifiedQuery and TestCase. Extension publication must add these as material objects become defined. Required predicates: depends_on, governed_by, calculated_from, maps_to, approved_by, member_of and tested_by. hypothesized_driver_of is explicitly noncausal. Direction and domain/range validation are part of admission: Metric->Metric/Expression for calculation, Metric->Policy for governance, Mapping->Account/ReportingLine for mapping, Object->TestCase for testing, Object->Source for lineage. Do not treat any metadata edge as a financial join authorization.

Unique key is release/object ID, with versions inside the immutable release; edges require unique release/edge ID and FK endpoints in the same release. Validate node type, edge type, domain/range, endpoint versions, validity intersection, current security eligibility, provenance and allowed traversal. Reject hierarchy cycles and unapproved calculation cycles. No solver exception exists in the selected core. Future approved solver components must collapse into an acyclic component graph with explicit convergence controls.

Traversal use cases: metric->inputs->source lineage; revised policy->dependent metrics->affected tests; entity->approved hierarchy memberships; verified query->metric and join plan. Proposed Oracle traversal template shape:

```sql
-- DRAFT_UNEXECUTED, PROPOSED_TARGET. Preauthorized, version-filtered edge projection required.
SELECT FROM_ID, PREDICATE, TO_ID, LEVEL AS DEPTH
FROM FPA_META_EDGE
WHERE RELEASE_ID = :release_id
START WITH FROM_ID = :object_id AND RELEASE_ID = :release_id
CONNECT BY NOCYCLE PRIOR TO_ID = FROM_ID
  AND PRIOR RELEASE_ID = RELEASE_ID AND LEVEL <= :max_depth;
```

The example is lineage shape only. Runtime must use a permission-filtered edge/node projection before traversal, check each path endpoint, deduplicate canonical paths, bound depth/visited edges/output rows and reject unsupported predicates. Final-result redaction is insufficient. Graph depth/fanout budgets are configuration values to benchmark, not asserted universal settings. Native property graphs/RDF are conditional alternatives requiring actual product/version/privilege evidence. No dedicated graph server is required.

## Lexical and entity resolution

Start with exact canonical IDs and source-scoped aliases. Alias key includes tenant, concept type, domain, language, validity and approval version. Preserve distinct EBITA/EBITDA, gross/net retention, entity/management unit and amount/ratio concepts. Case/spacing normalization applies only when approved. Renames preserve entity IDs. Name collisions across tenants/domains produce authorized ambiguity choices, never cross-scope search. No fuzzy O/0/I/1 repair is automatic. Oracle Text/BM25/fuzzy ranking is optional and implementation-specific, pending feature availability and workload evidence.

## Vector logical contract and optional Oracle adapter

vector_record.schema.json defines chunk/object/type/domain, tenant/security scope, protected approved-text reference, content hash, definition version, validity, approval, authority/provenance, locale/sensitivity, embedding model/version/dimensions/distance, timestamp, generation and tombstone. Physical vectors are intentionally absent from the conventional relational DDL. No model, external endpoint, embedding dimensions, top-k or index algorithm is selected without data residency, language, version and evaluation evidence.

If verified native Oracle vector capability is selected, keep text/provenance/security metadata in a versioned relational projection and add a separate vector table/index adapter pinned to the installed release and COMPATIBLE. Verify documentation against that release, distance metric and query shape. Do not copy 26ai VECTOR syntax into the provisional 19c core. Approximate search needs a measured exact-neighbor reference and selective-authorization-filter tests. An empty eligible corpus returns no context. A bounded supported exact-search retry may help under-retrieval; widening authorization is never a fallback.

Chunk one coherent definition with its formula signature, policy qualifications, grain, permitted dimensions and provenance, using a parent reference when content exceeds the chosen budget. Never split away a denominator qualification. Tune chunk size/overlap/candidate count/top-k/reranker against reviewed authorized questions and context completeness; no arbitrary universal values are prescribed. Numerical facts are queried deterministically, not embedded as an aggregation mechanism.

Embedding migration creates a new generation with compatible query/index preprocessing and model/dimension/distance metadata. Re-embed eligible text only, validate retrieval, publish compatible generation pointer, retain rollback while permitted, tombstone obsolete content and recheck current access on every retrieval. Incompatible model spaces never mix.

## Cross-store release and revocation

Publication unit includes release ID, contract/schema/semantic/policy/hierarchy/template versions, content hashes, applicable data snapshot/watermarks, source bindings, approval states, graph projection, optional lexical/vector generation, embedding metadata and rollback reference. manifest.json inventories actual files and hashes; configuration.json is a proposed settings surface, not approved runtime configuration.

Change event contract: event ID, object/type, old/new version, operation, effective time, recorded time, hash, access/sensitivity change, dependents and rebuild/retest actions. Canonical publisher signs off change, builds derived projections, validates references/security, runs affected tests, stages all generations, then publishes a compatible manifest pointer. Consumers are idempotent by event ID; enforce object-version ordering, retries with bounded deadlines, dead-letter evidence and replay. No distributed atomic commit is presumed.

On failure preserve the last compatible permitted release or block the affected domain. Security revocation takes effect at the current enforcement boundary immediately, independent of embedding refresh or semantic rollback. Invalidate result/discovery/export caches by access revision; remove/tombstone index and graph projections; historical answer reopen/export reauthorizes. A rollback never restores revoked permissions or deleted restricted context. One-use execution permits/private inference/Wren/ArcadeDB are conditional historical options, not existing infrastructure or mandatory services.

## End-to-end demonstrated and stopping examples

Synthetic Q005: trusted fixture analyst T1 scoped to E1/E2 selects proposed revenue, January 2026, actuals and USD. Candidate company policies are not used. Fixture policy supplies 120 USD for E1, 90 EUR for E2 and FX-January multiply-by-2. Independent financial control is 120+90*2=300 USD. Offline result carries fixture/release/metric/rate context, synthetic validation and no production approval. intent.valid.json and answer.valid.json show the envelope. No NLP or native Oracle call occurred.

Company EBITDA question: candidate workbook supports an EBITA spine, generic EBITDA record is damaged/unbound, and D&A/source approval is unavailable. Resolve no certified recipe and return awaiting-data or clarification with the specific metric/source gap. Do not relabel the answer EBITA. answer.stop.json illustrates a nonnumeric stop without exposing restricted data. An unauthorized question returns a minimal unauthorized schema and no restricted object names or values.

Runtime admission still needs actual identity service, secure projections, template compiler/adapter, trusted source snapshot, owner-approved finance policies and native Oracle tests. Offline reference tests demonstrate selected contracts only.
