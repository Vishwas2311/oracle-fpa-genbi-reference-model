"""Assess extracted workbook metadata. Literal checks are candidate defects until alignment is reviewed."""
import collections,csv,json,pathlib,re
P=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_text(encoding='utf-8'))
manifest=load('workbook_manifest.json');records=load('workbook_records.json');issues=[x for x in load('workbook_issues.json') if x['kind'] not in ['status_domain_candidate_anomaly','header_type_alignment_candidate_anomaly']]
def save(n,x):(P/n).write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
catalogs={s['headers'][0]:s['name'] for s in manifest['sheets'] if s['name'][:2].isdigit() and s['name'][:2]!='00' and s['headers'][0]}
aliases={'Object_ID':'Business_Object_ID','Canonical_Object_ID':'Business_Object_ID','Subject_Object_ID':'Business_Object_ID','Object_Object_ID':'Business_Object_ID','Primary_Object_ID':'Business_Object_ID','Produces_Object_ID':'Business_Object_ID','Changes_Object_ID':'Business_Object_ID','Related_Object_ID':'Business_Object_ID','Business_Attribute_ID':'Attribute_ID','Canonical_Attribute_ID':'Attribute_ID','Related_Concept_ID':'Concept_ID','Canonical_Concept_ID':'Concept_ID','Source_Node_ID':'Node_ID','Target_Node_ID':'Node_ID','Parent_Domain_ID':'Domain_ID','Parent_Process_ID':'Process_ID','Predecessor_Event_ID':'Event_ID','Successor_Event_ID':'Event_ID','Parent_Member_ID':'Member_ID'}
idsets={h:{str(r['values'][0]) for r in records[s] if r['row']>1 and r['values'][0] is not None} for h,s in catalogs.items()}
literal_checks=[];classification=[];trace=[]
for s in manifest['sheets']:
    name=s['name'];headers=s['headers']
    if name.startswith('00_'):continue
    for rec in records[name]:
        if rec['row']==1:continue
        v=rec['values'];rid=v[0];coords=f"{name}!A{rec['row']}"
        warnings=[]
        if rid is None:warnings.append('missing_first_column_identifier')
        elif not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',str(rid)):warnings.append('identifier_syntax_candidate_or_non_ID_catalog')
        if any(x==headers[i] for i,x in enumerate(v) if x is not None and i<len(headers)):warnings.append('possible_repeated_header_or_displacement')
        for i,h in enumerate(headers):
            if not h:continue
            target=aliases.get(h,h)
            if target in idsets and i>0 and v[i] is not None:
                matched=str(v[i]) in idsets[target]
                literal_checks.append(dict(sheet=name,row=rec['row'],column=i+1,header=h,raw=v[i],target_sheet=catalogs[target],exact_match=matched,qualification='literal check only; field alignment and polymorphic semantics unverified'))
                if not matched:warnings.append('unmatched_candidate_reference:'+h)
            if h=='Status' and v[i] is not None and v[i] not in ['Active','Draft','Review','Pending','Approved','Deprecated','Inactive']:
                issues.append(dict(id=f'ENUM.{name}.{rec["row"]}',sheet=name,row=rec['row'],header=h,raw=v[i],kind='status_domain_candidate_anomaly',status='unresolved',severity='medium'))
            if h=='Data_Type' and v[i] is not None and not re.match(r'^(string|text|number|decimal|integer|date|timestamp|boolean|varchar|char|numeric|float|clob)',str(v[i]),re.I):
                issues.append(dict(id=f'TYPE.{name}.{rec["row"]}',sheet=name,row=rec['row'],header=h,raw=v[i],kind='header_type_alignment_candidate_anomaly',status='unresolved',severity='high'))
        classification.append(dict(sheet=name,row=rec['row'],raw_id=rid,evidence=coords,classification='unresolved_region' if warnings else 'syntactically_plausible_candidate_record',warnings=warnings,authority='not_business_approved',action='quarantine_for_certification' if warnings else 'retain_candidate_pending_semantic_review'))
    for i,h in enumerate(headers,1):
        if h:trace.append(dict(workbook_sha256=manifest['sha256'],sheet=name,field=h,column=i,source_range=f'{name}!row2:row{s["max_row"]}/column{i}',meaning='candidate '+str(h),target_namespace='workbook_candidate.'+re.sub('[^a-z0-9]+','_',str(h).lower()),source_binding='UNBOUND',transformation='preserve raw value/type/coordinate; no silent repair or financial fact generation',policy_status='UNKNOWN',owner='catalog_steward',issue='see row classifications and literal reference checks',test='INTAKE.LITERAL_REFERENCES',decision='retain_as_evidence'))
repairs=[dict(id='REPAIR.001',coordinates=['02_Subdomain!B2','01_Domain!A2'],raw='DOOI versus D001',proposal='Possible D001 replacement',reason='lexical similarity only; not enough to prove the intended parent',impact='domain assignment and dependent routing',approval='required_catalog_owner',applied=False),dict(id='REPAIR.002',coordinates=['07_Business_Attribute!B2:J3'],raw='Data_Type E2/E3 = N/A with descriptive fragments in adjacent fields',proposal='Reconstruct rows from original attribute inventory, retaining separate alternatives',impact='attribute identity, data typing, source joins',approval='required_source_owner',applied=False),dict(id='REPAIR.003',coordinates=['08_Glossary!D94'],raw='#NAME?',proposal='Recover intended domain reference from original glossary; do not zero-fill',impact='glossary routing',approval='required_catalog_owner',applied=False),dict(id='REPAIR.004',coordinates=['41_Metric_Component!E16','41_Metric_Component!J17:K17'],raw='Rounding residual forced into this component',proposal='Separate economic residual, explicit approved rounding adjustment, and source mismatch; recover displaced component fields before formula use',impact='FX/amount bridge reliability',approval='required_FP&A_controller',applied=False),dict(id='REPAIR.005',coordinates=['09_KPI_Metric!A67:A69','09_KPI_Metric!B76:G77'],raw='M067 absent in candidate ID column; M076/M077 contain concatenated/continuation content',proposal='Recover missing M067 record and reconstruct M076/M077 from originals, without deriving missing formulas from neighbor rows',impact='business expense/profit dependencies',approval='required_metric_owner',applied=False),dict(id='REPAIR.006',coordinates=['00_README_v3!B19'],raw='EBITDA request suggested to be answered as EBITA',proposal='Reject automatic substitution; resolve distinct approved metric or return unsupported/clarification',impact='financial meaning of requested profit measure',approval='design_boundary_from_user_request',applied=False)]
save('literal_reference_checks.json',literal_checks);save('row_classification.json',classification);save('workbook_issues.json',issues);save('repair_proposals.json',repairs)
with (P/'workbook_to_model.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(trace[0]));w.writeheader();w.writerows(trace)
counts=[]
mapping={13:'01_Domain',14:'02_Subdomain',15:'03_Data_Domain',16:'04_Process',17:'05_Process_Step',18:'06_Business_Object',19:'07_Business_Attribute',20:'08_Glossary',21:'09_KPI_Metric',22:'10_Relationship',23:'11_Bridge',24:'12_Source_System',25:'13_Source_Table',26:'14_Source_Field',27:'15_Business_Rule',28:'16_Data_Quality',29:'17_Owner_Steward',30:'18_Code_Set',31:'19_Hierarchy',32:'20_Lineage',33:'21_MECE_Checklist',34:'22_Automation_Opportunity'}
readme={r['row']:r['values'] for r in records['00_README']}
for row,sheet in mapping.items():
    rs=[r for r in records[sheet] if r['row']>1]; ids=[r['values'][0] for r in rs if r['values'][0] is not None]
    counts.append(dict(readme_cell=f'00_README!B{row}',sheet=sheet,claimed=readme[row][1],populated_candidate_rows=len(rs),nonblank_candidate_ids=len(ids),distinct_literal_ids=len(set(map(str,ids))),difference_populated=len(rs)-readme[row][1],qualification='physical counts, not approved reconstructed record counts'))
save('readme_count_reconciliation.json',counts)
summary=dict(candidate_rows=len(classification),literal_checks=len(literal_checks),literal_nonmatches=sum(not x['exact_match'] for x in literal_checks),alignment_caveat='Nonmatches are diagnostic candidates, not proven dangling FKs; displaced and polymorphic fields need review',issues=len(issues),readme_count_discrepancies=sum(x['difference_populated']!=0 for x in counts),repairs_applied=0)
save('intake_assessment_summary.json',summary);print(json.dumps(summary))
