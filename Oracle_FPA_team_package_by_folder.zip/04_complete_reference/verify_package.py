"""Check saved artifact consistency and hashes without connecting to any service."""
import csv,hashlib,json,pathlib,re
P=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_text(encoding='utf-8'))
model=load('canonical_model.json');ddl=(P/'oracle_ddl.sql').read_text(encoding='utf-8')
for f in P.glob('*.json'):json.loads(f.read_text(encoding='utf-8'))
for f in P.glob('*.py'):compile(f.read_text(encoding='utf-8'),str(f),'exec')
with (P/'physical_dictionary.csv').open(encoding='utf-8',newline='') as f:dictionary=list(csv.DictReader(f))
assert len(dictionary)==sum(len(t['columns']) for t in model['tables'])==248
assert len(re.findall(r'^CREATE TABLE ',ddl,re.M))==len(model['tables'])==29
assert len(re.findall(r'^COMMENT ON COLUMN ',ddl,re.M))==248
for t in model['tables']:
    assert all(len(c['name'])<=30 for c in t['columns'])
    for c in t['columns']:assert f"COMMENT ON COLUMN {t['name']}.{c['name']} IS " in ddl
assert len(load('question_bank.json'))==110 and len(load('golden_cases.json'))==50
assert len({q['id'] for q in load('question_bank.json')})==110
assert len(load('workbook_candidate_policies.json'))==12
assert len(load('workbook_kpi_catalog.json')['raw_metric_records'])==84
assert all(not p['business_approved'] for p in load('workbook_candidate_policies.json'))
assert all(b['state']=='UNBOUND' for b in load('configuration.json')['source_bindings'])
assert not load('configuration.json')['publication']['production_approved']
report=load('test_report.json')
assert all(x['passed'] for x in report['cases']+report['mutation_checks']+report['additional_checks'])
assert report['model_sha256']==hashlib.sha256((P/'canonical_model.json').read_bytes()).hexdigest()
assert load('contract_test_report.json')['passed']==load('contract_test_report.json')['total']==96
assert load('final_review_test_report.json')['passed']==load('final_review_test_report.json')['total']==12
assert load('source_prompt_review_report.json')['passed']==load('source_prompt_review_report.json')['total']==13
assert load('correction_test_report.json')['passed']==load('correction_test_report.json')['total']
assert load('correction_test_report.json')['total']>=23
for a in load('manifest.json')['artifacts']:
    assert hashlib.sha256((P/a['path']).read_bytes()).hexdigest()==a['sha256'],a['path']
print(json.dumps(dict(status='saved_artifacts_consistent',tables=29,columns=248,golden_cases='50/50',mutation_checks='7/7',additional_controls='3/3',schema_checks='96/96',source_mappings='UNBOUND',oracle_execution='NOT_RUN',production_approval=False)))
