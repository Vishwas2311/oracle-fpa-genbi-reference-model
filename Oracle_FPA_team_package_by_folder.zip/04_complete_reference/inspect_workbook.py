import collections, datetime, hashlib, json, pathlib, re, sys, zipfile
import openpyxl
from xml.etree import ElementTree as ET

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else (pathlib.Path(__file__).resolve().parent if pathlib.Path(__file__).resolve().parent.name=='oracle_fpa_reference' else ROOT / 'outputs' / 'oracle_fpa_reference')
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path('Corporate_Finance_Enterprise_Semantic_Model_v3.xlsx')
raw = SOURCE.read_bytes()
wb = openpyxl.load_workbook(SOURCE, data_only=False)
cached = openpyxl.load_workbook(SOURCE, data_only=True)
def safe(v):
    return v.isoformat() if isinstance(v, (datetime.datetime, datetime.date, datetime.time)) else v
def save(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str), encoding='utf-8')
manifest = {'file':str(SOURCE), 'sha256':hashlib.sha256(raw).hexdigest(), 'bytes':len(raw), 'extracted_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'reader':'openpyxl '+openpyxl.__version__, 'authority':'unapproved semantic catalog and requirements reference', 'properties':dict(wb.properties), 'epoch':str(wb.epoch), 'calculation':dict(wb.calculation) if wb.calculation else None, 'defined_names': {k:str(v) for k,v in wb.defined_names.items()}, 'sheets':[]}
manifest['properties']={k:safe(getattr(wb.properties,k,None)) for k in ['creator','lastModifiedBy','created','modified','title','subject','description','version']}
cells, records, issues = [], {}, []
for ws in wb:
    nonempty = [c for row in ws for c in row if c.value is not None]
    formulas = [c.coordinate for c in nonempty if c.data_type=='f']
    errors = [c.coordinate for c in nonempty if c.data_type=='e']
    rows = []
    for row in ws:
        if any(c.value is not None for c in row):
            rows.append({'row':row[0].row, 'values':[safe(c.value) for c in row]})
    records[ws.title] = rows
    headers = [safe(c.value) for c in ws[1]]
    profile=[]
    for col in ws.iter_cols(min_row=2):
        vals=[c.value for c in col if c.value is not None]
        counts=collections.Counter(str(v) for v in vals)
        profile.append({'column':col[0].column_letter if col else None, 'header':headers[col[0].column-1] if col else None, 'nonblank':len(vals), 'blank':ws.max_row-1-len(vals), 'distinct':len(counts), 'duplicate_values':{k:n for k,n in counts.items() if n>1}, 'types':dict(collections.Counter(c.data_type for c in col if c.value is not None))})
    info={'name':ws.title,'visibility':ws.sheet_state,'max_row':ws.max_row,'max_column':ws.max_column,'nonempty_cells':len(nonempty),'headers':headers,'formulas':formulas,'errors':errors,'tables':list(ws.tables),'merged':list(map(str,ws.merged_cells.ranges)),'hidden_rows':[i for i,d in ws.row_dimensions.items() if d.hidden],'hidden_columns':[i for i,d in ws.column_dimensions.items() if d.hidden],'autofilter':ws.auto_filter.ref,'validations':[str(v) for v in ws.data_validations.dataValidation], 'chart_count':len(ws._charts), 'pivot_count':len(ws._pivots), 'profile':profile}
    manifest['sheets'].append(info)
    for c in nonempty:
        cells.append({'sheet':ws.title,'cell':c.coordinate,'raw':safe(c.value),'type':c.data_type,'formula':c.value if c.data_type=='f' else None,'cached':safe(cached[ws.title][c.coordinate].value) if c.data_type=='f' else None,'number_format':c.number_format,'comment':c.comment.text if c.comment else None,'hyperlink':c.hyperlink.target if c.hyperlink else None})
        if c.data_type in ('f','e'):
            issues.append({'id':f'CELL.{ws.title}.{c.coordinate}','sheet':ws.title,'cell':c.coordinate,'raw':c.value,'kind':'expression_requires_classification' if c.data_type=='f' else 'stored_excel_error','severity':'high','status':'unresolved','proposed_action':'retain raw evidence; do not execute or publish as approved calculation'})
    if headers and headers[0] and str(headers[0]).lower().endswith('id'):
        counts=collections.Counter(str(ws.cell(r,1).value) for r in range(2,ws.max_row+1) if ws.cell(r,1).value is not None)
        for val,n in counts.items():
            if n>1: issues.append({'id':f'DUP.{ws.title}.{val}','sheet':ws.title,'raw':val,'kind':'duplicate_first_column_candidate_id','count':n,'status':'needs_alignment_review'})
with zipfile.ZipFile(SOURCE) as z:
    names=z.namelist()
    manifest['zip_parts']=names
    manifest['feature_coverage']={
      'worksheets_cells_formulas_caches_formats_comments_tables_names_validation_hidden_merges':'inspected',
      'charts_pivots_external_links_connections':{k:[n for n in names if pattern in n] for k,pattern in [('charts','xl/charts/'),('pivot_tables','xl/pivotTables/'),('pivot_caches','xl/pivotCache/'),('external_links','xl/externalLinks/'),('connections','connections.xml'),('query_tables','xl/queryTables/'),('vba','vbaProject'),('embedded_models','xl/model/'),('custom_xml','customXml/')]},
      'dax_powerquery_binary_payloads':'not decoded; ZIP part inventory only, absence of familiar part names is not proof of semantic absence',
      'formula_recalculation':'not performed; cache freshness unknown',
      'displayed_text':'not rendered; number formats retained, rendered formatting not evaluated'}
    ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    manifest['raw_cell_xml']={}
    for sheet,coord in [('02_Subdomain','B2'),('07_Business_Attribute','E2'),('08_Glossary','D94'),('41_Metric_Component','E16'),('41_Metric_Component','J17'),('41_Metric_Component','K17')]:
        idx=wb.sheetnames.index(sheet)+1
        tree=ET.fromstring(z.read(f'xl/worksheets/sheet{idx}.xml'))
        node=tree.find(f'.//s:c[@r="{coord}"]',ns)
        manifest['raw_cell_xml'][sheet+'!'+coord]=ET.tostring(node,encoding='unicode') if node is not None else None
domains={wb['01_Domain'].cell(r,1).value for r in range(2,wb['01_Domain'].max_row+1)}
sub=wb['02_Subdomain']
unmatched=[{'cell':f'B{r}','raw':sub.cell(r,2).value} for r in range(2,113) if sub.cell(r,2).value is not None and sub.cell(r,2).value not in domains]
manifest['reported_check_reproduction']={'scope':'02_Subdomain!B2:B112 versus 01_Domain column A populated records','unmatched_nonblank':len(unmatched),'blank':sum(sub.cell(r,2).value is None for r in range(2,113)),'unmatched':unmatched}
save('workbook_manifest.json',manifest); save('workbook_cells.json',cells); save('workbook_records.json',records); save('workbook_issues.json',issues)
print(json.dumps({'sha256':manifest['sha256'],'sheets':len(wb.sheetnames),'cells':len(cells),'formula_cells':sum(len(s['formulas']) for s in manifest['sheets']),'error_cells':sum(len(s['errors']) for s in manifest['sheets']),'check':manifest['reported_check_reproduction'],'sheet_headers':[{k:s[k] for k in ('name','max_row','max_column','headers')} for s in manifest['sheets']]},indent=2,default=str))
