# Assumptions, decisions and remaining confirmations

## Confirmed scope and observed evidence

Oracle Database is the primary financial target. This is local design and offline engineering. The reference workbook is unchanged and is a candidate catalog, not an approved report or operational extract. The user has confirmed that version/edition and original referenced files are unavailable and development should continue. No live database access or deployment is requested by the current work.

Candidate business policies already extracted are in candidate_policy_review.md. Do not reopen those as entirely unknown: Jan–Dec YTD, INR/lakh presentation, a 100000 divisor, source negative income/positive expense, EBITA distinctions and line-level planning claims are present in the workbook. What remains unknown is authoritative approval, applicability, missing exceptions and damaged details.

## Configurable assumptions and blocked claims

| ID | Proposed/observed setting | Specific confirmation still needed | Owner | Blocks | Development treatment |
|---|---|---|---|---|---|
| A01 | Oracle conventional relational authoring baseline is 19c only as a proposal | Actual release/RU, edition/service, COMPATIBLE, charset, driver and permitted features | DBA/platform | Native compatibility/execution certification | Generate portable conventional Oracle draft; optional features separate |
| A02 | Workbook Jan–Dec fiscal reporting candidate | Entity/ledger applicability, adjustment periods, close and business timezone | Controller | Certified calendar/time comparisons | Configurable independent calendar/period records |
| A03 | Workbook INR rupee/lakh presentation candidate | Entity currencies, salary amount-column exceptions, rounding stage/mode | Treasury/controller | Certified cross-entity amounts and report parity | Currency/rate/unit fields explicit; no automatic source binding |
| A04 | Workbook source negative income/positive expense | Per-line exceptions, reversals, favorability | Controller/FP&A | Certified presentation/variance | Raw debit/credit independent of report sign policy |
| A05 | Workbook EBITA and candidate P&L formulas | Exact approved recipes, M067 reconstruction, M074 exclusion sign, external lines | KPI owners | Certified MIS/EBITDA/PAT answers | Distinct IDs; candidate and generic metrics never substituted |
| A06 | Sources described in workbook only | Actual source schema, object/column types, sample rows and controls | Source owner | SOURCE_BOUND status and actual correctness | All source object/column fields UNBOUND in configuration.json |
| A07 | Workbook salary matrix vs later Converted INR default conflict | Actual entity-column matrix, currency basis and effective exceptions | Payroll/controller | Salary company calculation | Flag conflict; no guessed column |
| A08 | Workbook 365-day/15th-day salary candidates | Annual versus monthly compensation basis, leap-year/proration/eligible days | Payroll | Salary driver execution | Requirements retained, no formula certified |
| A09 | Prior year is a time comparison; plan/forecast separate | Actual native plan grain, version/approval/vintage/cutover/horizon | FP&A | Certified planning comparison | Versioned consumption model and synthetic examples |
| A10 | Dedicated analytical Oracle schema proposed | Source load/history, approved overlay opportunities, ownership and service cost | Data architecture | Final deployment architecture | Reversible logical/physical proposal |
| A11 | Exact alias and relational graph first; vector optional | Retrieval workload, residency, embedding model, eligible corpus and engine evidence | GenBI/security | Production retrieval configuration | Empty certified corpus; graph prototype only |
| A12 | Entitlements from trusted current identity | Tenant model, row/object policies, compensation inference rules, retention | Security | Access approval/native security | Offline predicate model only; no invented suppression threshold |
| A13 | NUMBER amount/rate/weight bounds proposed | Financial maxima, sum/multiplication headroom, precision and currency minor units | Controller/DBA | Production storage adequacy | Exact Decimal tests and overflow rejection contract |
| A14 | Workload targets unknown | Rows/growth, active peak concurrency, freshness/latency/RPO/RTO/cost | Operations | Scalability/performance acceptance | No invented performance numbers or automatic licensed options |
| A15 | Reporting framework not established | Applicable jurisdiction/framework/adoption/effective and transition periods | Accounting policy | Statutory/IFRS 18 compliance claims | Applicability register design, no jurisdiction assumption |

## Risk and review register

| Risk | Severity | Impact | Evidence/reproduction | Resolution/status |
|---|---|---|---|---|
| Field displacement and malformed IDs | High | Wrong joins, routing or formulas | raw cells, row_classification.json, literal_reference_checks.json | Raw preserved; proposals unapplied; steward reconstruction required |
| Formula-like prose and stored error | High | Unsafe execution or false calculation claims | Six formula cells with empty caches; 08_Glossary!D94 stored error | Never execute; separately classified in workbook_issues.json |
| Residual force-balancing | High | Hides unexplained financial differences | 41_Metric_Component!E16/J17/K17 vs README/BRL048 | Explicit residual design; business repair pending |
| Version/status claims without originals | High | False approval and source certainty | README mixed v2/v3/v4/v5 and static counts | No precedence inferred; authority remains candidate |
| Coarse plan drill/fact fanout | High | Overstated actual or invented budget | Q028/Q035 and comparison checks | Separate aggregation, compatible grain, unmatched rows retained |
| Missing rate/close coverage | High | Invalid comparisons | Q019/Q047 and FPA_COVERAGE design | Stop affected answer; no blanket zero-fill |
| Wrong profit measure | High | EBITDA or PAT mislabeled | README suggested substitutions | Reject substitution; separate definitions and missing-input response |
| Oracle compatibility/security untested | High | Runtime failure or disclosure | All native gates NOT_RUN | Authorized integration phase required |
| Generic financial core mistaken for complete company implementation | High | Premature adoption | Selected-core boundaries and completion matrix | No production approval or universal accuracy claim |

The design was challenged in separate finance, semantic, security and validation passes by the same assistant. No independent agent or human review is claimed. Passing finite synthetic tests does not resolve these risks outside that population.
