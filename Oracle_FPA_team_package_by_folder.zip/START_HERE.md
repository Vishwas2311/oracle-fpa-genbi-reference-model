# Oracle FP&A correction release organized by team folder

Release: reference-2026-11-01-02. Internal contract version: 2. Delivery consistency revision: 2. Proposed, not production approved.

Start with 01_team_review/Start_here_Oracle_FPA_guide.md and correction_release_notes.md. The updated four-slide presentation is 01_team_review/Oracle_FPA_GenBI_leadership_brief.pptx. Slide 3 lists still-pending confirmations. Read 04_complete_reference/final_review.md for the current evidence and remaining work; prior_review_2026_10_30.md and audit_findings_2026_11_01.md are historical.

| Folder | Audience | Contents |
|---|---|---|
| 01_team_review | Finance, FP&A, leadership | Presentation, guide, policies, confirmations and correction notes |
| 02_engineering_implementation | Architects, Oracle and GenBI engineers | Corrected model/SQL, contracts, generators and offline candidate admission |
| 03_validation_and_tests | QA, finance control, security | Synthetic inputs, runnable tests and observed evidence |
| 04_complete_reference | Model owner and steward | Full reference and extracted workbook evidence |

The core has 29 tables, 248 columns and 15 proposed metrics. Graph: 35 proposed nodes and 21 dependency edges. Vector metadata/corpus specifications exist, but embeddings and live retrieval do not. The source workbook is not included and remains unchanged.

The release addresses audit F01-F08 within the supported offline scope. Composite keys are breaking changes: do not execute over existing populated objects without a reviewed migration. All company mappings remain UNBOUND. Native Oracle, source integration, security enforcement, real-source reconciliation and production approval remain pending. The validator never publishes data or confers approval.

Role folders contain duplicate dependencies for convenience; they are not competing editable authorities. The complete-reference manifest verifies that folder only. PACKAGE_CONTENTS.json hashes every other ZIP entry. No nested ZIPs are included. The public copy removes computer-specific paths from two reference files and updates manifests.
