# Oracle FP&A team package organized by folder

This single ZIP contains all previously prepared team packs as ordinary folders. There are no nested ZIP files. Extract the entire archive before opening scripts or related files.

| Folder | Audience | What it contains |
|---|---|---|
| 01_team_review | Finance, FP&A and project stakeholders | The single guide, candidate policy review, pending confirmations, forwarding guidance and a one-line file index |
| 02_engineering_implementation | Architects, Oracle DBAs, data engineers and GenBI developers | Proposed model, SQL, dictionary, relationships, configuration, contracts, generation scripts and implementation notes |
| 03_validation_and_tests | QA, finance control and security reviewers | Frozen synthetic inputs, expected results, offline tests, observed reports and validation protocol |
| 04_complete_reference | Designated model owner and data steward | The complete technical and workbook-evidence snapshot, including the latest final review, original manifest and reproducibility files |

Start with Start_here_Oracle_FPA_guide.md in 01_team_review. Every role folder has its own file list. Where a description discusses an earlier separate pack, the folder with the corresponding name now serves that purpose. The complete reference is preserved unchanged, so some of its older navigation references remain historical.

Some technical files intentionally appear in multiple folders. This keeps the engineering generators and validation tests usable from their respective folders. Edit the maintained canonical source through the designated model owner; do not maintain these distributed copies as separate authorities.

Keep the complete-reference folder intact when running its manifest verification. It contains the supporting raw workbook evidence, so distribute this combined archive only to an internal project group authorized to receive that evidence. Folders organize recipients; they do not enforce access permissions. For a wider audience, share only their appropriate extracted folder.

Current status is proposed design with 27 tables and 233 columns, all company source mappings UNBOUND, and no production approval. Prior observed offline results are 50 golden cases, seven mutation checks, three additional controls and 90 contract checks passing. SQL remains DRAFT_UNEXECUTED. Native Oracle execution, real-source reconciliation and production security validation remain pending.

The final prompt/workbook review is in final_review.md in the role folders. Read it before judging readiness: it records repaired defects, 12 passing new regressions, 13 source/prompt checks and specific remaining enterprise implementation gaps.

The original reference Excel file is not included. Its extracted evidence and identity are retained in 04_complete_reference. No files have been sent to anyone.

PACKAGE_CONTENTS.json lists every other file in this combined archive with its folder, size and SHA256 hash. The file index includes the original reference manifest, while this combined index covers the updated folder-specific navigation documents too.

This public copy removes two local computer paths and updates checksums. See PUBLIC_COPY_NOTES.md.

## Leadership presentation

Open 01_team_review/Oracle_FPA_GenBI_confirmations_updated.pptx for the four-slide model and GenBI overview. Slide 3 lists the remaining confirmations and responsible teams. Candidate policies and production limitations remain explicit.
