# Files in this folder

- Oracle_FPA_GenBI_leadership_brief.pptx — Presents the corrected scope, offline evidence, pending confirmations and intended GenBI architecture in four editable slides.
- Start_here_Oracle_FPA_guide.md — Contains the single plain-language guide to the model, policies, files, test results and next steps.
- Which_files_to_forward_to_the_team.md — Contains Which files to forward to the team for the proposed reference release.
- assumptions_and_confirmations.md — Lists configurable assumptions, specific pending business confirmations, accountable roles and unresolved risks.
- candidate_policy_review.md — Explains workbook-derived calendar, currency, scaling, sign and KPI candidates with conflicts and remaining confirmations.
- correction_release_notes.md — Explains every audit correction, schema compatibility, proposed policies and remaining integration limits.
- final_review.md — Explains the final prompt and workbook review, confirmed corrections, observed test results and remaining implementation work.
- Contents_of_this_pack.md — Lists every included file in one sentence per file.
