This document is included in the combined folder package. Use START_HERE.md at the ZIP root for current navigation.

# Files in this pack

- assumptions_and_confirmations.md — Lists configurable assumptions, specific pending business confirmations, accountable roles and unresolved risks.
- candidate_policy_review.md — Explains workbook-derived calendar, currency, scaling, sign and KPI candidates with conflicts and remaining confirmations.
- final_review.md — Explains the final prompt and workbook review, confirmed corrections, observed test results and remaining implementation work.
- Start_here_Oracle_FPA_guide.md — Explains the complete model, policies, table groups, file purposes, tests and next steps.
- Which_files_to_forward_to_the_team.md — Explains which pack each team role should receive and what feedback is needed.
- Contents_of_this_pack.md — Lists every included file with a one-sentence description.
