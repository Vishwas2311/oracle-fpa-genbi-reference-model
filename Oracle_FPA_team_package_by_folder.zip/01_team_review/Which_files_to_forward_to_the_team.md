# Which files to forward to the team

Use the single combined ZIP and forward the appropriate extracted folders. The same ZIP is intentionally available in the public repository.

| Recipient | Folder | Purpose |
|---|---|---|
| Finance, FP&A, leadership | 01_team_review | Updated four-slide presentation, guide, candidate policies, confirmations and correction notes |
| Architects, Oracle and GenBI engineers | 02_engineering_implementation | Corrected 29-table/248-column design, SQL, contracts and offline candidate validator |
| QA, finance control, security | 03_validation_and_tests | Frozen synthetic inputs, tests and bounded offline evidence |
| Model owner/data steward | 04_complete_reference | Complete maintained reference snapshot and extracted workbook evidence |

All source mappings remain UNBOUND and all SQL remains DRAFT_UNEXECUTED. Current observed results: 50 golden, 7 mutation, 3 additional, 96 contract, 12 earlier regression, 25 correction regression and 13 source/prompt checks passed. Native Oracle, actual sources and production approval remain pending. Version 2 changes composite keys and is not an automatic in-place migration.
