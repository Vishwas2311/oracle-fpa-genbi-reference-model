This document is included in the combined folder package. Use START_HERE.md at the ZIP root for current navigation.

# Which files to forward to the team

Use the team review folder first. Send the engineering and validation packs only to the people doing those jobs. The complete original archive is for the designated model owner or data steward when full workbook evidence is needed.

## Recommended folder access

| Recipient | Use this folder | What they should do |
|---|---|---|
| Finance reviewers, FP&A owners and project stakeholders | 01_team_review folder | Read the single guide and review the workbook candidate policies, conflicts and pending confirmations |
| Data architects, Oracle DBAs, data engineers and GenBI developers | 02_engineering_implementation folder | Review and develop the proposed schema, source bindings, SQL, metadata and integration contracts |
| QA, financial control and security validation reviewers | 03_validation_and_tests folder | Inspect expected results, reproduce offline tests and plan the unexecuted native and business checks |
| Designated model owner or data steward who needs complete original evidence | 04_complete_reference folder | Trace workbook coordinates, inspect raw extraction, investigate catalog defects and maintain the complete source package |

Each recipient should use the folder for their role. If one technical lead is responsible for implementation and validation, that person can receive both relevant packs. General reviewers need only the first pack to understand the proposal and give business feedback.

## What each pack contains

01_team_review folder contains five documents: the single plain-language guide, the candidate policy review, the assumptions and confirmations register, this forwarding note, and the latest final review; it also has a file contents index.

02_engineering_implementation folder contains the proposed canonical model, full table and column dictionary, relationships, diagram source, configuration, Oracle scripts, GenBI contracts, graph/vector specification, generation scripts and a pack-specific README.

03_validation_and_tests folder contains the frozen synthetic fixture, golden cases, candidate question bank, reference calculator, test runners, required model/configuration/schema inputs, observed test reports and evaluation protocol, with a pack-specific README.

04_complete_reference folder is the complete technical and workbook-evidence snapshot, including the latest final review and regression checks. It does not contain this forwarding note or the separate single guide. Use the review pack for those explanations.

The smaller packs deliberately exclude raw workbook_cells.json and workbook_records.json. They also exclude the original all-artifact manifest because a subset archive must not imply that every original artifact is present. Each smaller archive includes a contents list with one sentence per included file. Detailed workbook reconstruction and full evidence regeneration require the original archive and the reference workbook.

## Suggested message to accompany the review pack

Please review the proposed Oracle FP&A model using the enclosed single guide. Focus on the documented calendar, currency and scaling, sign conventions, KPI definitions and unresolved conflicts. The design and source mappings remain provisional. The synthetic tests have passed, but Oracle execution, real-source reconciliation and production approval remain pending. Please return corrections against the specific candidate policies and confirmations rather than treating the workbook status labels as approval.

## Current status

The package contains a proposed financial core with 27 tables and 233 documented columns. Observed offline results are 50 of 50 golden cases, seven of seven mutation checks, three of three additional controls and 90 of 90 contract checks. These results do not demonstrate native Oracle compatibility or production access enforcement. The 60 additional question templates are not executed benchmark results.

All company source bindings remain UNBOUND. Workbook-derived candidates, proposed definitions and synthetic data are separate. None of these archives is an instruction to execute SQL in a live Oracle environment.

No files have been sent to anyone. These folders are combined in one ZIP for the project team.
