# Correction release for the published model audit

Release: reference-2026-11-01-02. Internal contract version: 2. Status: proposed, not production approved.

The current selected core has 29 tables, 248 columns and 15 proposed metric contracts. The additional tables are FPA_ENTITY_ID (stable legal identity) and FPA_PLAN_LINE (native report-line planning). Graph projection: 35 proposed nodes and 21 depends_on edges. No embeddings or live vector index exist.

| Audit finding | Correction | Evidence |
|---|---|---|
| F01 release/history mismatch | Release-specific tables use release-aware PKs, UKs and FKs. FPA_ENTITY_ID holds stable identity. Entitlements reference it independently of financial releases. GL physical identity additionally includes ledger. | Two-release relational regression retains all 28 fixture journal rows in each release and two current entitlements. |
| F02 report-line planning | FPA_PLAN_LINE stores entity/ledger/report-line/period/currency/version amounts with no account field. Account plans remain in FPA_PLAN. Two separate metric contracts expose native line budgets and forecasts. | Native-line plan survives without any account-plan rows. A separate proposed query aggregates actuals through admitted report mappings. |
| F03 ledger coverage | LEDGER_ID is required in coverage identity and relationships. | Separate complete/closed and partial/open states coexist across two ledgers. |
| F04 publication admission | Compound FKs align GL functional currency and batch/source/currency context. Ledger COA_ID enables chart checks. An executable offline candidate validator checks typed fields, references, release, ledger/calendar/chart, source origin, journal balance, batch amounts/counts and supported temporal overlaps. | Valid fixture passes; incompatible populations and controls are rejected. |
| F05 numerical boundaries | Public arithmetic entry points establish their own 38-digit working context. Inputs reject binary floats, NaN and Infinity. Storage validation rejects out-of-range amounts and scale loss. | Caller precision cannot silently weaken the tested calculation; invalid values and storage overflow fail explicitly. |
| F06 replay boundaries | Release is required for materialized-event deduplication. Transport batch/delivery IDs do not change event payload identity. | Same-release replay collapses, conflicting payload rejects, and a new release coexists. |
| F07 transitive certification | Dependency closure checks metric approval/binding, policy approval/binding and lineage-table approval/binding. Empty approved-recipe placeholders cannot certify. | Unapproved dependencies and unbound lineage reject; a fully marked synthetic approval scenario passes only its offline invariant test. |
| F08 allocation rounding | Explicit proposed fixture policy uses signed-cent largest remainder over positive-weight receivers, with input-order tie resolution. | Positive, negative and zero pools conserve totals without assigning residuals to a zero-weight receiver. |

## Admission scope and limits

Run `python publication_validation.py --input publication_fixture.json` to validate the supported synthetic candidate. It does not connect to a database, write data, authenticate anyone, approve a policy or publish a release. The returned production_approved value is always false. The CLI mode company_candidate rejects unverified sources, unbound populated targets and unapproved policies; authoritative verification of those assertions remains an integration responsibility.

Supply the complete candidate/reference snapshot and explicit release ID. Foreign-key validation is release-aware. The supported batch-control path is journal batches with no unreconciled rejected amounts. Any nonempty rejected population blocks this candidate until an explicit rejected-amount reconciliation adapter exists. Empty/non-journal batch scopes are rejected instead of silently certified. Hierarchy-edge and assumption admission domains currently reject as unsupported. Source-specific extraction, generalized hierarchy/intersection enforcement, approved MIS mapping scope, native security and atomic database publication are still future integration work.

Coverage can distinguish ledgers, but an approved close policy still determines whether open or soft-closed data is eligible for a particular answer. The validator requires a watermark for COMPLETE/ZERO_ACTIVITY assertions; it cannot independently prove source completeness. Native report-line plans do not establish complete statement recipes, account allocations or an approved company planning grain.

Working precision and storage precision are distinct. The proposed money storage remains NUMBER(28,8). The supported storage boundary rejects excess integer digits or fractional scale rather than silently rounding. Currency minor-unit rounding remains a business confirmation. The allocation cent/tie policy is synthetic/proposed only, not a company default. Large FX/aggregate workloads still require native range/driver testing.

## Breaking schema changes

Version 2 is a breaking proposed physical design. Do not run its CREATE TABLE statements over existing populated objects. No destructive reset or automatic ALTER migration is supplied. No database was deployed by this project. If another team deployed version 1, inventory that schema, retain a backup/snapshot, and implement an authorized migration in an isolated environment before switching consumers. Composite release-aware keys require all loaders, joins, seeds, projections, tests and cache/publication identities to use the same version.

FPA_ENTITY_ID is stable and tenant-scoped. FPA_ENTITY now represents functional-currency/source attributes in a release; its canonical legal ENTITY_ID remains stable. Label history remains in FPA_ENTITY_VER. Current entitlements refer to the stable identity and never inherit an old financial release's access policy. FPA_CURRENCY remains a shared configured denomination registry, not a release-versioned policy table.

## Reproduce

Use requirements.txt in a separate Python environment. Run the existing three suites and `python test_correction_release.py`. Generate the typed admission fixture with build_oracle_fixture.py after rebuilding the canonical model and synthetic fixture. The correction suite includes in-memory SQLite projections only for portable PK/UK/FK/check semantics; these are not Oracle compatibility tests.

Company sources remain UNBOUND. All company metric certification stays disabled. Original MIS/annexure/process files and Oracle environment details remain unavailable. The wider enterprise implementation, native Oracle validation, trusted identity/security integration, real-source reconciliation, live GenBI retrieval and accountable production acceptance remain open.
