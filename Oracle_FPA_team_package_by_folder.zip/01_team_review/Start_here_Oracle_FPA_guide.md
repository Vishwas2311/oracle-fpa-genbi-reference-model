This document is included in the combined folder package. Use START_HERE.md at the ZIP root for current navigation.

# A single guide to the Oracle FP&A model and its supporting files

This document explains what was created, how the pieces fit together, what the workbook already tells us, and what remains to be validated. You can read this guide without opening the SQL, JSON or Python files. Those files are the detailed definitions, proposed implementation and supporting evidence.

The current result is a proposed financial data model with working offline reference tests. It contains 27 proposed database tables and 233 documented columns. It has not been deployed to Oracle or connected to company financial sources. Workbook-derived policies, proposed design decisions and synthetic test data remain separate.

The final review on 30 October 2026 rechecked the original prompt and Excel, found and corrected calculation/validation defects, and added 12 passing regression checks and 13 passing source/prompt checks. Read final_review.md for the corrections and remaining gaps. The wider enterprise specification is still only partially implemented; the current core is suitable for further engineering and design review, not production release.

## 1 What the system is intended to do

The model is intended to give finance reporting and a future natural-language BI application a consistent financial foundation. It organizes actuals, budgets, forecasts, reporting periods, currencies, organizational hierarchies and MIS definitions so that a question can resolve to a controlled calculation.

For example, “What was January revenue against budget?” needs more than two amounts. It needs the legal entities, ledger, reporting calendar, revenue definition, currency, approved budget version and the caller's access rights. The model records these distinctions instead of allowing each report or AI answer to choose them differently.

The intended flow is:

1. Receive financial data from an authorized source.
2. Check its identity, completeness, types and control totals.
3. Separate accepted records from records needing correction.
4. Store financial records at their declared level of detail.
5. Apply the relevant versioned finance definitions and reporting mappings.
6. Resolve an authorized question to a supported calculation.
7. Return numbers together with their units, scope, source context and validation status.

The current package supplies the proposed structure, contracts, SQL drafts and an offline demonstration of selected rules. The real source connectors and the production GenBI application remain implementation work.

## 2 The three kinds of information in the package

| Kind | Meaning | Example | How to use it |
|---|---|---|---|
| Workbook-derived candidate | A statement actually found in the supplied Excel, with coordinates | January–December YTD reporting | Use as a documented candidate and confirm applicability or conflicts |
| Proposed design | A structure or rule introduced for the target model | Separate journal and balance tables | Review and refine before implementation approval |
| Synthetic data | Invented, explicitly labeled values used for controlled tests | Two test entities using USD and EUR | Demonstrate calculations without treating the amounts as company facts |

An observation that the workbook says “Approved” is evidence of that text. It does not establish that a finance owner actually approved the definition. Similarly, a passing synthetic test is evidence about that finite test, not proof of company financial correctness.

## 3 What the workbook already documents

The reference Excel was inspected across all 57 sheets and preserved unchanged. It is a semantic catalog and requirements reference, with damaged and displaced fields in some records. It does not contain the original supporting MIS, annexure and process-note files mentioned in its descriptions.

The extraction preserves all 84 populated candidate KPI rows. Twelve policy groups and nine readable KPI expressions are separately documented so that damaged fields are not silently converted into executable logic.

| Area | Documented candidate | Specific remaining issue |
|---|---|---|
| Calendar | January–December reporting year; YTD begins in January; FTM means for the month | Which entities and ledgers use it; close, adjustment-period, timezone and partial-period rules |
| Currency and scale | MIS in INR lakhs or Rs Lacs; referenced annexure in rupees; divide by 100000 for like-for-like comparison | Entity currency basis, rounding mode and rounding stage |
| Salary amount selection | An entity-specific amount-column matrix is referenced | Reconcile its exceptions with later guidance favoring Converted INR |
| Source signs | Income negative and expense positive in the referenced annexure | Account exceptions, reversals, presentation signs and variance favorability |
| Profit measures | An EBITA reporting spine; depreciation remains within non-staff cost | Exact approved recipes and external inputs; EBITDA must remain distinct |
| Ratio denominators | Income including forwards is proposed for specified MIS ratios | Broad denominator wording conflicts with Actual/Plan and Actual/Forecast definitions |
| Percentages | Fractions stored as decimals, with percentage display applied once | Exceptional baselines and allegedly inconsistent stored growth calculations |
| Scenarios | Referenced annexure actuals-only; MIS plan and forecast at report-line level | Actual source grain, version history, approvals and forecast cutover |
| Salary drivers | A 365-day expression and 15th-day recognition cutoff are described | Annual versus monthly compensation basis, leap years and proration |
| Reconciliation | Fee tolerance below 0.01 INR lakh; salary drivers plus disclosed residual reconcile variance | Rounding boundaries and conflicting force-balancing wording |

Readable candidate formulas include:

- Total staff cost equals FBC plus incentives, fringe, other compensation and other staff costs.
- Business EBITA equals total income including forwards less total business expense.
- Net EBITA equals business EBITA less corporate allocation.
- PBT equals EBITA including SEIS less amortisation and finance cost plus other income.

These are candidate expressions extracted from workbook text. They are not approved company calculations. A missing component, damaged definition or unresolved sign still prevents certified execution of the affected measure.

The detailed policy review identifies each claim's exact workbook coordinates and remaining confirmation. You do not need to rediscover the stated calendar, scale or sign conventions from scratch.

## 4 How the 27 tables fit together

A table is a structured collection of records. Its “grain” means what exactly one record represents. Keeping different grains separate prevents double counting.

### Financial records

| Table | What it represents |
|---|---|
| FPA_GL_LINE | One accepted journal line with separate debit and credit values |
| FPA_BALANCE | One account-period closing snapshot with opening and movement values |
| FPA_PLAN | One planned amount by entity, ledger, account, period, currency and version |
| FPA_ASSUMPTION | One scoped numeric driver or explicitly unresolved assumption |
| FPA_FX_RATE | One conversion rate with its pair, date, type and rate version |

Actuals and plans can be compared only at dimensions supported by both. A monthly entity/account budget does not create a product-level budget. A closing balance is selected for a date or period and cannot be summed across successive snapshots.

### Business identity and time

| Table | What it represents |
|---|---|
| FPA_ENTITY | Stable legal entity identity |
| FPA_ENTITY_VER | Effective and recorded history of entity labels |
| FPA_ACCOUNT | Canonical account identity and accounting classification |
| FPA_LEDGER | Ledger and accounting-basis context |
| FPA_CALENDAR | Independently governed fiscal calendar |
| FPA_PERIOD | Period boundaries, sequence and fiscal labels within a calendar |
| FPA_CURRENCY | Configured currency denomination and presentation precision |
| FPA_VERSION | Budget or forecast version, availability time, state and actual cutoff |

Multiple calendars and currencies can coexist. Names are labels, not dependable join keys. Version history prevents a later forecast from replacing the forecast that was actually available at an earlier decision date.

### Hierarchies and MIS presentation

| Table | What it represents |
|---|---|
| FPA_HIER_VERSION | A named legal, management, account, reporting or other financial hierarchy version |
| FPA_HIER_NODE | A typed hierarchy member, including intermediate parents |
| FPA_HIER_EDGE | An effective parent–child relationship and any permitted weight |
| FPA_REPORT_LINE | An ordered MIS or statement line, subtotal or ratio |
| FPA_REPORT_MAP | Effective account-to-report-line mapping and presentation sign |

These tables separate legal identity from management reporting. They support historical and restated reporting designs. Loaders must still check cycles, temporal overlaps and weights. A foreign key alone does not prove a hierarchy is financially correct.

### Control and governance

| Table | What it represents |
|---|---|
| FPA_RELEASE | A versioned publication of compatible model and policy definitions |
| FPA_SOURCE | A registered source and its actual-source or synthetic classification |
| FPA_POLICY | A versioned finance or reporting policy and approval state |
| FPA_BATCH | An extraction/load batch with source cutoff and control totals |
| FPA_QUARANTINE | Rejected rows with their reason and retained evidence |
| FPA_COVERAGE | Completeness, zero activity, missingness and close status |
| FPA_ENTITLEMENT | Current trusted principal-to-entity access rights |
| FPA_META_OBJECT | Published metric, expression, policy or other metadata definition |
| FPA_META_EDGE | Typed dependencies and provenance between metadata objects |

Missing data and a real zero are different states. Rejected records remain visible for remediation. Historical semantic releases never restore access that has since been revoked.

## 5 What GenBI metadata graph and vector mean here

GenBI is the intended natural-language reporting application. The metadata tells it what a metric means, which dimensions are allowed, which joins are safe, what context is required and what evidence must accompany an answer.

A structured intent records the resolved meaning of a question before calculation. An answer envelope records the result, units, metric version, snapshot, completeness and limitations. JSON Schema files check the structure of these records. Further application and database checks must enforce their meaning and current permissions.

The graph represents relationships such as “this metric depends on these inputs.” It supports lineage and change-impact review. It does not calculate financial totals or permit arbitrary joins.

Vector retrieval is an optional future way to find relevant approved definitions from natural-language questions. No embedding model, vector index or production vector service has been selected or deployed. The present design begins with relational metadata and exact approved aliases. The certified retrieval corpus is empty because company definitions have not been approved and source-bound.

All three paths must use the same governed definitions. A vector match or graph connection does not prove that a financial amount is correct.

## 6 What was tested and what the results mean

| Check | Observed result | Scope |
|---|---:|---|
| Fully specified synthetic cases | 50 of 50 passed | Selected arithmetic, time, FX, version, scope and failure behaviors |
| Metadata mutation checks | 7 of 7 passed | Deliberately malformed definitions were rejected |
| Additional independent controls | 3 of 3 passed | Account totals, unmatched comparisons and margin aggregation |
| Contract and schema checks | 90 of 90 passed | Valid examples accepted and specified invalid examples rejected |

There are 110 candidate questions in total. Fifty are executable development cases. Sixty are templates with explicit missing inputs or runtime dependencies. They have not been evaluated as a production natural-language benchmark.

One hand-verifiable example translates synthetic January revenue: entity E1 has 120 USD; entity E2 has 90 EUR; the synthetic EUR-to-USD rate is 2. The result is 120 + 90 × 2 = 300 USD. That proves the chosen fixture calculation. It says nothing about the company's January revenue or actual exchange rates.

No live Oracle DDL, query, driver round-trip, native access control, workload performance or real-source reconciliation was tested. No finance or production sign-off is claimed.

## 7 Which files to open for each purpose

You can use this guide as your main document and open other files only when you need implementation detail.

| Your purpose | Relevant files |
|---|---|
| Read the workbook policies and conflicts | candidate_policy_review.md; workbook_candidate_policies.json; workbook_kpi_catalog.json |
| Understand the detailed model and decisions | model_design.md; assumptions_and_confirmations.md |
| See each table, column, type and relationship | canonical_model.json; physical_dictionary.csv; physical_erd.mmd; join_registry.json |
| Review proposed Oracle scripts | oracle_ddl.sql; oracle_queries.sql; oracle_validation.sql; oracle_synthetic_seed.sql |
| Configure future sources and candidate settings | configuration.json; source_binding.schema.json |
| Understand Oracle compatibility and operations | oracle_and_operations.md |
| Understand GenBI discovery and publication | graph_vector_publication.md; parameter_dictionary.csv; graph.proposed.json; the schema and example JSON files |
| Inspect test inputs and expected results | synthetic_fixture.json; golden_cases.json; question_bank.json |
| Inspect actual test evidence | test_report.json; contract_test_report.json; oracle_seed_static_report.json |
| Inspect the original workbook evidence | intake_report.md; workbook_manifest.json; workbook_cells.json; workbook_records.json |
| Review defects and proposed repairs | workbook_issues.json; repair_proposals.json; row_classification.json; literal_reference_checks.json; readme_count_reconciliation.json |
| Trace workbook fields into proposed objects | workbook_to_model.csv; selected_source_to_target_trace.csv; workbook_coverage_extensions.csv |
| Review capability and research coverage | capability_process_bus.csv; capability_evidence_matrix.csv; research_register.json |
| See completion and remaining work | completion_matrix.csv; continuation_manifest.json; acceptance_status.json; evaluation_protocol.md |
| Rebuild or verify the package | README.md; requirements.txt; the Python build, extraction, test and verification scripts |
| Check artifact identity and hashes | manifest.json |

The SQL files define proposed Oracle structures and query shapes. JSON files contain machine-readable definitions, configuration, examples or evidence. CSV files are catalogs and traceability tables that can be opened in Excel. Python files generate or test the artifacts. Markdown files provide the explanations.

You do not need to run any script to read or understand this guide. Do not interpret a generated SQL file as evidence that it has already run.

## 8 What happens next

Further proposed development can continue with configurable inputs. The next implementation work includes source-specific loaders, stronger publication/admission checks and any applicable workforce, capital, working-capital, tax, debt and integrated-statement schedules. Those wider enterprise areas are tracked as extensions and are not fully implemented by the current core.

Before real company use, the following specific dependencies must be resolved:

1. Identify the Oracle release, edition/service, driver, permitted features and authorized test environment.
2. Confirm the applicability and exceptions of the workbook-derived policies, including salary amount columns, metric denominators and damaged profit definitions.
3. Configure real source objects and fields from evidence. All current source bindings are UNBOUND.
4. Reconcile loaded amounts to authoritative reports and approve the relevant definitions.
5. Implement and validate the production identity, secure serving, query compilation and GenBI integration paths.
6. Execute native Oracle, security, performance and end-to-end business tests before release approval.

The original MIS, annexure and process notes are currently unavailable. Their absence is recorded and does not prevent proposed development. It does prevent claims that their source fields, formulas or report totals have been independently verified.

The present package is ready for design review and further engineering. Production acceptance remains pending.

## 9 Complete file index with one sentence per file


Each entry below is one sentence describing one file.

- Start_here_Oracle_FPA_guide.md — Contains the single plain-language guide to the model, policies, files, test results and next steps.
- 04_complete_reference folder — Contains the complete downloadable implementation package and its supporting evidence.
- acceptance_status.json — Records separate statuses for inspection, design, testing, source binding, Oracle execution and production approval.
- answer.schema.json — Defines the permitted structure of numeric answers, partial results, clarification requests and failure responses.
- answer.stop.json — Provides an example response that stops because required company data or approved policies are unavailable.
- answer.valid.json — Provides a valid synthetic answer with amounts, units, source context, completeness and validation status.
- assess_intake.py — Checks extracted workbook records for candidate reference mismatches, alignment problems, status anomalies and count discrepancies.
- assumptions_and_confirmations.md — Lists configurable assumptions, specific pending business confirmations, accountable roles and unresolved risks.
- audit_source.py — Rechecks every extracted workbook cell and policy evidence reference against supplied source files and reviews all original prompt sections.
- build_contracts.py — Generates GenBI JSON schemas, example requests and answers, proposed graph records and the parameter dictionary.
- build_fixture.py — Generates synthetic financial data, 50 executable golden cases and the 110-question candidate bank.
- build_handoff.py — Generates intake summaries, capability catalogs, traceability, completion records and the artifact manifest.
- build_oracle_fixture.py — Generates the synthetic Oracle seed script and checks its required fields, primary keys and foreign references offline.
- build_reference.py — Defines the canonical model and generates the proposed Oracle DDL, physical dictionary, ER diagram and join registry.
- candidate_policy_review.md — Explains workbook-derived calendar, currency, scaling, sign and KPI candidates with conflicts and remaining confirmations.
- canonical_model.json — Contains the proposed tables, columns, keys, constraints, policies, metrics, aggregation rules and model scope.
- capability_evidence_matrix.csv — Connects selected business capabilities to primary documentation, implementation gaps, Oracle implications and test references.
- capability_process_bus.csv — Lists 18 finance capabilities with decisions, personas, inputs, workflows, owners, cadence and acceptance criteria.
- completion_matrix.csv — Tracks all 56 specification sections against artifacts, validation evidence, current status and remaining work.
- configuration.json — Separates workbook candidate policies, unbound source mappings, synthetic settings and publication restrictions.
- continuation_manifest.json — Lists completed core work and the exact remaining model, loader, Oracle, GenBI, evaluation and approval tasks.
- contract_test_report.json — Records the observed results of 90 positive and negative JSON contract checks.
- evaluation_protocol.md — Defines evaluation measures, native Oracle test gates, prompt comparison rules and the proposed rollout sequence.
- extract_candidate_policies.py — Extracts coordinate-backed workbook policy and KPI candidates while preserving conflicts and generating configuration.
- final_review.md — Explains the final prompt and workbook review, confirmed corrections, observed test results and remaining implementation work.
- final_review_test_report.json — Records the results of 12 regression checks added during the final review.
- golden_cases.json — Contains 50 executable synthetic cases with questions, interpretations, inputs, expected results or errors and tolerances.
- graph.proposed.json — Contains the proposed selected-core graph nodes and dependency edges with versions, provenance and approval states.
- graph.schema.json — Defines the required fields and allowed record types for internal graph nodes and edges.
- graph_vector_publication.md — Specifies metadata authority, graph relationships, optional vector retrieval, publication, synchronization and revocation controls.
- inspect_workbook.py — Reads the reference workbook without executing its content and exports its structure, cells, profiles and initial issues.
- intake_assessment_summary.json — Summarizes candidate record counts, literal reference checks, detected anomalies and unapplied repairs.
- intake_report.md — Explains the workbook inspection, authority limits, observed defects, normalization rules and coverage of all 57 sheets.
- intent.invalid.json — Provides an intentionally invalid certified request with an unresolved business-policy choice.
- intent.schema.json — Defines the structure of a resolved GenBI request including metrics, grain, time, scenario and reporting context.
- intent.valid.json — Provides a valid synthetic request for January revenue translated into USD.
- join_registry.json — Lists proposed foreign-key join contracts with cardinality, tenant requirements, temporal conditions and fanout restrictions.
- literal_reference_checks.json — Preserves individual workbook reference comparisons with raw values and qualifications about unverified field alignment.
- manifest.json — Inventories package artifacts with identifiers, purposes, statuses, ownership notes, file sizes and SHA256 hashes.
- metric.schema.json — Defines the structure of metric contracts including expressions, policies, grain, aggregation, scope and certification state.
- model_design.md — Explains the architecture, financial grains, relationships, planning rules, MIS reporting, GenBI behavior and scope boundaries.
- oracle_and_operations.md — Documents provisional Oracle compatibility, data types, loading, typed binds, security, consistency, performance and recovery requirements.
- oracle_ddl.sql — Contains unexecuted proposed Oracle table definitions, constraints, comments, foreign keys and a candidate filter index.
- oracle_queries.sql — Contains unexecuted proposed Oracle templates for GL activity, compatible actual-versus-budget comparisons and closing balances.
- oracle_seed_static_report.json — Records offline structural and reference checks for the synthetic Oracle seed records.
- oracle_synthetic_seed.sql — Contains 66 unexecuted INSERT statements for an isolated synthetic Oracle test fixture.
- oracle_validation.sql — Contains unexecuted Oracle diagnostic queries for journal balance, mapping matches, history overlaps, policies and constraint states.
- parameter_dictionary.csv — Explains runtime and publication parameters with their types, authority, requiredness, validation and missing-value behavior.
- physical_dictionary.csv — Documents all 233 proposed columns with types, purpose, nullability, constraints, sensitivity, history and source-binding status.
- physical_erd.mmd — Contains the Mermaid source for the complete proposed physical table and foreign-key diagram.
- policy.schema.json — Defines the required structure of an internal policy record including version, owner, approval and source-binding state.
- prompt_requirement_review.csv — Reviews each of the 56 original prompt sections and distinguishes proposed or partial work from complete implementation.
- question_bank.json — Contains 110 candidate questions comprising 50 executable development cases and 60 templates with missing-input dependencies.
- README.md — Introduces the package, identifies the main files and gives commands to rebuild artifacts and run offline tests.
- readme_count_reconciliation.json — Compares workbook README count claims with populated candidate rows and literal identifier counts.
- reference_engine.py — Implements the bounded offline decimal calculations and selected metadata, interval, replay and authorization-reference checks.
- repair_proposals.json — Records evidence-backed workbook repair candidates with impact, required approval and an explicit unapplied status.
- requirements.txt — Pins the Python packages needed for workbook extraction and JSON Schema validation.
- research_register.json — Records primary-source research URLs, supported claims, product versions, implications, limitations and research gaps.
- row_classification.json — Classifies extracted workbook rows as plausible candidates or unresolved regions and records their warnings.
- run_tests.py — Executes the 50 golden cases, seven metadata mutation checks and three additional financial controls.
- selected_source_to_target_trace.csv — Links selected workbook policy regions and defects to proposed target objects, candidate definitions and test references.
- source_binding.schema.json — Defines configurable source mappings and rejects SOURCE_BOUND claims without source objects, column mappings and evidence.
- source_prompt_review_report.json — Records full extracted-cell comparisons, policy evidence checks and prompt-section consistency results.
- synthetic_fixture.json — Contains labeled test entities, journals, budgets, forecast vintages, FX rates, hierarchy changes and edge conditions.
- table.schema.json — Defines the required structure of table contracts including columns, keys, constraints, history and foreign-key relationships.
- test_contracts.py — Validates example requests, answers, policies, tables, metrics, source bindings and graph records against their contracts.
- test_final_review.py — Runs regression checks for grain alignment, tenant and ledger isolation, allocations, zero denominators, reversals and SQL release predicates.
- test_report.json — Records the actual offline results of the 50 golden cases, seven mutation checks and three additional controls.
- vector_record.schema.json — Defines metadata requirements for a future approved vector record including provenance, security, embedding identity and index generation.
- verify_package.py — Checks saved JSON, Python syntax, model and dictionary counts, test statuses, source-binding states and artifact hashes.
- workbook_candidate_policies.json — Preserves 12 workbook-derived policy groups with exact cell evidence, conflicts and specific pending confirmations.
- workbook_cells.json — Preserves extracted nonempty cells with coordinates, raw values, stored types, formulas, caches, formats and annotations.
- workbook_coverage_extensions.csv — Records the proposed retain, revise or defer treatment of every inspected workbook sheet.
- workbook_issues.json — Lists observed formula-like prose, stored errors, duplicate candidate identifiers and candidate alignment or status anomalies.
- workbook_kpi_catalog.json — Preserves 84 raw candidate KPI rows and nine readable candidate definitions with provenance and unapproved status.
- workbook_manifest.json — Records workbook identity, hash, extraction details, sheet profiles, feature coverage and selected raw XML evidence.
- workbook_records.json — Preserves the extracted populated workbook rows as raw ordered values grouped by worksheet.
- workbook_to_model.csv — Inventories workbook header fields and their candidate normalization, lineage, ownership and mapping treatment.

## 10 Which files to forward to the team

Send 01_team_review folder to finance reviewers and general project stakeholders. Send 02_engineering_implementation folder to the architects, Oracle team and developers. Send 03_validation_and_tests folder to QA, financial control and security reviewers. Keep the original complete package with the designated model owner or data steward for detailed workbook evidence. Only someone covering multiple roles needs multiple packs.

- Which_files_to_forward_to_the_team.md explains who should receive each archive and includes a suggested accompanying message.
- 01_team_review folder contains the single guide, candidate policy review, assumptions register and forwarding note.
- 02_engineering_implementation folder contains the proposed model, SQL, configuration, contracts, generation scripts and implementation notes.
- 03_validation_and_tests folder contains the offline tests, frozen test inputs, observed results and validation protocol.

The smaller archives have their own one-line contents lists. They do not include all the raw workbook evidence. Nothing has been sent to the team.
