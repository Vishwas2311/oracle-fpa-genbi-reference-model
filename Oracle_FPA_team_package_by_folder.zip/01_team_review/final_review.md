# Current model review and correction status

Review date: 1 November 2026. Release: reference-2026-11-01-02. Contract version: 2. Status: proposed core for further development, not production approved.

The pinned GitHub version reviewed before this correction was 00da5d1bb862e804a90ab42b7a182f1d57fec3ee. Its eight findings are addressed in this revision within the supported offline design and test scope. See correction_release_notes.md for exact changes and remaining boundaries. The earlier 30 October review is retained as prior_review_2026_10_30.md, whose counts describe the earlier release.

## What changed

Release-aware PK/UK/FKs now permit immutable R1/R2 snapshots without losing facts at period joins. A stable entity identity registry keeps current rights independent of financial releases. A separate FPA_PLAN_LINE preserves native MIS plan grain. Coverage is ledger-specific and ledgers declare their chart. GL compound references constrain functional currency and batch/source/currency. The offline candidate admission module rejects supported inconsistent contexts, controls and overlaps without publishing anything. Arithmetic now owns its working context and rejects non-finite/binary-float input; storage bounds are explicit. Replay is release-aware. Certification checks dependencies, policies and lineage recursively. Proposed allocation rounding validates eligible receivers and signs.

The core now has 29 tables, 248 columns and 15 proposed metrics. The graph has 35 proposed nodes and 21 depends_on edges. No embeddings, vector index or live GenBI service are implemented. All company mappings stay UNBOUND and no company metrics are certified.

## Evidence

| Suite | Observed result | Scope |
|---|---|---|
| Synthetic golden cases | 50/50 | Selected financial calculations |
| Metadata mutations | 7/7 | Selected invalid metadata |
| Additional controls | 3/3 | Independent scoped controls |
| Contract checks | 96/96 | JSON contracts and selected semantic invariants |
| Earlier regressions | 12/12 | Previously repaired cases |
| Correction regressions | See correction_test_report.json | Audit F01–F08, candidate admission and portable relational checks |
| Workbook/prompt checks | 13/13 | All 20,503 populated cells, 79 policy evidence references, 84 raw KPI rows and 56 prompt sections |

Passing these finite cases is not an overall accuracy percentage. The question bank remains 50 executable helper cases and 60 unexecuted templates. In-memory SQLite regressions exercise portable keys/checks only and establish no Oracle runtime compatibility.

## Work still required

Integrate the candidate validator with governed source-specific loaders, rejected-amount reconciliation, native database transactions/publication and security. Extend admission deliberately for currently unsupported hierarchy/driver/batch domains rather than accepting them silently. Complete applicable workforce, capital, working-capital, debt, tax, ownership and integrated-statement schedules; executable approved metric recipes and compiler; secure identity/session/query execution; lexical/graph/vector adapters; and end-to-end evaluation.

The actual Oracle release/edition/driver/features, original MIS/annexure/process notes, source samples and control totals, approved finance exceptions, access rules and workload targets remain unavailable. Native execution, real-source reconciliation and finance/security/operations acceptance remain NOT_RUN or pending. Do not run version 2 DDL over existing populated objects without a reviewed migration.

The supplied workbook remains unchanged. This correction makes no company policy approvals. Review and tests were performed by the same assistant, without an independent human finance/security certification.

## Delivery consistency revision 2

Current generated requirement notes use the canonical table/metric counts. The continuation register and completion matrix distinguish the implemented supported offline validator from unfinished source loading/native publication. The PPT explicitly labels the GenBI flow as proposed and states that application services still require implementation. test_delivery_consistency.py verifies active document counts and remaining-work descriptions; its --archive mode additionally validates all folder copies, file indexes, guide coverage and PPT claims. Read delivery_consistency_report.json for the recorded scope; archive checks do not establish native Oracle behavior or business approval.
