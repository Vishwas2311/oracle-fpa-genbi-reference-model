This document is included in the combined folder package. Use START_HERE.md at the ZIP root for current navigation.

# Validation and tests pack

This subset contains the frozen inputs and code needed to reproduce the selected offline results. Use a separate Python 3.12 or later environment with requirements.txt. From this folder, run python run_tests.py and python test_contracts.py. Expected results are 50 golden cases, seven metadata mutations, three additional controls and 90 contract checks passing.

Also run python test_final_review.py for the 12 regression checks added during the final prompt/workbook review. The source/prompt report records 13 passing checks, but repeating that source comparison requires audit_source.py in the complete package and the original prompt and workbook.

The original all-artifact manifest and verify_package.py are intentionally omitted because this is a subset. The 60 additional question templates remain unexecuted. Native Oracle execution, source reconciliation, security enforcement, performance and business approval require their own future validation. Read evaluation_protocol.md for those gates. The synthetic fixture is not company actuals and must remain isolated. No independent human review or production certification is claimed.
