# Validation and tests folder

Use a separate Python 3.12+ environment with requirements.txt. Run run_tests.py, test_contracts.py, test_final_review.py and test_correction_release.py. Expected current results are 50 golden cases, 7 mutations, 3 additional controls, 96 contract checks, 12 prior regressions and 25 correction regressions. The 13 source/prompt checks require the original workbook/prompt and audit_source.py in 04_complete_reference to reproduce.

Run publication_validation.py --input publication_fixture.json for the supported synthetic admission example. Counterexamples include two releases, report-line plans, ledger coverage, inconsistent contexts, numerical boundaries, replay, certification and allocation. SQLite probes test portable key/check/query shape only, not Oracle compatibility or timezone semantics.

The 60 additional question templates remain unexecuted. Native Oracle, real source reconciliation, live identity/security, retrieval, performance and production acceptance remain pending. Subsets omit the full-reference manifest intentionally. Read evaluation_protocol.md and correction_release_notes.md.
