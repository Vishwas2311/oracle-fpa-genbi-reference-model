import copy,json,pathlib
from jsonschema import Draft202012Validator,FormatChecker
P=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_text(encoding='utf-8'))
results=[]
def test(name,schema,value,valid):
    errors=list(Draft202012Validator(schema,format_checker=FormatChecker()).iter_errors(value))
    results.append(dict(id=name,passed=(not errors)==valid,observed_valid=not errors,expected_valid=valid,errors=[e.message for e in errors]))
intent=load('intent.schema.json');answer=load('answer.schema.json')
test('INTENT_VALID',intent,load('intent.valid.json'),True)
test('INTENT_UNRESOLVED_CERTIFICATION_REJECTED',intent,load('intent.invalid.json'),False)
bad=load('intent.valid.json');bad['scenario_context']={'scenario':'FORECAST'}
test('MISSING_FORECAST_VERSION',intent,bad,False)
test('ANSWER_VALID',answer,load('answer.valid.json'),True)
test('ANSWER_STOP',answer,load('answer.stop.json'),True)
bad=load('answer.valid.json');bad['truncated']=True
test('TRUNCATED_SUCCESS_REJECTED',answer,bad,False)
bad=load('answer.valid.json');bad['rows'][0]['value']=123.1
test('BINARY_FLOAT_MONEY_REJECTED',answer,bad,False)
for p in load('canonical_model.json')['policies']:test('POLICY_'+p['id'],load('policy.schema.json'),p,True)
for t in load('canonical_model.json')['tables']:test('TABLE_'+t['name'],load('table.schema.json'),t,True)
for m in load('canonical_model.json')['metrics']:test('METRIC_'+m['id'],load('metric.schema.json'),m,True)
for b in load('configuration.json')['source_bindings']:test('BINDING_'+b['target'],load('source_binding.schema.json'),b,True)
bad=load('configuration.json')['source_bindings'][0];bad['state']='SOURCE_BOUND'
test('FALSE_SOURCE_BINDING_REJECTED',load('source_binding.schema.json'),bad,False)
graph=load('graph.proposed.json');test('GRAPH_SCHEMA',load('graph.schema.json'),graph,True)
ids={n['id'] for n in graph['nodes']}
results.append(dict(id='GRAPH_REFERENCES',passed=all(e['from_id'] in ids and e['to_id'] in ids for e in graph['edges'])))
from reference_engine import check_dag
check_dag([(e['from_id'],e['to_id']) for e in graph['edges'] if e['type']=='depends_on'])
results.append(dict(id='GRAPH_DEPENDENCY_DAG',passed=True))
report=dict(checks=results,passed=sum(r['passed'] for r in results),total=len(results),limitations='Schema checks plus selected semantic invariants only; trusted identity provenance, native enforcement and all graph domain/range rules need integration.')
(P/'contract_test_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ['passed','total']}))
assert all(r['passed'] for r in results)
