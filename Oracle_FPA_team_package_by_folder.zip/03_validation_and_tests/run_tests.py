"""Run actual offline assertions and mutation checks; Oracle and production gates stay NOT_RUN."""
import copy,datetime,hashlib,json,pathlib,sys,traceback
from decimal import Decimal,localcontext
from reference_engine import evaluate,validate_model,ContractError,compare,totals
P=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_text(encoding='utf-8'))
fixture=load('synthetic_fixture.json');model=load('canonical_model.json'); cases=load('golden_cases.json')
results=[]
with localcontext() as ctx:
    ctx.prec=38
    for case in cases:
        observed=None;error=None;ok=False
        try:
            observed=evaluate(case,fixture,model)
            expected=case['expected_result_rows'][0]['value'] if not case['expected_error'] else None
            if case['expected_error']:ok=False
            elif expected is None or isinstance(expected,(bool,int)):ok=(observed==expected)
            else:
                try:ok=abs(Decimal(str(observed))-Decimal(expected))<=Decimal(case['tolerance'])
                except Exception:ok=(str(observed)==expected)
        except ContractError as ex:
            error=str(ex);ok=(error==case['expected_error'])
        except Exception as ex:error=repr(ex)
        results.append(dict(id=case['id'],passed=ok,observed=str(observed) if isinstance(observed,Decimal) else observed,error=error,expected_rows=case['expected_result_rows'],expected_error=case['expected_error']))
mutations=[]
def mutation(name,fn,expected):
    m=copy.deepcopy(model);fn(m)
    try:validate_model(m);got='NO_ERROR'
    except ContractError as e:got=str(e)
    mutations.append(dict(id=name,passed=got==expected,observed=got,expected=expected))
mutation('MISSING_POLICY',lambda m:m['metrics'][0]['policy_ids'].append('absent'),'MISSING_POLICY')
mutation('INVALID_ENUM',lambda m:m['metrics'][0].update(status='Passed'),'INVALID_STATUS')
mutation('DUPLICATE_ID',lambda m:m['tables'].append(m['tables'][0]),'DUPLICATE_ID')
mutation('FK_TYPE',lambda m:m['tables'][1]['columns'][-1].update(type='NUMBER(4,0)'),'FK_TYPE_MISMATCH')
mutation('FALSE_CERTIFICATION',lambda m:m['metrics'][0].update(certifiable=True),'UNAPPROVED_CERTIFICATION')
mutation('SIGNATURE_ARITY',lambda m:m['metrics'][2]['expression'].update(input_metric_ids=[]),'EXPRESSION_ARITY')
mutation('UNIT_MISMATCH',lambda m:m['metrics'][2]['expression'].update(output_unit='headcount'),'UNIT_OR_GRAIN_MISMATCH')
# Independent checks inspect full intersections and fixed account totals, not just the case result count.
extra=[]
def check(name,fn):
    try:fn();extra.append(dict(id=name,passed=True))
    except Exception as e:extra.append(dict(id=name,passed=False,error=repr(e)))
def comparison_check():
    x=compare([dict(key='A',amount='10'),dict(key='B',amount='20')],[dict(key='B',amount='15'),dict(key='C',amount='30')])
    assert x[0]['actual']=='10' and x[0]['budget'] is None and x[0]['absolute'] is None
    assert x[1]['absolute']==Decimal('5')
    assert x[2]['actual'] is None and x[2]['budget']=='30'
check('UNMATCHED_INTERSECTIONS_NOT_ZERO_FILLED',comparison_check)
def balances():
    from reference_engine import trial_balance
    tb=trial_balance(fixture['journals'])
    assert tb[('T1','L1','E1','USD','CASH')]==Decimal('250')
    assert tb[('T1','L1','E2','EUR','CASH')]==Decimal('280')
    assert tb[('T1','L1','E1','USD','REV')]==Decimal('-360')
    assert tb[('T1','L1','E2','EUR','COGS')]==Decimal('90')
check('INDEPENDENT_TRIAL_BALANCE_ACCOUNT_CONTROLS',balances)
def margin():
    with localcontext() as c:
        c.prec=38
        correct=totals(fixture,'2026-01',converted=True)['margin']
        incorrect=(Decimal(50)/120+Decimal(60)/90)/2
        assert abs(correct-Decimal(170)/300)<Decimal('1e-30') and correct!=incorrect
check('RATIO_DIFFERS_FROM_UNWEIGHTED_AVERAGE',margin)
report=dict(executed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python run_tests.py',engine='Python Decimal offline reference; not Oracle',snapshot=fixture['id'],release=model['release_id'],model_sha256=hashlib.sha256((P/'canonical_model.json').read_bytes()).hexdigest(),cases=results,mutation_checks=mutations,additional_checks=extra,summary=dict(golden_passed=sum(x['passed'] for x in results),golden_total=len(results),mutation_passed=sum(x['passed'] for x in mutations),mutation_total=len(mutations),additional_passed=sum(x['passed'] for x in extra),additional_total=len(extra)),not_run=['Oracle DDL compilation and execution','Oracle typed driver round-trips','native VPD/security and pooled session isolation','actual source reconciliation','finance/access approval','NL interpretation/retrieval/narrative benchmark','load/latency/cost','prompt comparison'],independent_review='No separate human or agent reviewer; expected values are explicitly hand-specified, with separate formula/control assertions')
(P/'test_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report['summary']))
failed=[x for x in results+mutations+extra if not x['passed']]
if failed:print(json.dumps(failed,indent=2));sys.exit(1)
