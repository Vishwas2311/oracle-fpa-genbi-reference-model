"""Independent regression probes added during prompt/workbook final review; no Oracle connection."""
import copy,datetime,json,pathlib,re,sys
from decimal import Decimal
from reference_engine import ContractError,evaluate,trial_balance,totals,validate_model
P=pathlib.Path(__file__).resolve().parent
load=lambda name:json.loads((P/name).read_text(encoding='utf-8'))
model=load('canonical_model.json');fixture=load('synthetic_fixture.json');results=[]
def check(name,fn):
    try:fn();results.append(dict(id=name,passed=True))
    except Exception as e:results.append(dict(id=name,passed=False,error=str(e)))
def rejected(fn,expected):
    try:fn()
    except ContractError as e:assert str(e)==expected,(str(e),expected);return
    raise AssertionError('Invalid input was accepted')
def division_grain():
    m=copy.deepcopy(model)
    next(x for x in m['metrics'] if x['id']=='metric.revenue')['grain'].append('product')
    # This also affects gross profit; isolate the division to exercise that branch.
    m['metrics']=[x for x in m['metrics'] if x['id'] in ['metric.revenue','metric.cogs','metric.gross_profit','metric.gross_margin']]
    next(x for x in m['metrics'] if x['id']=='metric.gross_profit')['expression'].update(operator='sum_report_line',input_metric_ids=[])
    rejected(lambda:validate_model(m),'UNIT_OR_GRAIN_MISMATCH')
check('DIVISION_REJECTS_DIFFERENT_INPUT_GRAINS',division_grain)
def tb_scope():
    base=fixture['journals'][0]
    rows=[dict(base,tenant='TA',ledger='LA',debit='10',credit='0'),dict(base,tenant='TB',ledger='LB',debit='0',credit='10')]
    values=trial_balance(rows)
    assert len(values)==2 and sorted(values.values())==[Decimal('-10'),Decimal('10')]
check('TRIAL_BALANCE_KEEPS_TENANT_LEDGER_SCOPES',tb_scope)
def total_scope():
    f=copy.deepcopy(fixture);f['journals'].append(dict(f['journals'][0],tenant='OTHER',period='2026-01',account='REV',debit='0',credit='999'))
    rejected(lambda:totals(f,'2026-01',converted=True),'MULTIPLE_TENANT_OR_LEDGER_SCOPES')
check('TOTALS_REJECT_UNRESOLVED_TENANT_LEDGER_SCOPE',total_scope)
check('EMPTY_ALLOCATION_RETURNS_SPECIFIC_ERROR',lambda:rejected(lambda:evaluate(dict(operation='allocation',arguments=dict(pool='100',weights=[])),fixture,model),'NO_ELIGIBLE_TARGET'))
check('NEGATIVE_ALLOCATION_WEIGHT_REJECTED',lambda:rejected(lambda:evaluate(dict(operation='allocation',arguments=dict(pool='100',weights=['1.5','-.5'])),fixture,model),'INVALID_WEIGHTS'))
check('ZERO_POPULATION_DENOMINATOR_IS_UNAVAILABLE',lambda:(_ for _ in ()).throw(AssertionError('Expected unavailable')) if evaluate(dict(operation='scope_ratio',arguments=dict(numerator=['10'],denominator=['0'])),fixture,model) is not None else None)
def reverse_scope():
    f=copy.deepcopy(fixture)
    f['journals']=[dict(f['journals'][0],debit='17',credit='0')]
    from unittest.mock import patch
    with patch('reference_engine.trial_balance',wraps=trial_balance) as checked:
        assert evaluate(dict(operation='reverse',arguments={}),f,model)==0
        checked.assert_called_once()
        rows=checked.call_args.args[0]
        assert len(rows)==2 and rows[1]['debit']=='0' and rows[1]['credit']=='17'
        assert rows[1]['account']==rows[0]['account'] and all(v==0 for v in trial_balance(rows).values())
check('ACTUAL_REVERSAL_CANCELS_EACH_ACCOUNT_SCOPE',reverse_scope)
def plan_lineage():
    for metric in model['metrics']:
        if metric['id'] in ['metric.budget','metric.forecast']:
            assert metric['lineage_ids']==['object.fpa_plan']
check('PLAN_METRICS_REFERENCE_PLAN_FACT',plan_lineage)
def query_release():
    sql=(P/'oracle_queries.sql').read_text(encoding='utf-8')
    assert re.search(r'p\.RELEASE_ID\s*=\s*g\.RELEASE_ID',sql)
    assert re.search(r'p\.RELEASE_ID\s*=\s*b\.RELEASE_ID',sql)
    assert re.search(r'v\.RELEASE_ID\s*=\s*b\.RELEASE_ID',sql)
check('QUERY_PERIOD_VERSION_RELEASE_ALIGNMENT',query_release)
def invalid_policy():
    m=copy.deepcopy(model);m['policies'][0]['status']='PASSED'
    rejected(lambda:validate_model(m),'INVALID_POLICY_STATUS')
check('POLICY_APPROVAL_ENUM_CHECKED_SEMANTICALLY',invalid_policy)
def resolvable_test_refs():
    bank={q['id']:q for q in load('question_bank.json')}
    question=next(q for q in bank.values() if q['question']=='Can EBITDA be supplied when only EBITA is supported?')
    text=(P/'selected_source_to_target_trace.csv').read_text(encoding='utf-8')
    assert question['id']+' template' in text
check('EBITDA_TRACE_POINTS_TO_CORRECT_TEMPLATE',resolvable_test_refs)
def no_offset_tb():
    base=fixture['journals'][0]
    f=dict(fixture,journals=[dict(base,tenant='A',debit='10',credit='0'),dict(base,tenant='B',debit='0',credit='10')])
    rejected(lambda:evaluate(dict(operation='trial_balance',arguments={}),f,model),'UNBALANCED_TRIAL_BALANCE')
check('OFFSET_TENANT_IMBALANCES_DO_NOT_PASS',no_offset_tb)
report=dict(review_date='2026-10-30',executed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=results,passed=sum(r['passed'] for r in results),total=len(results),scope='Offline regression probes only; not a native Oracle or production security certification')
(P/'final_review_test_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
sys.exit(0 if all(r['passed'] for r in results) else 1)
